<?php
/**
 *
 * Hide Newest User. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2018 HiFiKabin
 * @license GNU General Public License, version 2 (GPL-2.0-only)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'ACP_HIDENEWESTUSER_CONFIG'				=> 'Paramètres',
	'ACP_HIDENEWESTUSER_CONFIG_EXPLAIN'		=> 'Sur cette page il est possible de paramétrer les options de l’extension : « Hide Newest User ».',

	'ACP_HIDENEWESTUSER_CONFIG_SET'			=> 'Options disponibles',
	'HIDENEWESTUSER_CONFIG_SAVED'			=> 'Les paramètres ont été sauvegardés avec succès !',

	'HIDENEWESTUSER_STATS'					=> 'Bloc « Statistiques »',
	'HIDENEWESTUSER_STATS_SW_EXPLAIN'		=> 'Permet de sélectionner le groupe d’utilisateurs qui peut voir le bloc « STATISTIQUES ».',
	
	'HIDENEWESTUSER_ONLINE'					=> 'Bloc « Qui est en ligne »',
	'HIDENEWESTUSER_ONLINE_EXPLAIN'			=> 'Permet de masquer le bloc « QUI EST EN LIGNE ».',
	'HIDENEWESTUSER_ONLINE_SW_EXPLAIN'		=> 'Permet de sélectionner le groupe d’utilisateurs qui peut voir le bloc « QUI EST EN LIGNE ».',

	'HIDENEWESTUSER_ADMIN'					=> 'Seulement les administrateurs',
	'HIDENEWESTUSER_MODS'					=> 'Seulement les administrateurs et les modérateurs',
	'HIDENEWESTUSER_MEMBERS'				=> 'Seulement les membres',
	'HIDENEWESTUSER_NONE'					=> 'Personne',
	'HIDENEWESTUSER_ALL'					=> 'Tout le monde',
));
