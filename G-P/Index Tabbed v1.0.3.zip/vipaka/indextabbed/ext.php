<?php
/**
*
* @package phpBB Extension - Preferences Expansion
* @copyright (c) 2014 Esmaerin/Amelia Winstead
* @license COPYRIGH
*
*/

namespace vipaka\indextabbed;

/**
* @ignore
*/

class ext extends \phpbb\extension\base
{
}
