## Changelog

### 1.0.3 - 2017-03-08

- Update code in listener.
- Update code in donation controller.
- Compatible with 3.2 (icon).
- Added acp_donation language file.
- Deleted donation_goal_currency_enable.

### 1.0.2 - 2016-05-25

- Update code.

### 1.0.1 - 2016-03-15

- Update code.

### 1.0.0 - 2015-04-12

- First release
