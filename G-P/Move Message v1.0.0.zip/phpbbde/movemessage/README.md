# phpBB 3.1 Extension - Move Message

 A small extension, that displays a short message in the topic, when it was moved from one forum to another.

Author: Joas Schilling, Philipp Kordowich

URL: https://www.phpbb.de

Version: 1.0.0

## Install instructions:
1. Download the extension
2. Copy the whole archive content to: phpBB/ext/phpbbde/movemessage
3. Go to your phpBB-Board > Admin Control Panel > Customise > Manage extensions > phpBB.de - Move Message: enable

## Update instructions:
1. Go to you phpBB-Board > Admin Control Panel > Customise > Manage extensions > phpBB.de - Move Message: disable
2. Delete all files of the extension from phpBB/ext/phpbbde/movemessage
3. Upload all the new files to the same locations
4. Go to you phpBB-Board > Admin Control Panel > Customise > Manage extensions > phpBB.de - Move Message: enable
5. Purge the board cache

## License

[GPLv2](license.txt)
