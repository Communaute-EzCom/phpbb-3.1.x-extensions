# h24as
Hides the statistics block of the phpBB extension "24 hour activity stats" to users/groups at will. The statistics will be shown only to authorized users/groups, based on permissions. As well modifies the native ACP's "time online span" to accept up to 9999 minutes instead of 999.
