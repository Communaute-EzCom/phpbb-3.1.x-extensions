<?php
/**
*
* @package phpBB Extension - phpBB Gallery Add-on: Sitemap
* @copyright (c) 2016 ostridm
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/
namespace ostridm\gallerysitemap\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;
use Symfony\Component\DependencyInjection\ContainerInterface;

/**
* Event listener
*/
class listener implements EventSubscriberInterface
{
	/**
	* Assign functions defined in this class to event listeners in the core
	*
	* @return array
	* @static
	* @access public
	*/
	static public function getSubscribedEvents()
	{
		return array(
			'shredder.sitemap.extra_sitemap_content' => 'ext_shredder_sitemap_extra_sitemap_content',
		);
	}

	/** @var \phpbb\config\config */
	protected $config;

	/** @var \phpbb\controller\helper */
	protected $helper;
	
	/** @var ContainerInterface */
	protected $phpbb_container;
	
	/** @var \phpbb\db\driver\driver_interface */
	protected $db;	

	/** @var string */
	protected $albums_table;
	
	/** @var string */
	protected $images_table;	
	

	/**
	* Constructor
	*/
	public function __construct(\phpbb\config\config $config, \phpbb\controller\helper $helper, ContainerInterface $phpbb_container, \phpbb\db\driver\driver_interface $db, $albums_table, $images_table)
	{
		$this->config = $config;
		$this->helper = $helper;
		$this->phpbb_container = $phpbb_container;
		$this->db = $db;
		$this->albums_table = $albums_table;
		$this->images_table = $images_table;
	}
	
	public function ext_shredder_sitemap_extra_sitemap_content($event)
	{
		$appender = $this->phpbb_container->get('shredder.sitemap.appender');
		
		$board_url = generate_board_url(true);
		
		$prior = '0.3';
		$freq = 'weekly';
		$time = time();
		
		$image_album_id	= -1;
		$image_album_num = 0;
		$perpage = (int)$this->config['phpbb_gallery_items_per_page'];
		
		$sql = 'SELECT i.image_id, i.image_album_id, i.image_time, a.album_last_image_time
					FROM ' . $this->images_table . ' i JOIN ' . $this->albums_table . ' a ON i.image_album_id = a.album_id 
					ORDER BY i.image_album_id, i.image_id';

					
		$result = $this->db->sql_query($sql);
		while ($row = $this->db->sql_fetchrow($result))
		{
			if ($image_album_id != $row['image_album_id'])
			{
				$image_album_id = $row['image_album_id'];
				$image_album_count = 0;
			}
			
			$page = (int)($image_album_count/$perpage);
			$start = $page * $perpage;
			
			if ($image_album_count == $start)
			{
				if ($page > 0)
				{
					$route = $this->helper->route('phpbbgallery_core_album_page',array('album_id' => $image_album_id, 'page' => (int)(1+$page)), false, '' ); 
				}
				else
				{
					$route = $this->helper->route('phpbbgallery_core_album',array('album_id' => $image_album_id), false, '' );
				}
				
				$tm = (int)$row['album_last_image_time'];
				$tm = $tm > 0 ? $tm : $time;
				
				$appender->append($board_url . $route, $tm , $freq, $prior);
			}
			
			$image_album_count ++;
			
			$route = $this->helper->route('phpbbgallery_core_image',array('image_id' => $row['image_id']), false, '' );
			
			$tm = (int)$row['image_time'];
			$tm = $tm > 0 ? $tm : $time;
			
			$appender->append($board_url . $route, $tm , $freq, $prior);
		}	
		
		$this->db->sql_freeresult($result);
	}
}
