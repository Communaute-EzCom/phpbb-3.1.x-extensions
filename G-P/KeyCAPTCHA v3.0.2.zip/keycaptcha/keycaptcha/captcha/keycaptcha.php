<?php
/**
*
* This file is part of the phpBB Forum Software package.
*
* @copyright (c) phpBB Limited <https://www.phpbb.com>
* @license GNU General Public License, version 2 (GPL-2.0)
*
* For full copyright and license information, please see
* the docs/CREDITS.txt file.
*
*/

namespace keycaptcha\keycaptcha\captcha;
if(!class_exists( 'KeyCAPTCHA_CLASS' ))
{
	class KeyCAPTCHA_CLASS
		{			
			private $c_kc_keyword = 'accept';
			private $p_kc_visitor_ip = '';
			private $p_kc_session_id = '';
			private $p_kc_web_server_sign = '';
			private $p_kc_web_server_sign2 = '';
			private $p_kc_js_code = '';
			public $p_kc_private_key = '';
		
			public function get_web_server_sign( $use_visitor_ip=0 )
			{
				return md5( $this->p_kc_session_id.(($use_visitor_ip) ? ($this->p_kc_visitor_ip) :('')).$this->p_kc_private_key );
			}

			function __construct( $a_private_key='')	
			{
				global $user;
				if($a_private_key!='') {
					$set = explode("0",trim($a_private_key),2);
					if (sizeof($set)>1){
						$this->p_kc_private_key = trim($set[0]);
						$this->p_kc_userID = (int)$set[1];
						$this->p_kc_js_code =
"<!-- KeyCAPTCHA code (www.keycaptcha.com)-->
<script type=\"text/javascript\">
	var s_s_c_user_id = '".$this->p_kc_userID."';
	var s_s_c_session_id = '#KC_SESSION_ID#';
	var s_s_c_captcha_field_id = 'kc_response_field';
	var s_s_c_submit_button_id = 'submit,preview,post';
	var s_s_c_web_server_sign = '#KC_WSIGN#';
	var s_s_c_web_server_sign2 = '#KC_WSIGN2#';
</script>
<script type=\"text/javascript\" src=\"http://backs.keycaptcha.com/swfs/cap.js\"></script>
<!-- end of KeyCAPTCHA code-->";
					}
				}
				$this->p_kc_session_id = uniqid() . '-3.2.0.002';
				$this->p_kc_visitor_ip = $user->ip;
			}
		
			function http_get( $path )
			{
				$arr = parse_url( $path );
				$host = $arr['host'];
				$page = $arr['path'];
				if($page=='')
				{ 
					$page='/'; 
				}
				if(isset( $arr['query'] ))
				{ 
					$page.='?'.$arr['query']; 
				}
				$errno = 0;
				$errstr = '';
				$fp = fsockopen( $host, 80, $errno, $errstr, 30 );
				if(!$fp)
				{
					return '';
				}
				$request = "GET $page HTTP/1.0\r\n";
				$request .= "Host: $host\r\n";
				$request .= "Connection: close\r\n";
				$request .= "Cache-Control: no-store, no-cache\r\n";
				$request .= "Pragma: no-cache\r\n";
				$request .= "User-Agent: KeyCAPTCHA\r\n";
				$request .= "\r\n";
			
				fwrite( $fp, $request );
				$out = '';

				while (!feof( $fp ))
				{
					$out .= fgets( $fp, 250 );
				}
				fclose( $fp );
				$ov = explode( "close\r\n\r\n", $out );

				return $ov[1];
			}
	
			public function check_result( $response )
			{
				$kc_vars = explode ( '|', $response );
				if(sizeof( $kc_vars )<4)
				{
					return false;
				}
				if($kc_vars[0]==md5( $this->c_kc_keyword.$kc_vars[1].$this->p_kc_private_key.$kc_vars[2] ))
				{
					$this->p_kc_session_id = $kc_vars[3];				
					$this->p_kc_web_server_sign = $this->get_web_server_sign( 1 );

					if($kc_vars[1]==$this->p_kc_web_server_sign)
					{
						if(stripos( $kc_vars[2], 'http://' )!==0)
						{					
							$kc_current_time = time();
							$kc_var_time = split( '[/ :]', $kc_vars[2] );
							$kc_submit_time = gmmktime( $kc_var_time[3], $kc_var_time[4], $kc_var_time[5], $kc_var_time[1], $kc_var_time[2], $kc_var_time[0] );
							if(($kc_current_time - $kc_submit_time)<15)
							{
								return true;
							}
							return false;
						}
						else
						{	
							if($this->http_get( $kc_vars[2] . $this->p_kc_web_server_sign )=='1')
							{
								return true;
							}
							else
							{
								return false;
							}
						}
					}
					return false;
				}
				return false;
			}

			public function render_js ()
			{
// 				if ( isset( $_SERVER['HTTPS'] )&&( $_SERVER['HTTPS']=='on' ) )
				if ( isset($_SERVER['HTTPS'])&&(request_var('HTTPS','')=='on') )
				{
					$this->p_kc_js_code = str_replace( 'http://', 'https://', $this->p_kc_js_code );
				}
				$this->p_kc_js_code = str_replace( '#KC_SESSION_ID#', $this->p_kc_session_id, $this->p_kc_js_code );
				$this->p_kc_js_code = str_replace( '#KC_WSIGN#', $this->get_web_server_sign( 1 ), $this->p_kc_js_code );
				$this->p_kc_js_code = str_replace( '#KC_WSIGN2#', $this->get_web_server_sign(), $this->p_kc_js_code );
				return $this->p_kc_js_code;	
			}
		}
}

class keycaptcha extends \phpbb\captcha\plugins\captcha_abstract
{
	// PHP4 Constructor
	function phpbb_keycaptcha()	{
	}

	function init($type)
	{
		global $config, $db, $user;

		$user->add_lang_ext('keycaptcha/keycaptcha','captcha_keycaptcha');
		parent::init($type);
	}

	public function is_available()
	{
		global $config, $user;
		$user->add_lang_ext('keycaptcha/keycaptcha','captcha_keycaptcha');
		return (isset($config['keycaptcha_privkey']) && !empty($config['keycaptcha_privkey']));
	}

	/**
	*  API function
	*/
	function has_config()
	{
		return true;
	}

	static public function get_name()
	{
		return 'CAPTCHA_KEYCAPTCHA';
	}

	/**
	* This function is implemented because required by the upper class, but is never used for reCaptcha.
	*/
	function get_generator_class()
	{
		throw new \Exception('No generator class given.');
	}

	function acp_page($id, &$module)
	{
		global $config, $db, $template, $user, $request,$phpbb_log;

		$captcha_vars = array(
			'keycaptcha_privkey'				=> 'KEYCAPTCHA_PRIVKEY',
		);

		$module->tpl_name = '@keycaptcha_keycaptcha/captcha_keycaptcha_acp';
		$module->page_title = 'ACP_VC_SETTINGS';
		$form_key = 'acp_captcha';
		add_form_key($form_key);

		$submit = $request->variable('submit', '');

		if ($submit && check_form_key($form_key))
		{
			$captcha_vars = array_keys($captcha_vars);
			foreach ($captcha_vars as $captcha_var)
			{
				$value = $request->variable($captcha_var, '');
				if ($value)
				{
					$config->set($captcha_var, $value);
				}
			}

			$phpbb_log->add('admin', $user->data['user_id'], $user->ip, 'LOG_CONFIG_VISUAL');
			trigger_error($user->lang['CONFIG_UPDATED'] . adm_back_link($module->u_action));

		}
		else if ($submit)
		{
			trigger_error($user->lang['FORM_INVALID'] . adm_back_link($module->u_action));
		}
		else
		{
			foreach ($captcha_vars as $captcha_var => $template_var)
			{
				$var = (isset($_REQUEST[$captcha_var])) ? request_var($captcha_var, '') : ((isset($config[$captcha_var])) ? $config[$captcha_var] : '');
				$template->assign_var($template_var, $var);
			}

			$template->assign_vars(array(
				'CAPTCHA_PREVIEW'	=> $this->get_demo_template($id),
				'CAPTCHA_NAME'		=> $this->get_service_name(),
				'U_ACTION'			=> $module->u_action,
			));

		}
	}

	// not needed
	function execute_demo()
	{
	}

	// not needed
	function execute()
	{
	}

	function get_template()
	{
		global $config, $user, $template, $phpbb_root_path, $phpEx;

		if ($this->is_solved())
		{
			return false;
		}
		else
		{
			$contact_link = phpbb_get_board_contact_link($config, $phpbb_root_path, $phpEx);
			$explain = $user->lang(($this->type != CONFIRM_POST) ? 'CONFIRM_EXPLAIN' : 'POST_CONFIRM_EXPLAIN', '<a href="' . $contact_link . '">', '</a>');
			
			$pk = isset($config['keycaptcha_privkey']) ? $config['keycaptcha_privkey'] : '';
			$kc_o = new KeyCAPTCHA_CLASS($pk);
			$kc_code = $kc_o->render_js();
			
			
			$template->assign_vars(array(
				'KEYCAPTCHA_CODE'			=> $kc_code,
				'KEYCAPTCHA_ERRORGET'		=> '',
				'S_KEYCAPTCHA_AVAILABLE'		=> self::is_available(),
				'S_CONFIRM_CODE'			=> true,
				'S_TYPE'					=> $this->type,
				'L_CONFIRM_EXPLAIN'			=> $explain,
			));

			return '@keycaptcha_keycaptcha/captcha_keycaptcha.html';
		}
	}

	function get_demo_template($id)
	{
		return $this->get_template();
	}

	function get_hidden_fields()
	{
		$hidden_fields = array();

		// this is required for posting.php - otherwise we would forget about the captcha being already solved
		if ($this->solved)
		{
			$hidden_fields['confirm_code'] = $this->code;
		}
		$hidden_fields['confirm_id'] = $this->confirm_id;
		return $hidden_fields;
	}

	function uninstall()
	{
		$this->garbage_collect(0);
	}

	function install()
	{
		return;
	}

	function validate()
	{
		global $config, $user,$request;
		if (!parent::validate())
		{	
			return false;
		}
		else
		{
			$pk = isset($config['keycaptcha_privkey']) ? $config['keycaptcha_privkey'] : '';
			$kc_o = new KeyCAPTCHA_CLASS($pk);
			if($kc_o->check_result( $request->variable('kc_response_field', '')))
			{
				$this->solved=true;
				return false;
			}
			else
			{
				return $user->lang['KEYCAPTCHA_INCORRECT'];
			}

		}
	}
}
