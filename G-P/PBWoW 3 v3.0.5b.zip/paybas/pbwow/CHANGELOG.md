## Changelog

 ##### 3.0.5b 30/12/2016
 - [FIX] fix in migrations

##### 3.0.5 18/12/2016
- [FIX] ACP now correctly sets the version color to red when extension is not up to date. 
- [FIX] Blizzard Static Render Domains Update 

##### 3.0.4 13/11/2016
- [FIX] fix for phpbb 3.1.10

##### 3.0.3 13/11/2016
- [NEW] now uses phpbb native version_helper class to fetch latest version info in ACP.
- [NEW] added Demon hunter class for WoW
- [CHG] Level cap changed to 110
- [NEW] added uninstall feature

