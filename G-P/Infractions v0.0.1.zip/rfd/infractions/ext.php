<?php

namespace rfd\infractions;

class ext extends \phpbb\extension\base {

}