<?php
/**
*
* @package phpBB Extension - Hide newest user and stats
* @copyright (c) 2015 HiFiKabin
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace hifikabin\hidenewestuser\acp;

class hidenewestuser_module
{
var $u_action;

	function main($id, $mode)
	{
		global $user, $template, $request;
		global $config;

		$this->tpl_name = 'acp_hidenewestuser_config';
		$this->page_title = $user->lang('HIDENEWESTUSER_CONFIG');

		$user->add_lang_ext('hifikabin/hidenewestuser', 'common');

		add_form_key('acp_hidenewestuser_config');

		$submit = $request->is_set_post('submit');
		if ($submit)
		{
			if (!check_form_key('acp_hidenewestuser_config'))
			{
				trigger_error('FORM_INVALID');
			}
			$config->set('hidenewestuser_online', $request->variable('hidenewestuser_online', 0));
			$config->set('hidenewestuser_stats_sw', $request->variable('hidenewestuser_stats_sw', 0));
			$config->set('hidenewestuser_online_sw', $request->variable('hidenewestuser_online_sw', 0));

			trigger_error($user->lang('HIDENEWESTUSER_CONFIG_SAVED') . adm_back_link($this->u_action));
		}

		$template->assign_vars(array(
			'HIDENEWESTUSER_ONLINE'			=> $config['hidenewestuser_online'],
			'HIDENEWESTUSER_STATS_SW'		=> $config['hidenewestuser_stats_sw'],
			'HIDENEWESTUSER_ONLINE_SW'		=> $config['hidenewestuser_online_sw'],
			'U_ACTION'						=> $this->u_action,
		));
	}
}
