# Messenger
This is the repository for the development of the Messenger extension for phpBB 3.1

Extension is currently under development and is not recommended to install on the live forum. No support will be given until the first release.
