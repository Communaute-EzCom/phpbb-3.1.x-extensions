# who-was-here
Extension phpBB3.1 - Nv who was here?

# Installation:
Copy the entire contents of the repository to ext/bb3mobi/washere/
Navigate in the ACP to Customise -> Extension Management.
Click Enable for Who was here.

[![Build Status](https://travis-ci.org/bb3mobi/who-was-here.svg?branch=master)](https://travis-ci.org/bb3mobi/who-was-here)
