s9e\mediaembed is a phpBB extension that automatically embeds third-party media in messages.

### How to install

[Download the latest release](https://github.com/s9e/phpbb-ext-mediaembed/releases/latest). Unzip the archive into the `ext` directory of your forum. Then go to the ACP and enable the extension.

![](http://i.imgur.com/i64CxlC.png)

### Like this extension?

If you like this extension, you can support its author with a donation in USD or EUR.

[![Donate in USD](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG_global.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ABGFV5AGE98AG)
[![Donate in EUR](https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG_global.gif)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=6P6985GT2DLGL)