<?php

/**
* @package   s9e\mediaembed
* @copyright Copyright (c) 2014-2016 The s9e Authors
* @license   http://www.opensource.org/licenses/mit-license.php The MIT License
*/
namespace s9e\mediaembed;

use phpbb\extension\base;

class ext extends base
{
}