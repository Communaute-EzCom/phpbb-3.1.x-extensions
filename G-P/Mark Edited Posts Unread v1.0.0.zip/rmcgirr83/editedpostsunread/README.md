phpbb-3.1-ext-editedposts_unread
=========================

This extension marks topic's last posts and first post as unread if they are edited.



[![Build Status](https://travis-ci.org/rmcgirr83/phpbb-3.1-ext-editedposts_unread.svg)](https://travis-ci.org/rmcgirr83/phpbb-3.1-ext-editedposts_unread)
## Installation

### 1. clone
Clone (or download and move) the repository into the folder /ext/rmcgirr83/editedpostsunread:

```
cd phpBB3
git clone https://github.com/rmcgirr83/phpbb-3.1-ext-editedposts_unread.git ext/rmcgirr83/editedpostsunread/
```

### 2. activate
Go to admin panel -> tab customise -> Manage extensions -> enable `Mark Edited Posts Unread`

