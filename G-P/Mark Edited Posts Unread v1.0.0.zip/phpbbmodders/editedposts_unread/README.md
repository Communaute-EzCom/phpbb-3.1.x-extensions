phpbb-3.1-ext-editedposts_unread
=========================

This extension marks topic's last posts and first post as unread if they are edited.



[![Build Status](https://travis-ci.org/phpbbmodders/editedposts_unread.svg)](https://travis-ci.org/phpbbmodders/editedposts_unread)
## Installation

### 1. clone
Clone (or download and move) the repository into the folder /ext/phpbbmodders/editedposts_unread:

```
cd phpBB3
git clone https://github.com/phpbbmodders/editedposts_unread.git ext/phpbbmodders/editedposts_unread/
```

### 2. activate
Go to admin panel -> tab customise -> Manage extensions -> enable Mark Edited Posts Unread

