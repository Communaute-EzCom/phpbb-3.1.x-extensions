<?php
/**
*
* Online Status extension
* Czech translation by R3gi (regiprogi@gmail.com)
*
* @copyright (c) 2015 matu58 <https://www.matiaslauriti.com.ar>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// ---------

$lang = array_merge($lang, array(
	'STATUS'				=> 'Stav',
));
