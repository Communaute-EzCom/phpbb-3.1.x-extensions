<?php

// Use this file for custom installation logic

namespace masivotech\mobbernTCP;

class ext extends \phpbb\extension\base
{
}
