; (function ($, window, document) {
	// do stuff here and use $, window and document safely
	// https://www.phpbb.com/community/viewtopic.php?p=13589106#p13589106
	$(".post:has(.postprofile:hidden)").addClass("profile_hidden");
})(jQuery, window, document);
