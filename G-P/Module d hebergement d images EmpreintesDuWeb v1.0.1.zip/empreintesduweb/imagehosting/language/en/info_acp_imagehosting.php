<?php
/**
*
* Image hosting EmpreintesDuWeb
*
* @copyright (c) 2015 EmpreintesDuWeb https://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'ACP_EDW_IMAGEHOSTING_EXT_TITLE'				=> 'Module hosting image EmpreintesDuWeb',
	'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS'			=> 'General settings',
	'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_EDW'		=> 'EmpreintesDuWeb module settings',
	'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_OTHER'	=> 'Module other parameters hoster',
	'ACP_EDW_IMAGEHOSTING_DESCRIPTION_EXT'			=> 'This extension is a service by <a href="https://www.empreintesduweb.com">EmpreintesDuWeb</a> ©',

	// General
	'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_GENERAL'		=> 'General settings module',
	'ACP_EDW_IMAGEHOSTING_ACTIVE_EXT'					=> 'Enable image hosting module?',
	'ACP_EDW_IMAGEHOSTING_WIDTH'						=> 'Indicate the desired width for the module',
	'ACP_EDW_IMAGEHOSTING_WIDTH_EXPLAIN'				=> 'The ideal width is 450 px',
	'ACP_EDW_IMAGEHOSTING_HEIGHT'						=> 'Indicate the desired height of the module',
	'ACP_EDW_IMAGEHOSTING_HEIGHT_EXPLAIN'				=> 'The ideal height is 120 px',
	'ACP_EDW_IMAGEHOSTING_ALIGN_CENTER'					=> 'Should the unit be centered on the page?',
	'ACP_EDW_IMAGEHOSTING_ALIGN_CENTER_EXPLAIN'			=> '<span style="color: #016D21;"><strong>Option unnecessary if you use the popup version</strong></span><br />If « No » is selected the module will default left-aligned.',
	'ACP_EDW_IMAGEHOSTING_OTHER_HOSTING'					=> 'Use the module of another host that EmpreintesDuWeb?',
	'ACP_EDW_IMAGEHOSTING_OTHER_HOSTING_EXPLAIN'			=> 'If you chississez « Yes » you can specify the code for another host unit in the « %s »',
	'ACP_EDW_IMAGEHOSTING_IFRAME_ACTIVE'				=> 'Use the module iframe?',
	'ACP_EDW_IMAGEHOSTING_IFRAME_ACTIVE_EXPLAIN'		=> 'If set to « No » you will use the popup module instead of the iframe.<br />The iframe version will open below the writing of a message field.<br />The version will display popup type bbcode button and in the space provided for this purpose.',

	// Module settings EmpreintesDuWeb
	'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_MODULE_EDW'	=> 'Module settings EmpreintesDuWeb',
	'ACP_EDW_IMAGEHOSTING_ID'							=> 'Enter your personal ID',
	'ACP_EDW_IMAGEHOSTING_ID_EXPLAIN'					=> 'Your personal ID will be available after opening an account on our <a href="https://images.empreintesduweb.com">image hosting service</a> default if you specify the ID « 0 » image will be considered for a single user <i>(basic offers)</i> and will be retained less time on the server if it is not viewed regularly.<br />See the <a href="https://images.empreintesduweb.com/comparatif-des-offres.html">comparison of our offers</a>',
	'ACP_EDW_IMAGEHOSTING_COPY'							=> 'support EmpreintesDuWeb',
	'ACP_EDW_IMAGEHOSTING_COPY'							=> 'View EmpreintesDuWeb copyright at the bottom of the forum (footer) of forum?',
	'ACP_EDW_IMAGEHOSTING_COPY_EXPLAIN'					=> 'The team of EmpreintesDuWeb decided not to impose copyright, but the display of this link is greatly appreciated so if you like our service is a little more to us. <strong>If you use the iframe of another image hosting copyright does not display whatever you want.</strong>',

	// Module settings if you are using another hosting
	'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_MODULE_OTHER'	=> 'Module settings if you are using another hosting',
	'ACP_EDW_IMAGEHOSTING_CODE_IFRAME'					=> 'Enter here the iframe code you want to use',
	'ACP_EDW_IMAGEHOSTING_CODE_IFRAME_EXPLAIN'			=> 'If you use image hosting EmpreintesDuweb default there is no need to fill in this field, you can leave it blank. By cons, if you chose « Yes » to « %s » this field is required.',

	// Various error messages
	'ACP_EDW_IMAGEHOSTING_ANOTHER_HOST'		=> 'You have chosen to use the iframe code from another web host so you do not have access to this part of the module whose settings will not be useful to you.<br /><br />Go to the menu « %s » below against',
	'ACP_EDW_IMAGEHOSTING_HOST_EDW'			=> 'You have chosen to use the image hosting EmpreintesDuweb so you do not have access to this part of the module whose settings will not be useful to you.<br /><br />Visit the menu « %s » below cons.',

	// Checking the version
	'ACP_EDW_VERSION_CHECK'			=> 'Checking the version of the extension',
	'ACP_EDW_ANNOUNCEMENT_TOPIC'	=> 'Announcement of availability',
	'ACP_EDW_CURRENT_VERSION'		=> 'Extension version currently installed',
	'ACP_EDW_DOWNLOAD_LATEST'		=> 'Download the latest version of the extension',
	'ACP_EDW_LATEST_VERSION'		=> 'Latest extension',
	'ACP_EDW_NO_INFO'				=> 'Version server could not be contacted',
	'ACP_EDW_NOT_UP_TO_DATE'		=> '« %s » is not up to date',
	'ACP_EDW_RELEASE_ANNOUNCEMENT'	=> 'More information about the update',
	'ACP_EDW_UP_TO_DATE'			=> '« %s » is up to date',
));
