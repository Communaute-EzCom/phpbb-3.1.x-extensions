<?php
/**
*
* Image hosting EmpreintesDuWeb
*
* @copyright (c) 2015 EmpreintesDuWeb https://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'EDW_IMAGEHOSTING_ACTIVE_USER'			=> 'Can see and use of EmpreintesDuWeb image hosting module on the posting page of a message.',
));
