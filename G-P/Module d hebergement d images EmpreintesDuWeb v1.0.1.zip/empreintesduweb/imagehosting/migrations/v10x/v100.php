<?php
/**
*
* Image hosting EmpreintesDuWeb
*
* @copyright (c) 2015 EmpreintesDuWeb https://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace empreintesduweb\imagehosting\migrations\v10x;

class v100 extends \phpbb\db\migration\migration
{
	public function update_data()
	{
		return array(
			// Add configs
			array('config.add', array('edw_imagehosting_iframe_active', '1')),
			array('config.add', array('edw_imagehosting_id', '0')),
			array('config.add', array('edw_imagehosting_width', '450')),
			array('config.add', array('edw_imagehosting_height', '125')),
			array('config.add', array('edw_imagehosting_align_center', '0')),
			array('config.add', array('edw_imagehosting_copy', '1')),
			array('config.add', array('edw_imagehosting_other_hosting', '0')),
			array('config_text.add', array('edw_imagehosting_code_iframe', '')),

			// Current version
			array('config.add', array('edw_imagehosting_version', '1.0.0')),

			// Add ACP modules
			array('module.add', array('acp', 'ACP_CAT_DOT_MODS', 'ACP_EDW_IMAGEHOSTING_EXT_TITLE')),
			array('module.add', array(
				'acp',
				'ACP_EDW_IMAGEHOSTING_EXT_TITLE',
				array(
					'module_basename'	=> '\empreintesduweb\imagehosting\acp\imagehosting_module',
					'modes'				=> array('general_settings', 'settings_edw', 'settings_other'),
				)
			)),

			// Add permission
			array('permission.add', array('u_edw_imagehosting_active', true)),

			// Set permissions
			array('permission.permission_set', array('ROLE_USER_FULL', 'u_edw_imagehosting_active')),
			array('permission.permission_set', array('ROLE_USER_NOAVATAR', 'u_edw_imagehosting_active')),
			array('permission.permission_set', array('ROLE_USER_NOPM', 'u_edw_imagehosting_active')),
			array('permission.permission_set', array('ROLE_USER_STANDARD', 'u_edw_imagehosting_active')),
			array('permission.permission_set', array('ROLE_USER_NEW_MEMBER', 'u_edw_imagehosting_active')),
		);
	}
}