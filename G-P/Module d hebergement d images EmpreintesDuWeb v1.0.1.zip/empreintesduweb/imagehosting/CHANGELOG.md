# Changelog

## 1.0.1 - 01-08-2016

- Prise en compte de SSL sur EmpreintesDuWeb
- Suppression de la vérification de version depuis l'espace de réglage de l'extension, car cette possibilité existe déjà dans phpBB

## 1.0.0 - 24-07-2015

- Mise en conformité de l'extension en vue d'une future validation
- Test de compatibilité avec phpBB 3.1.5
- Déplacement du copyright qui ne s'affiche que sur la page de redaction d'un message
- Les clés de langue de l'extension ne sont chargées que sur la page de rédaction d'un message
- Ajout de la vérification de version dans la page des paramètres généraux
- Possibilité d'utiliser la version popup même pour d'autres hébergeur que EmpreintesDuWeb
- Quelques changements dans le texte

## 1.0.0-b2 - 21-03-2015

- Corrections dans les fichiers de langue
- Correction du CSS
- Suppression de l'option de désactivation de l'extension qui faisait double emploi
- Ajout d'une permission utilisateur "Peut voir et utiliser le module d’hébergement d’images EmpreintesDuWeb sur la page de rédaction d’un message" onglet "Divers" qui permet d'afficher ou non le module suivant les besoins de l'administrateur
- Changement de nom pour les config_name pour être cohérent

## 1.0.0-b1 - 05-03-2015

- Ajout de la traduction en anglais
- Corrections et modifications
- Prise en charge de l'affichage sur divers taille d'écran du PC au smartphone (responsive) pour le module d'hébergement par défaut
- Possibilité d'utiliser un code html d'un autre hébergeur d'images externe
- Amélioration de la partie "réglages" en séparant en catégories

## 0.0.2 - 24-02-2015

- Ajout d'un paramètre permettant d'afficher ou non le copyright en bas du forum (footer)

## 0.0.1 - 21-02-2015

- Première version de l'extension
