Social Login for phpBB 3.1.x
====================

An installation guide is available here:
http://docs.oneall.com/plugins/guide/social-login-phpbb/3.1/