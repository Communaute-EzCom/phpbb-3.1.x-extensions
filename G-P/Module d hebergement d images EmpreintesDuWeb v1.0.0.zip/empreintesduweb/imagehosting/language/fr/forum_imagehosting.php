<?php
/**
*
* Image hosting EmpreintesDuWeb
*
* @copyright (c) 2015 EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'EDW_IMAGEHOSTING_TITLE'					=> 'Héberger une image',
	'EDW_IMAGEHOSTING_TITLE_EXPLAIN'			=> 'Héberger une image en utilisant la popup',
	'EDW_IMAGEHOSTING_COPYRIGHT'				=> 'Notre module d’hébergement d’images est un service proposé par <a href="http://www.empreintesduweb.com/">EmpreintesDuWeb</a>',
	'EDW_IMAGEHOSTING_POPUP_ANOTHER_HOSTER'	=> 'Héberger vos images',
));
