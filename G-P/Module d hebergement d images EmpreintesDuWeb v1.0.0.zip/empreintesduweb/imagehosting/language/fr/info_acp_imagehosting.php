<?php
/**
*
* Image hosting EmpreintesDuWeb
*
* @copyright (c) 2015 EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'ACP_EDW_IMAGEHOSTING_EXT_TITLE'				=> 'Module d’hébergement d’images EmpreintesDuWeb',
	'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS'			=> 'Paramètres généraux',
	'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_EDW'		=> 'Paramètres module EmpreintesDuWeb',
	'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_OTHER'		=> 'Paramètres module autre hebergeur',
	'ACP_EDW_IMAGEHOSTING_DESCRIPTION_EXT'			=> 'Cette extension est un service proposé par <a href="http://www.empreintesduweb.com">EmpreintesDuWeb</a> ©',

	// General
	'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_GENERAL'		=> 'Réglages général du module',
	'ACP_EDW_IMAGEHOSTING_ACTIVE_EXT'					=> 'Activer le module d’hébergement d’images ?',
	'ACP_EDW_IMAGEHOSTING_WIDTH'						=> 'Indiquez la largeur souhaitée pour le module',
	'ACP_EDW_IMAGEHOSTING_WIDTH_EXPLAIN'				=> 'La largeur idéale est de 450 px',
	'ACP_EDW_IMAGEHOSTING_HEIGHT'						=> 'Indiquez la hauteur souhaitée pour le module',
	'ACP_EDW_IMAGEHOSTING_HEIGHT_EXPLAIN'				=> 'La hauteur idéale est de 120 px',
	'ACP_EDW_IMAGEHOSTING_ALIGN_CENTER'					=> 'Le module doit-il être centré sur la page ?',
	'ACP_EDW_IMAGEHOSTING_ALIGN_CENTER_EXPLAIN'			=> '<span style="color: #016D21;"><strong>Option inutile si vous utilisez la version popup</strong></span><br />Si « Non » est choisi le module sera par défaut aligné à gauche.',
	'ACP_EDW_IMAGEHOSTING_OTHER_HOSTING'					=> 'Utiliser le module d’un autre hébergeur qu’EmpreintesDuWeb ?',
	'ACP_EDW_IMAGEHOSTING_OTHER_HOSTING_EXPLAIN'			=> 'Si vous choisissez « Oui » vous pourrez indiquer le code du module d’un autre hébergeur dans la partie « %s »',
	'ACP_EDW_IMAGEHOSTING_IFRAME_ACTIVE'				=> 'Utiliser le module par iframe ?',
	'ACP_EDW_IMAGEHOSTING_IFRAME_ACTIVE_EXPLAIN'		=> 'Si réglé sur « Non » vous utiliserez le module par popup à la place de l’iframe.<br />La version iframe s’affichera en dessous du champ de rédaction d’un message.<br />La version popup affichera un bouton de type bbcode et à l’emplacement prévu à cet effet.',

	// Module settings EmpreintesDuWeb
	'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_MODULE_EDW'	=> 'Réglages du module EmpreintesDuWeb',
	'ACP_EDW_IMAGEHOSTING_ID'							=> 'Indiquez votre ID personnel',
	'ACP_EDW_IMAGEHOSTING_ID_EXPLAIN'					=> 'Votre ID personnel sera disponible après ouverture d’un compte sur notre <a href="http://images.empreintesduweb.com">service d’hébergement d’images</a> à défaut si vous indiquez l’ID « 0 » l’image sera considérée comme pour un simple utilisateur <i>(offre basique)</i> et sera conservée moins longtemps sur le serveur si elle n’est pas visionnée régulièrement.<br />Consultez le <a href="http://images.empreintesduweb.com/comparatif-des-offres.html">comparatif de nos offres</a>',
	'ACP_EDW_IMAGEHOSTING_COPY'							=> 'Soutenir EmpreintesDuWeb',
	'ACP_EDW_IMAGEHOSTING_COPY'							=> 'Afficher le copyright EmpreintesDuWeb dans le bas du forum (footer) du forum ?',
	'ACP_EDW_IMAGEHOSTING_COPY_EXPLAIN'					=> 'L’équipe EmpreintesDuWeb à décidé de ne pas imposer de copyright, mais l’affichage de ce lien est fortement apprécié donc si vous aimez notre service c’est un petit plus pour nous.',

	// Module settings if you are using another hosting
	'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_MODULE_OTHER'	=> 'Réglages du module si vous utilisez un autre hébergeur',
	'ACP_EDW_IMAGEHOSTING_CODE_IFRAME'					=> 'Indiquez ici le code l’iframe que vous souhaitez utiliser',
	'ACP_EDW_IMAGEHOSTING_CODE_IFRAME_EXPLAIN'			=> 'Si vous utilisez l’hébergeur d’image EmpreintesDuweb par défaut il est inutile de remplir ce champ, vous pouvez le laisser vide. Par contre, si vous avez choisi « Oui » à « %s » ce champ est obligatoire.',

	// Various error messages
	'ACP_EDW_IMAGEHOSTING_ANOTHER_HOST'		=> 'Vous avez choisi d’utiliser le code iframe d’un autre hébergeur donc vous n’avez pas accès à cette partie du module dont les réglages ne vous seront pas utiles.<br /><br />Rendez-vous dans le menu « %s » ci-contre.',
	'ACP_EDW_IMAGEHOSTING_HOST_EDW'			=> 'Vous avez choisi d’utiliser l’hébergeur d’images EmpreintesDuweb donc vous n’avez pas accès à cette partie du module dont les réglages ne vous seront pas utiles.<br /><br />Rendez-vous dans le menu « %s » ci-contre.',

	// Version check
	'ACP_EDW_VERSION_CHECK'			=> 'Vérification de la version de l’extension',
	'ACP_EDW_ANNOUNCEMENT_TOPIC'	=> 'Annonce de mise à disposition',
	'ACP_EDW_CURRENT_VERSION'		=> 'Version de l’extension actuellement installée',
	'ACP_EDW_DOWNLOAD_LATEST'		=> 'Télécharger la dernière version de l’extension',
	'ACP_EDW_LATEST_VERSION'		=> 'Dernière version de l’extension',
	'ACP_EDW_NO_INFO'				=> 'Le serveur n’a pu être contacté',
	'ACP_EDW_NOT_UP_TO_DATE'		=> '« %s » n’est pas à jour',
	'ACP_EDW_RELEASE_ANNOUNCEMENT'	=> 'Plus d’information sur la mise à jour',
	'ACP_EDW_UP_TO_DATE'			=> 'L’extension « %s » est à jour',
));
