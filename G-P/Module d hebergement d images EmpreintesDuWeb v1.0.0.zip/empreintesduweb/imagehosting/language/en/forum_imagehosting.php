<?php
/**
*
* Image hosting EmpreintesDuWeb
*
* @copyright (c) 2015 EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'EDW_IMAGEHOSTING_TITLE'					=> 'Host an image',
	'EDW_IMAGEHOSTING_TITLE_EXPLAIN'			=> 'Host an image using the popup',
	'EDW_IMAGEHOSTING_COPYRIGHT'				=> 'Our hosting module images is a service offered by <a href="http://www.empreintesduweb.com/">EmpreintesDuWeb</a>',
	'EDW_IMAGEHOSTING_POPUP_ANOTHER_HOSTER'	=> 'Host your images',
));
