<?php
/**
*
* Image hosting EmpreintesDuWeb
*
* @copyright (c) 2015 EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace empreintesduweb\imagehosting\acp;

class imagehosting_info
{
	function module()
	{
		return array(
			'filename'	=> '\empreintesduweb\imagehosting\acp\imagehosting_module',
			'title'		=> 'ACP_EDW_IMAGEHOSTING_EXT_TITLE',
			'modes'		=> array(
				'general_settings'		=> array(
						'title' => 'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS',
						'auth' => 'ext_empreintesduweb/imagehosting && acl_a_board',
						'cat' => array('ACP_EDW_IMAGEHOSTING_EXT_TITLE')
					),
				'settings_edw'			=> array(
						'title' => 'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_EDW',
						'auth' => 'ext_empreintesduweb/imagehosting && acl_a_board',
						'cat' => array('ACP_EDW_IMAGEHOSTING_EXT_TITLE')
					),
				'settings_other'		=> array(
						'title' => 'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_OTHER',
						'auth' => 'ext_empreintesduweb/imagehosting && acl_a_board',
						'cat' => array('ACP_EDW_IMAGEHOSTING_EXT_TITLE')
					),
			),
		);
	}
}
