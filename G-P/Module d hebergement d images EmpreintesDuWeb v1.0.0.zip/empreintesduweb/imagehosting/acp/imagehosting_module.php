<?php
/**
*
* Image hosting EmpreintesDuWeb
*
* @copyright (c) 2015 EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace empreintesduweb\imagehosting\acp;

class imagehosting_module
{
	public $u_action;
	protected $new_config = array();
	protected $version_checking;
	protected $phpbb_container;

	public function __construct()
	{
		global $phpbb_container;
		$this->phpbb_container = $phpbb_container;

		$this->version_checking = $this->phpbb_container->get('empreintesduweb.imagehosting.version.check');
	}

	public function main($id, $mode)
	{
		global $config, $user, $template, $phpbb_container, $request;

		$this->page_title = 'ACP_EDW_IMAGEHOSTING_EXT_TITLE';
		$this->tpl_name = 'acp_imagehosting';

		$action = $request->variable('action', '');
		$submit = ($request->is_set_post('submit')) ? true : false;

		$form_key = 'imagehosting_module';
		add_form_key($form_key);

		$form_display = true;
		$error = array();

		switch ($mode)
		{
			case 'general_settings':

				// Cheking version
				$this->version_checking->check();

				$display_vars = array(
					'title'	=> 'ACP_EDW_IMAGEHOSTING_TITLE',
					'vars'	=> array(
						'legend1'	=> 'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_GENERAL',
							'edw_imagehosting_width'			=> array('lang' => 'ACP_EDW_IMAGEHOSTING_WIDTH', 'validate' => 'int:400:600', 'type' => 'number:400:600', 'explain' => true, 'append' => ' ' . $user->lang['PIXEL']),
							'edw_imagehosting_height'			=> array('lang' => 'ACP_EDW_IMAGEHOSTING_HEIGHT', 'validate' => 'int:100:200', 'type' => 'number:100:200', 'explain' => true, 'append' => ' ' . $user->lang['PIXEL']),
							'edw_imagehosting_align_center'	=> array('lang' => 'ACP_EDW_IMAGEHOSTING_ALIGN_CENTER', 'validate' => 'bool', 'type' => 'radio:yes_no', 'explain' => true),
							'edw_imagehosting_other_hosting'		=> array('lang' => 'ACP_EDW_IMAGEHOSTING_OTHER_HOSTING', 'validate' => 'bool', 'type' => 'radio:yes_no', 'explain' => true),
							'edw_imagehosting_iframe_active'		=> array('lang' => 'ACP_EDW_IMAGEHOSTING_IFRAME_ACTIVE', 'validate' => 'bool', 'type' => 'radio:yes_no', 'explain' => true),

						'legend2'	=> 'ACP_SUBMIT_CHANGES',
					),
				);

				break;

			case 'settings_edw':

				$display_vars = array(
					'title'	=> 'ACP_EDW_IMAGEHOSTING_TITLE',
					'vars'	=> array(
						'legend1'	=> 'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_MODULE_EDW',
							'edw_imagehosting_id'				=> array('lang' => 'ACP_EDW_IMAGEHOSTING_ID', 'validate' => 'int:0:1000000', 'type' => 'number:0:1000000', 'explain' => true),

						'legend2'	=> 'ACP_EDW_IMAGEHOSTING_COPY',
							'edw_imagehosting_copy'			=> array('lang' => 'ACP_EDW_IMAGEHOSTING_COPY', 'validate' => 'bool', 'type' => 'radio:yes_no', 'explain' => true),

						'legend3'	=> 'ACP_SUBMIT_CHANGES',
					),
				);

				// If another host using iframe
				if ($config['edw_imagehosting_other_hosting'])
				{
					$error[] = sprintf($user->lang['ACP_EDW_IMAGEHOSTING_ANOTHER_HOST'], $user->lang['ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_OTHER']);
					$form_display = false;
				}

				break;

			case 'settings_other':

				$display_vars = array(
					'title'	=> 'ACP_EDW_IMAGEHOSTING_TITLE',
					'vars'	=> array(
						'legend1'	=> 'ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_MODULE_OTHER',
							'edw_imagehosting_code_iframe'		=> array('lang' => 'ACP_EDW_IMAGEHOSTING_CODE_IFRAME', 'validate' => '', 'type' => 'textarea:10:300000', 'explain' => true),

						'legend2'	=> 'ACP_SUBMIT_CHANGES',
					),
				);

				// If another host using iframe
				if (!$config['edw_imagehosting_other_hosting'])
				{
					$error[] = sprintf($user->lang['ACP_EDW_IMAGEHOSTING_HOST_EDW'], $user->lang['ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_EDW']);
					$form_display = false;
				}

				break;

			default:
				trigger_error('NO_MODE', E_USER_ERROR);
				break;
		}

		if (isset($display_vars['lang']))
		{
			$user->add_lang($display_vars['lang']);
		}

		$this->new_config = $config;

		$cfg_array = ($request->is_set('config')) ? utf8_normalize_nfc($request->variable('config', array('' => ''), true)) : $this->new_config;

		// We validate the complete config if wished
		validate_config_vars($display_vars['vars'], $cfg_array, $error);

		if ($submit && !check_form_key($form_key))
		{
			$error[] = $user->lang['FORM_INVALID'];
		}

		// Do not write values if there is an error
		if (sizeof($error))
		{
			$submit = false;
		}

		// Config Text..
		$config_text = $phpbb_container->get('config_text');

		// We go through the display_vars to make sure no one is trying to set variables he/she is not allowed to...
		foreach ($display_vars['vars'] as $config_name => $null)
		{
			if (!isset($cfg_array[$config_name]) || strpos($config_name, 'legend') !== false)
			{
				continue;
			}

			$this->new_config[$config_name] = $config_value = $cfg_array[$config_name];

			if ($submit)
			{
				// Config Text Add to DB..
				if ($config_name == 'edw_imagehosting_code_iframe')
				{
					$config_text->set_array(array($config_name => $config_value));
				}
				else
				{
					$config->set($config_name, $config_value);
				}
			}
		}

		if ($submit)
		{
			trigger_error($user->lang['CONFIG_UPDATED'] . adm_back_link($this->u_action));
		}

		$template->assign_vars(array(
			'S_ERROR'			=> (sizeof($error)) ? true : false,
			'ERROR_MSG'			=> implode('<br />', $error),
			'FORM_KEY'			=> $form_key,
			'S_FORM_DISPLAY'	=> ($form_display) ? true : false,
		));
		
		// Output relevant page
		foreach ($display_vars['vars'] as $config_key => $vars)
		{
			if (!is_array($vars) && strpos($config_key, 'legend') === false)
			{
				continue;
			}

			if (strpos($config_key, 'legend') !== false)
			{
				$template->assign_block_vars('options', array(
					'S_LEGEND'		=> true,
					'LEGEND'		=> (isset($user->lang[$vars])) ? $user->lang[$vars] : $vars)
				);

				continue;
			}

			$type = explode(':', $vars['type']);

			$l_explain = '';
			if ($vars['explain'] && isset($vars['lang_explain']))
			{
				$l_explain = (isset($user->lang[$vars['lang_explain']])) ? $user->lang[$vars['lang_explain']] : $vars['lang_explain'];
			}
			else if ($vars['explain'])
			{
				$l_explain = (isset($user->lang[$vars['lang'] . '_EXPLAIN'])) ? $user->lang[$vars['lang'] . '_EXPLAIN'] : '';

				if ($l_explain === $user->lang['ACP_EDW_IMAGEHOSTING_OTHER_HOSTING_EXPLAIN'])
				{
					$l_explain = sprintf($user->lang['ACP_EDW_IMAGEHOSTING_OTHER_HOSTING_EXPLAIN'], $user->lang['ACP_EDW_IMAGEHOSTING_TITLE_SETTINGS_OTHER']);
				}
				else if ($l_explain === $user->lang['ACP_EDW_IMAGEHOSTING_CODE_IFRAME_EXPLAIN'])
				{
					$l_explain = sprintf($user->lang['ACP_EDW_IMAGEHOSTING_CODE_IFRAME_EXPLAIN'], $user->lang['ACP_EDW_IMAGEHOSTING_OTHER_HOSTING']);
				}
			}

			$l_description = (isset($user->lang[$vars['lang'] . '_DESCRIPTION'])) ? $user->lang[$vars['lang'] . '_DESCRIPTION'] : '';

			// Config Text in display..
			if ($config_key == 'edw_imagehosting_code_iframe')
			{
				$this->new_config[$config_key] = $config_text->get($config_key);
			}

			$content = build_cfg_template($type, $config_key, $this->new_config, $config_key, $vars);

			if (empty($content))
			{
				continue;
			}

			$template->assign_block_vars('options', array(
				'KEY'					=> $config_key,
				'TITLE'					=> (isset($user->lang[$vars['lang']])) ? $user->lang[$vars['lang']] : $vars['lang'],
				'S_EXPLAIN'				=> $vars['explain'],
				'TITLE_EXPLAIN'			=> $l_explain,
				'TITLE_DESCRIPTION'		=> $l_description,
				'CONTENT'				=> $content,
				)
			);

			unset($display_vars['vars'][$config_key]);
		}
	}
}
