<?php
/**
*
* Image hosting EmpreintesDuWeb
*
* @copyright (c) 2015 EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace empreintesduweb\imagehosting\controller;

/**
* popup_controller_another_hoster
*/
class popup_controller_another_hoster
{
	protected $helper;
	protected $user;
	protected $template;
	protected $config_text;

	public function __construct(\phpbb\controller\helper $helper, \phpbb\user $user, \phpbb\template\template $template, \phpbb\config\db_text $config_text)
	{
		$this->helper = $helper;
		$this->user = $user;
		$this->template = $template;
		$this->config_text = $config_text;
	}

	public function display()
	{
		// Add language file
		$this->user->add_lang_ext('empreintesduweb/imagehosting', 'forum_imagehosting');

		$this->template->assign_vars(array(
			'EDW_IMAGEHOSTING_CODE_IFRAME'			=> html_entity_decode($this->config_text->get('edw_imagehosting_code_iframe')),
		));

		// Send all data to the template file
		return $this->helper->render('edw_imagehosting_another_hoster.html');
	}
}
