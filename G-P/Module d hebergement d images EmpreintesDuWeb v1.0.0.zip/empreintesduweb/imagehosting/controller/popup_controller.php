<?php
/**
*
* Image hosting EmpreintesDuWeb
*
* @copyright (c) 2015 EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace empreintesduweb\imagehosting\controller;

/**
* popup_controller
*/
class popup_controller
{
	protected $helper;

	public function __construct(\phpbb\controller\helper $helper)
	{
		$this->helper = $helper;
	}

	public function display()
	{
		// Send all data to the template file
		return $this->helper->render('edw_image_hosting.html');
	}
}
