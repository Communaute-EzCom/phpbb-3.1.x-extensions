<?php
/**
*
* Image hosting EmpreintesDuWeb
*
* @copyright (c) 2015 EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace empreintesduweb\imagehosting\includes;

class version_checking
{
	protected $version_extension_imagehosting;
	protected $config;
	protected $version_helper;
	protected $template;
	protected $user;
	protected $current_version;

	public function __construct($version_extension_imagehosting, $config, $version_helper, $template, $user)
	{
		$this->version_extension_imagehosting = $version_extension_imagehosting;
		$this->config = $config;
		$this->version_helper = $version_helper;
		$this->template = $template;
		$this->user = $user;
		$this->current_version = $this->config[str_replace(' ', '', $this->version_extension_imagehosting['version'])];
	}

	/**
	* Check extension version
	*/
	public function check($return_version = false)
	{
		// Set file location
		$this->version_helper->set_file_location($this->version_extension_imagehosting['file'][0], $this->version_extension_imagehosting['file'][1], $this->version_extension_imagehosting['file'][2]);

		// Set current version
		$this->version_helper->set_current_version($this->current_version);

		$this->version_helper->force_stability(($this->config['extension_force_unstable'] || !$this->version_helper->is_stable($this->current_version)) ? 'unstable' : null);

		$updates = $this->version_helper->get_suggested_updates(true);

		// Return version if $return_version is set to true
		if ($return_version)
		{
			return $this->current_version;
		}

		$version_up_to_date = empty($updates);

		$template_data = array(
			'CURRENT_VERSION'	=> $this->current_version,
			'UP_TO_DATE'		=> sprintf((!$version_up_to_date) ? $this->user->lang['ACP_EDW_NOT_UP_TO_DATE'] : $this->user->lang['ACP_EDW_UP_TO_DATE'], $this->user->lang['ACP_EDW_IMAGEHOSTING_EXT_TITLE']),
			'S_UP_TO_DATE'		=> $version_up_to_date,
			'TITLE'				=> (string) $this->user->lang['ACP_EDW_IMAGEHOSTING_EXT_TITLE'],
		);

		if (!$version_up_to_date)
		{
			$updates = array_shift($updates);
			$template_data = array_merge($template_data, array(
				'ANNOUNCEMENT'		=> (string) $updates['announcement'],
				'DOWNLOAD'			=> (string) $updates['download'],
				'LATEST_VERSION'	=> $updates['current'],
			));
		}
		$this->template->assign_block_vars('check_imagehosting', $template_data);
	}
}
