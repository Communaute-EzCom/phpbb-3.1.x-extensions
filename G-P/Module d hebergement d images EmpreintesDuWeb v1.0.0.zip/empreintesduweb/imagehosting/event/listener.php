<?php
/**
*
* Image hosting EmpreintesDuWeb
*
* @copyright (c) 2015 EmpreintesDuWeb http://www.empreintesduweb.com
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace empreintesduweb\imagehosting\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class listener implements EventSubscriberInterface
{
	protected $config;
	protected $template;
	protected $user;
	protected $config_text;
	protected $auth;
	protected $helper;

	public function __construct(\phpbb\config\config $config, \phpbb\template\template $template, \phpbb\user $user, \phpbb\config\db_text $config_text, \phpbb\auth\auth $auth, \phpbb\controller\helper $helper)
	{
		$this->config = $config;
		$this->template = $template;
		$this->user = $user;
		$this->config_text = $config_text;
		$this->auth = $auth;
		$this->helper = $helper;
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.posting_modify_template_vars' => 'assign_to_template',

			// ACP event
			'core.permissions'	=> 'add_permission',
		);
	}

	public function add_permission($event)
	{
		$permissions = $event['permissions'];
		$permissions['u_edw_imagehosting_active'] = array('lang' => 'EDW_IMAGEHOSTING_ACTIVE_USER', 'cat' => 'misc');
		$event['permissions'] = $permissions;
	}

	public function assign_to_template()
	{
		// Add language file
		$this->user->add_lang_ext('empreintesduweb/imagehosting', 'forum_imagehosting');

		$edw_imagehosting_code_iframe = $this->config_text->get('edw_imagehosting_code_iframe');

		$this->template->assign_vars(array(
			'EDW_IMAGEHOSTING_ID'					=> $this->config['edw_imagehosting_id'],
			'EDW_IMAGEHOSTING_WIDTH'				=> $this->config['edw_imagehosting_width'],
			'EDW_IMAGEHOSTING_HEIGHT'				=> $this->config['edw_imagehosting_height'],
			'EDW_IMAGEHOSTING_CODE_IFRAME'			=> html_entity_decode($edw_imagehosting_code_iframe),

			'S_EDW_IMAGEHOSTING_ACTIVE_IFRAME'		=> $this->config['edw_imagehosting_iframe_active'],
			'S_EDW_IMAGEHOSTING_ALIGN_CENTER'		=> $this->config['edw_imagehosting_align_center'],
			'S_EDW_IMAGEHOSTING_COPY'				=> $this->config['edw_imagehosting_copy'],
			'S_EDW_IMAGEHOSTING_OTHER_HOSTING'		=> $this->config['edw_imagehosting_other_hosting'],
			'S_EDW_IMAGEHOSTING_ACTIVE_USER'		=> $this->auth->acl_get('u_edw_imagehosting_active'),
			'S_EDW_IMAGEHOSTING_ACTIVE_POPUP'		=> (!$this->config['edw_imagehosting_other_hosting'] || ($this->config['edw_imagehosting_other_hosting'] && !empty($edw_imagehosting_code_iframe))) ? true : false,

			'U_ANOTHER_HOSTER'						=> $this->helper->route('empreintesduweb_imagehosting_popup_controller_another_hoster'),
		));
	}
}

?>