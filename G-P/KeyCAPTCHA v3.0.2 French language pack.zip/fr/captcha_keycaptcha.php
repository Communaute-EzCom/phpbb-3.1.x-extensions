<?php
/**
*
* KeyCAPTCHA extension for the phpBB Forum Software package.
* French translation by Galixte (http://www.galixte.com)
*
* @copyright (c) 2016 KeyCAPTCHA Team <https://keycaptcha.com>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'KEYCAPTCHA_TASK'				=> 'Anti-spam :',
	'KEYCAPTCHA_LANG'				=> 'fr',
	'KEYCAPTCHA_NOT_AVAILABLE'		=> 'Avant d’utiliser l’extension : « KeyCAPTCHA », il est nécessaire de créer un compte sur le site Web : <a href="https://keycaptcha.com">keycaptcha.com</a>.',
	'CAPTCHA_KEYCAPTCHA'				=> 'KeyCAPTCHA',
	'KEYCAPTCHA_INCORRECT'			=> 'La solution pour le KeyyCAPTCHA est incorrecte. Merci de recommencer !',
	'KEYCAPTCHA_PRIVATE'				=> 'Clé privée KeyCAPTCHA',
	'KEYCAPTCHA_PRIVATE_EXPLAIN'		=> 'Ceci est la clé privée KeyCAPTCHA. Les clés peuvent être obtenues sur le site Web : <a href="https://keycaptcha.com">keycaptcha.com</a> dans la section : "Site list" de la zone membre : « For Site Owners ».',
	'KEYCAPTCHA_MESSAGE_NOSCRIPT'	=> '<b>Il est nécessaire d’activer le langage JavaScript dans le navigateur, puis de recharger la page.<br />Auquel cas contraire, aucune information ne sera en mesure d’être affichée sur ce site Web.</b>.',
	'KEYCAPTCHA_EXPLAIN'				=> 'Terminer la tâche',
	'KEYCAPTCHA_SOCKET_ERROR'		=> 'Il y a eu une problème de connexion au service KEYCAPTCHA : « Impossibilité d’établir une connexion réseau. Merci de recommencer. ».',
));
