<?php
/**
*
* @package Joined Date Format Extension
* @copyright (c) 2015 david63
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace david63\joineddate;

class ext extends \phpbb\extension\base
{
	const JOINED_DATE_FORMAT_VERSION = '1.0.1';
}
