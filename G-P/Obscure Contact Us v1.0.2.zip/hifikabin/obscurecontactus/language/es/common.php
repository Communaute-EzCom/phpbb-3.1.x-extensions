<?php
/**
*
* @package phpBB Extension - Obscure Contact Us
* @copyright (c) 2015 - HiFiKabin
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
   exit;
}

if (empty($lang) || !is_array($lang))
{
   $lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(
   'ACP_OBSCURECONTACTUS_CONFIG'           	=> 'Obscure Contact Us',
   'ACP_OBSCURECONTACTUS_CONFIG_EXPLAIN'      	=> 'Esta es la página de configuración de la extensión Obscure Contact Us. </br>Se muestra su dirección de correo electrónico usando javascript que lo hace invisible a los rastreadores web.',
   'OBSCURECONTACTUS_VERSION'              	=> 'Versión',
   'ACP_OBSCURECONTACTUS_CONFIG_SET'       	=> 'Configuración',
   'OBSCURECONTACTUS_CONFIG_SAVED'         	=> 'Ajustes de Obscure Contact Us guardados',

   'OBSCURECONTACTUS_MOUSEOVER'              	=> 'En Mouseover',
   'OBSCURECONTACTUS_MOUSEOVER_EXPLAIN'         => 'El texto que será mostrado al hacer hover en el enlace “Contáctenos” . Deje esto en blanco si no desea mostrar texto en mouseover',

   'OBSCURECONTACTUS_PREFIX'              	=> 'Prefijo del Email',
   'OBSCURECONTACTUS_PREFIX_EXPLAIN'         	=> 'La parte de su dirección de correo electrónico que viene antes de la @',
   'OBSCURECONTACTUS_PREFIX_PLACEHOLDER'        => 'nombre',

   'OBSCURECONTACTUS_SUBJECT'              	=> 'Asunto del Email',
   'OBSCURECONTACTUS_SUBJECT_EXPLAIN'         	=> 'Rellena la línea de asunto del correo electrónico. Dejar en blanco para ningún asunto',

   'OBSCURECONTACTUS_SUFFIX'          		=> 'Sufijo del Email',
   'OBSCURECONTACTUS_SUFFIX_EXPLAIN'     	=> 'La parte de su dirección de correo electrónico que viene después de la @',
   'OBSCURECONTACTUS_SUFFIX_PLACEHOLDER'        => 'dirección.com',

));
