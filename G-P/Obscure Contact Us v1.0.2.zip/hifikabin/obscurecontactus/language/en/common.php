<?php
/**
*
* @package phpBB Extension - Obscure Contact Us
* @copyright (c) 2015 - HiFiKabin
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
   exit;
}

if (empty($lang) || !is_array($lang))
{
   $lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(
   'ACP_OBSCURECONTACTUS_CONFIG'           => 'Obscure Contact Us',
   'ACP_OBSCURECONTACTUS_CONFIG_EXPLAIN'   => 'This is configuration page for the Obscure Contact Us extension. </br>Your email address is displayed using javascript which makes it invisible to Web Crawlers.',
   'OBSCURECONTACTUS_VERSION'              => 'Version',
   'ACP_OBSCURECONTACTUS_CONFIG_SET'       => 'Configuration',
   'OBSCURECONTACTUS_CONFIG_SAVED'         => 'Obscure Contact Us settings saved',

   'OBSCURECONTACTUS_MOUSEOVER'            => 'On Mouseover',
   'OBSCURECONTACTUS_MOUSEOVER_EXPLAIN'    => 'The text that shows when you hover on the “Contact Us” link. Leave empty if you do not want any text to show on mouseover',

   'OBSCURECONTACTUS_PREFIX'               => 'Email Prefix',
   'OBSCURECONTACTUS_PREFIX_EXPLAIN'       => 'The part of your email address that comes before the @',
   'OBSCURECONTACTUS_PREFIX_PLACEHOLDER'   => 'name',

   'OBSCURECONTACTUS_SUBJECT'              => 'Email Subject',
   'OBSCURECONTACTUS_SUBJECT_EXPLAIN'      => 'Fills in the subject line of the email. Leave empty for no subject',

   'OBSCURECONTACTUS_SUFFIX'               => 'Email Suffix',
   'OBSCURECONTACTUS_SUFFIX_EXPLAIN'       => 'The part of your email address that comes after the @',
   'OBSCURECONTACTUS_SUFFIX_PLACEHOLDER'   => 'address.com',

));
