<?php
/**
*
* @package phpBB Extension - Obscure Contact Us
* @copyright (c) 2015 - HiFiKabin
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace hifikabin\obscurecontactus\acp;

class obscurecontactus_module
{
var $u_action;

	function main($id, $mode)
	{
	global $db, $user, $auth, $template, $cache, $request;
	global $config, $phpbb_root_path, $phpbb_admin_path, $phpEx;

	$this->tpl_name = 'acp_obscurecontactus_config';
	$this->page_title = $user->lang['OBSCURECONTACTUS_CONFIG'];
	add_form_key('acp_obscurecontactus_config');

	$submit = $request->is_set_post('submit');
	if ($submit)
	{
		if (!check_form_key('acp_obscurecontactus_config'))
		{
		trigger_error('FORM_INVALID');
		}
		$config->set('obscurecontactus_mouseover', utf8_normalize_nfc($request->variable('obscurecontactus_mouseover', '', true)));
		$config->set('obscurecontactus_prefix', utf8_normalize_nfc($request->variable('obscurecontactus_prefix', '', true)));
		$config->set('obscurecontactus_subject', utf8_normalize_nfc($request->variable('obscurecontactus_subject', '', true)));
		$config->set('obscurecontactus_suffix', utf8_normalize_nfc($request->variable('obscurecontactus_suffix', '', true)));
		trigger_error($user->lang['OBSCURECONTACTUS_CONFIG_SAVED'] . adm_back_link($this->u_action));
		}
		$template->assign_vars(array(
		'OBSCURECONTACTUS_MOUSEOVER'		=> (isset($config['obscurecontactus_mouseover'])) ? $config['obscurecontactus_mouseover'] : '',
		'OBSCURECONTACTUS_PREFIX'		=> (isset($config['obscurecontactus_prefix'])) ? $config['obscurecontactus_prefix'] : '',
		'OBSCURECONTACTUS_SUBJECT'		=> (isset($config['obscurecontactus_subject'])) ? $config['obscurecontactus_subject'] : '',
		'OBSCURECONTACTUS_SUFFIX'		=> (isset($config['obscurecontactus_suffix'])) ? $config['obscurecontactus_suffix'] : '',
		'OBSCURECONTACTUS_VERSION'		=> (isset($config['obscurecontactus_version'])) ? $config['obscurecontactus_version'] : '',
		'U_ACTION'				=> $this->u_action,
		));
	}
}
