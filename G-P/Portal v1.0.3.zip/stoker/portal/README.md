"Portal" extension for phpBB 3.1
======
Simple Portal page

Author: Ulrik Christensen

URL: http://www.phpbb3bbcodes.com

Version: v1.0.3 

## Install instructions:
1. Download the extension
2. Copy the whole archive content to: phpBB/ext/stoker/portal
3. Go to your phpBB-Board --> Admin Control Panel --> Customise --> Manage extensions --> Portal: Enable
4. A new tab "Extension" appears, where you setup the "Portal" page. 

## Update instructions:
1. Go to you phpBB-Board > Admin Control Panel > Customise > Manage extensions > Portal: disable
2. Delete all files of the extension from phpBB/ext/stoker/portal
3. Upload all the new files to the same locations
4. Go to you phpBB-Board > Admin Control Panel > Customise > Manage extensions > Portal: enable
5. Purge the board cache