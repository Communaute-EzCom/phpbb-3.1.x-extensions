<?php
/**
*
* @package phpBB Extension - Stoker Portal
* @copyright (c) 2015 Stoker www.phpbb3bbcodes.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace stoker\portal\acp;

class acp_portal_info
{
	function module()
	{
		return array(
			'filename'	=> '\stoker\portal\acp\acp_portal_module',
			'title'		=> 'ACP_PORTAL_SETTINGS',
			'version'	=> '1.0.3',
			'modes'		=> array(
			'config_portal'	=> array('title' => 'ACP_PORTAL_SETTINGS', 'auth' => 'ext_stoker/portal && acl_a_board', 'cat' => array('ACP_PORTAL_SETTINGS')),
			),
		);
	}
}
