<?php
/**
*
* @package phpBB Extension - Stoker Portal
* @copyright (c) 2015 Stoker www.phpbb3bbcodes.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*/

namespace stoker\portal\acp;

/**
* @ignore
*/


/**
* @package acp
*/
class acp_portal_module
{
	public $u_action;

	public function main($id, $mode)
	{
		global $user, $request, $template;
		global $config, $phpbb_root_path, $phpEx, $phpbb_container; 
		
		$user->add_lang(array('acp/board', 'posting'));
		
		$this->tpl_name = 'acp_portal';
		$this->page_title = 'PORTAL_SETTINGS';
		
		$form_name = 'PORTAL_setting';
		add_form_key($form_name);
		$error = '';
		
		if (!function_exists('display_custom_bbcodes'))
		{
			include($phpbb_root_path . 'includes/functions_display.' . $phpEx);
		}
		
		if (!class_exists('parse_message'))
		{
			include($phpbb_root_path . 'includes/message_parser.' . $phpEx);
		}
		$config_text = $phpbb_container->get('config_text');
		$portal_data	= $config_text->get_array(array(
		'portal_info',
		'portal_info_uid',
		'portal_info_bitfield',
		'portal_info_flags',
		));
		
		$portal_info	= $portal_data['portal_info'];
		$portal_info_uid	= $portal_data['portal_info_uid'];
		$portal_info_bitfield= $portal_data['portal_info_bitfield'];
		$portal_info_flags	= $portal_data['portal_info_flags'];
		
		if ($request->is_set_post('submit') || $request->is_set_post('preview'))
		{
			if (!check_form_key($form_name))
			{
				$error = $user->lang('FORM_INVALID');
			}
			$portal_info = $request->variable('portal_info', '', true);
			generate_text_for_storage(
				$portal_info,
				$portal_info_uid,
				$portal_info_bitfield,
				$portal_info_flags,
				!$request->variable('disable_bbcode', false),
				!$request->variable('disable_magic_url', false),
				!$request->variable('disable_smilies', false)
			);
			if (empty($error) && $request->is_set_post('submit'))
			{
				$config->set('acp_portal_enable', $request->variable('acp_portal_enable', false));

				$config_text->set_array(array(
				'portal_info'	=> $portal_info,
				'portal_info_uid'	=> $portal_info_uid,
				'portal_info_bitfield'	=> $portal_info_bitfield,
				'portal_info_flags'	=> $portal_info_flags,
				));
				trigger_error($user->lang['PORTAL_UPDATED'] . adm_back_link($this->u_action));
			}
		}
		
		$portal_info_preview = '';
		
		if ($request->is_set_post('preview'))
		{
			$portal_info_preview = generate_text_for_display($portal_info, $portal_info_uid, $portal_info_bitfield, $portal_info_flags);
		}
		$portal_edit = generate_text_for_edit($portal_info, $portal_info_uid, $portal_info_flags);
		
		$template->assign_vars(array(
			'ERRORS'						=> $error,
			'ACP_PORTAL_INFO'				=> $portal_edit['text'],
			'ACP_PORTAL_INFO_PREVIEW'		=> $portal_info_preview,
			'PORTAL_ENABLE'					=> $config['acp_portal_enable'],
			'S_BBCODE_DISABLE_CHECKED'		=> !$portal_edit['allow_bbcode'],
			'S_SMILIES_DISABLE_CHECKED'		=> !$portal_edit['allow_smilies'],
			'S_MAGIC_URL_DISABLE_CHECKED'	=> !$portal_edit['allow_urls'],
			'BBCODE_STATUS'					=> $user->lang('BBCODE_IS_ON', '<a href="' . append_sid("{$phpbb_root_path}faq.$phpEx", 'mode=bbcode') . '">', '</a>'),
			'SMILIES_STATUS'				=> $user->lang['SMILIES_ARE_ON'],
			'IMG_STATUS'					=> $user->lang['IMAGES_ARE_ON'],
			'FLASH_STATUS'					=> $user->lang['FLASH_IS_ON'],
			'URL_STATUS'					=> $user->lang['URL_IS_ON'],
			'S_BBCODE_ALLOWED'				=> true,
			'S_SMILIES_ALLOWED'				=> true,
			'S_BBCODE_IMG'					=> true,
			'S_BBCODE_FLASH'				=> true,
			'S_LINKS_ALLOWED'				=> true,
		));
	// Assigning custom bbcodes
	display_custom_bbcodes();
	}
}
