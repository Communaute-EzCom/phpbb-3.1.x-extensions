<?php
/**
*
* @package phpBB Extension - Stoker Portal
* @copyright (c) 2015 Stoker www.phpbb3bbcodes.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace stoker\portal\controller;

/**
* @ignore
*/

class main
{
	/* @var \phpbb\config\config */
	protected $config;

	/* @var \phpbb\config\db_text */
	protected $config_text;

	/* @var \phpbb\controller\helper */
	protected $helper;

	/* @var \phpbb\template\template */
	protected $template;

	/* @var \phpbb\user */
	protected $user;

	/* @var string phpEx */
	protected $php_ext;
	/**
	* Constructor
	*
	* @param \phpbb\config\config		$config
	* @param \phpbb\config\db_text		$config_text
	* @param \phpbb\controller\helper	$helper
	* @param \phpbb\template\template	$template
	* @param \phpbb\user				$user
	* @param string						$php_ext	phpEx
	*/
	public function __construct(\phpbb\config\config $config, \phpbb\config\db_text $config_text, \phpbb\controller\helper $helper, \phpbb\template\template $template, \phpbb\user $user, $php_ext)
	{
		$this->config 	= $config;
		$this->helper 	= $helper;
		$this->template = $template;
		$this->user 	= $user;
		$this->php_ext 	= $php_ext;
		$this->config_text = $config_text;
	}

	/**
	* Controller for route app.php/portal.php and /portal
	*
	* @return Symfony\Component\HttpFoundation\Response A Symfony Response object
	*/
	public function base()
	{		
		$portal_data			= $this->config_text->get_array(array(
				'portal_info',
				'portal_info_uid',
				'portal_info_bitfield',
				'portal_info_flags',
		));

		$portal_text = generate_text_for_display(
			$portal_data['portal_info'],
			$portal_data['portal_info_uid'],
			$portal_data['portal_info_bitfield'],
			$portal_data['portal_info_flags']
		);

		$this->template->assign_vars(array(
			'PORTAL_OUTPUT'	=> $portal_text,
			'PORTAL_ENABLE'	=> $this->config['acp_portal_enable'],
		));

		return $this->helper->render('portal_body.html', $this->user->lang('PORTAL'));
	}

	public function redirect()
	{
		redirect($this->helper->route('stoker_portal'));
	}

}