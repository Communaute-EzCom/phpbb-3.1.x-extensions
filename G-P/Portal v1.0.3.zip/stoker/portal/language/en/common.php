<?php
/**
*
* @package phpBB Extension - Stoker Portal
* @copyright (c) 2015 Stoker www.phpbb3bbcodes.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'PORTAL'							=> 'Portal',
	'PORTAL_SETTINGS'					=> 'Portal settings',
	'PORTAL_UPDATED'					=> 'Portal was successfully updated.',
	'PORTAL_NOTHING'					=> 'Currently nothing to see here',

	'ACP_PORTAL_ENABLE'					=> 'Portal',
	'ACP_PORTAL_ENABLE_EXPLAIN'			=> 'If the "Portal" page is disabled, your board will not show a link in the header to the "Portal" page. Nevertheless with the url "app.php/portal.php" you are able to visit the "Portal" page.',
	'ACP_PORTAL_INFO'					=> 'Portal text',
	'ACP_PORTAL_INFO_EXPLAIN'			=> 'You can edit the text which is displayed on the Portal page.',
	'ACP_PORTAL_INFO_PREVIEW'			=> 'Portal Preview',
	'ACP_PORTAL_SETTINGS'				=> 'Portal settings',
	'ACP_PORTAL_SETTINGS_EXPLAIN'		=> 'Here you are able to define the text of the "Portal" page and enable or disable the "Portal" page.',

	'VIEWONLINE_PORTAL'					=> 'Viewing Portal',
));
