<?php
/**
*
* @package phpBB Extension - Stoker Portal
* @copyright (c) 2015 Stoker www.phpbb3bbcodes.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/
namespace stoker\portal\migrations;

class stoker_portal_migrations extends \phpbb\db\migration\migration
{
	public function effectively_installed()
	{
		return isset($this->config['portal_enable']);
	}

	public function update_data()
	{
		return array(
			array('config.add', array('portal_enable', false)),
			array('config_text.add', array('portal_info', '')),
			array('config_text.add', array('portal_info_uid', '')),
			array('config_text.add', array('portal_info_bitfield', '')),
			array('config_text.add', array('portal_info_flags', OPTION_FLAG_BBCODE + OPTION_FLAG_SMILIES + OPTION_FLAG_LINKS)),
			array('module.add', array('acp', 'ACP_CAT_DOT_MODS','ACP_PORTAL_SETTINGS')),
			array('module.add', array('acp', 'ACP_PORTAL_SETTINGS', array(
				'module_basename' => '\stoker\portal\acp\acp_portal_module',
				'modes' => array('config_portal'),
			))),
		);
	}
}
