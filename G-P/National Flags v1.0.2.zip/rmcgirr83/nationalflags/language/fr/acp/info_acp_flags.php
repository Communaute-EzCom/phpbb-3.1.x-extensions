<?php
/**
*
* National Flags extension for the phpBB Forum Software package.
* French translation by Galixte (http://www.galixte.com)
*
* @copyright (c) 2015 RMcGirr83
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	//Module and page titles
	'ACP_CAT_FLAGS'						=> 'Drapeaux nationaux',
	'ACP_FLAGS'							=> 'Drapeaux nationaux',
	'ACP_FLAGS_EXPLAIN'					=> 'Sur cette page il est possible d’ajouter, modifier et supprimer les différents drapeaux. <strong>Pour utiliser des images celles-ci doivent être téléchargées dans le répertoire : ext/rmcgirr83/nationalflags/flags avant d’ajouter de nouveaux drapeaux.  L’image du drapeau doit avoir un nom composé uniquement de lettres en minuscule, par exemple, fr.gif.</strong>',
	'ACP_FLAGS_DONATE'					=> 'Pour soutenir de développement de cette extension, il est possible de faire un <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=S4UTZ9YNKEDDN" onclick="window.open(this.href); return false;"><strong>don</strong></a>.',
	'ACP_FLAG_USERS'					=> 'Nombre d’utilisateurs',

	//Add/Edit Flags
	'FLAG_EDIT'							=> 'Modifier un drapeau',
	'FLAG_NAME'							=> 'Nom du drapeau',
	'FLAG_NAME_EXPLAIN'					=> 'Le nom du drapeau. Le titre du drapeau sera affiché comme indiqué ici.',
	'FLAG_IMG'							=> 'Nom de l’image',
	'FLAG_IMG_EXPLAIN'					=> 'Le nom de l’image. Exemple : fr.gif. Les nouvelles images doivent être téléchargées dans le répertoire : ext/rmcgirr83/nationalflags/flags.',
	'FLAG_IMAGE'						=> 'Image du drapeau',
	'FLAG_ADD'							=> 'Ajouter un nouveau drapeau',

	//Settings
	'ACP_FLAG_SETTINGS'					=> 'Paramètres des drapeaux nationaux',
	'YES_FLAGS'							=> 'Activer les drapeaux',
	'YES_FLAGS_EXPLAIN'					=> 'Permet de d’activer ou de désactiver les drapeaux.',
	'FLAGS_VERSION'						=> 'Version',
	'FLAGS_REQUIRED'					=> 'Champ obligatoire',
	'FLAGS_REQUIRED_EXPLAIN'			=> 'Permet d’obliger à sélectionner son drapeau aux nouveaux utilisateurs enregistrés et aux utilisateurs qui consultent leur profil.',
	'FLAGS_DISPLAY_MSG'					=> 'Afficher un message',
	'FLAGS_DISPLAY_MSG_EXPLAIN'			=> 'Permet d’afficher un message demandant à sélectionner un drapeau aux utilisateurs.',
	'FLAGS_NUM_DISPLAY'					=> 'Nombre de drapeaux',
	'FLAGS_NUM_DISPLAY_EXPLAIN'			=> 'Permet de saisir le nombre de drapeaux à afficher sur la page de l’index du forum.',
	'FLAGS_ON_INDEX'					=> 'Afficher sur l’index',
	'FLAGS_ON_INDEX_EXPLAIN'			=> 'Permet d’afficher les drapeaux des utilisateurs sur la page de l’index du forum.',

	//Logs, messages and errors
	'LOG_FLAGS_DELETED'					=> '<strong>Un drapeau a été supprimé</strong><br />» %1$s',
	'LOG_FLAG_EDIT'						=> '<strong>Un drapeau a été mis à jour</strong><br />» %1$s',
	'LOG_FLAG_ADD'						=> '<strong>Un drapeau a été ajouté</strong><br />» %1$s',
	'MSG_FLAGS_DELETED'					=> 'Ce drapeau a été supprimé.',
	'MSG_CONFIRM'						=> 'Êtes-vous sûr de vouloir supprimer ce drapeau ?',
	'MSG_FLAG_CONFIRM_DELETE'			=> '<br />L’utilisateur <strong>%d</strong> a sélectionné ce drapeau et devra en choisir un autre si celui-ci est supprimé.',
	'MSG_FLAGS_CONFIRM_DELETE'			=> '<br />Les utilisateurs <strong>%d</strong> ont sélectionné ce drapeau et devront en choisir un autre si celui-ci est supprimé.',
	'MSG_FLAG_EDITED'					=> 'Le drapeau a été modifié.',
	'MSG_FLAG_ADDED'					=> 'Le nouveau drapeau a été ajouté.',
	'FLAG_ERROR_NO_FLAG_NAME'			=> 'Aucun nom de drapeau indiqué, ceci est un champ obligatoire.',
	'FLAG_ERROR_NO_FLAG_IMG'			=> 'Aucune image de drapeau indiquée, ceci est un champ obligatoire.',
	'FLAG_ERROR_NOT_EXIST'				=> 'Le drapeau sélectionné n’existe pas.',
	'FLAG_CONFIG_SAVED'					=> '<strong>Les paramètres des drapeaux nationaux ont été modifiés.</strong>',
	'FLAG_NAME_EXISTS'					=> 'Un drapeau portant ce nom existe déjà',
	'FLAG_SETTINGS_CHANGED'				=> 'Les paramètres des drapeaux nationaux ont été modifiés.',
));
