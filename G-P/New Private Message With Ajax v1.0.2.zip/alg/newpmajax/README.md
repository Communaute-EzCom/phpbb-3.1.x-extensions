newpmajax
==========

The extension makes it possible to add and remove recipients of PM without reloading the page
[![Build Status](https://travis-ci.org/alg5/newpmajax.svg?branch=master)](https://travis-ci.org/alg5/newpmajax)

Supported languages:
- English
- French
- Russian

### License
[GNU General Public License v2](http://opensource.org/licenses/GPL-2.0)

