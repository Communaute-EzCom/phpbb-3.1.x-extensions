PM Search
===========

PM search is phpBB 3.1 extension that allows users to search trough the PM archive in the board.

Features
--

  ACP
  
    - Enable PM Indexing
    - GLobaly allow PM search
    - Individual user permissions to allow PM Search
    - Indexing statistics
    - Build/delete Indexing statistics
  
  UCP
  
    - New UCP module for search
	
  Events
  
    - Register every PM for indexing
	- Remove PM removes index
    
    
Travis-ci state:

[![Build Status](https://travis-ci.org/lucifer4o/pmsearch.svg?branch=master)](https://travis-ci.org/lucifer4o/pmsearch)
