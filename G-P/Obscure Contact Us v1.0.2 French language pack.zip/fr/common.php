<?php
/**
*
* Obscure Contact Us extension for the phpBB Forum Software package.
* French translation by Galixte (http://www.galixte.com)
*
* @copyright (c) 2015 HiFiKabin <http://phpbb.hifikabin.me.uk>
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
   'ACP_OBSCURECONTACTUS_CONFIG'           => 'Paramètres de l’anti-span pour « Nous contacter »',
   'ACP_OBSCURECONTACTUS_CONFIG_EXPLAIN'   => 'Sur cette page il est possible de configurer les options de l’extension Anti-span pour « Nous contacter ».</br>Une adresse e-mail sera affichée en utilisant le langage JavaScript pour la rendre invisible des robots d’indexation du Web.',
   'OBSCURECONTACTUS_VERSION'              => 'Version',
   'ACP_OBSCURECONTACTUS_CONFIG_SET'       => 'Configuration',
   'OBSCURECONTACTUS_CONFIG_SAVED'         => 'Les paramètres de l’anti-span pour « Nous contacter » ont été mise à jour.',

   'OBSCURECONTACTUS_MOUSEOVER'            => 'Au survol de la souris',
   'OBSCURECONTACTUS_MOUSEOVER_EXPLAIN'    => 'Permet d’afficher un texte au survol de la souris sur le lien « Nous contacter ». Laisser vide pour n’afficher aucun texte.',

   'OBSCURECONTACTUS_PREFIX'               => 'Identifiant de l’adresse e-mail',
   'OBSCURECONTACTUS_PREFIX_EXPLAIN'       => 'Permet de saisir la partie de l’adresse e-mail située avant le symbole « @ ».',
   'OBSCURECONTACTUS_PREFIX_PLACEHOLDER'   => 'nom',

   'OBSCURECONTACTUS_SUBJECT'              => 'Sujet de l’e-mail',
   'OBSCURECONTACTUS_SUBJECT_EXPLAIN'      => 'Permet de saisir un sujet pour l’e-mail. Laisser vide pour ne pas pré-remplir le sujet de l’e-mail.',

   'OBSCURECONTACTUS_SUFFIX'               => 'Nom de domaine de l’adresse e-mail',
   'OBSCURECONTACTUS_SUFFIX_EXPLAIN'       => 'Permet de saisir la partie de l’adresse e-mail située après le symbole « @ ».',
   'OBSCURECONTACTUS_SUFFIX_PLACEHOLDER'   => 'domaine.fr',

));
