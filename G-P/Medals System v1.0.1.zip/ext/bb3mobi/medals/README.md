# Medals System

A system for awarding medals/ribbons to users

# README

You must create a folder images/medals and their devices/, set permissions 777 for devices folder.

# Installation:
Copy the entire contents of the repository to ext/bb3mobi/medals
Navigate in the ACP to Customise -> Extension Management.
Click Enable Medals System.

[![Build Status](https://travis-ci.org/bb3mobi/medals.svg?branch=master)](https://travis-ci.org/bb3mobi/medals)
