<?php
/***************************************************************************
*
* @package Medals Mod for phpBB3
* @version $Id: medals.php,v 0.7.0 2008/01/14 Gremlinn$
* @copyright (c) 2008 Nathan DuPra (mods@dupra.net)
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @traduit en fr par Ansoba https://www.pirate-ansoba.fr
*
***************************************************************************/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'IMG_ICON_POST_APPROVE'			=> 'Approuver',
	'ACP_MEDALS_INDEX'				=> 'Médailles ACP',
	'ACP_MEDALS_INDEX_EXPLAIN'		=> 'Explication des médailles',
	'ACP_MEDALS_TITLE'				=> 'Gestion des médailles',
	'ACP_MEDALS_SETTINGS'			=> 'Configuration',

	'MEDALS_MOD_INSTALLED'			=> 'Version d’extension de médailles %s installée',
	'MEDALS_MOD_UPDATED'			=> 'Extension de médailles mise à jour vers la version %s',
	'MEDALS_MOD_MANUAL'				=> 'Vous avez installé une ancienne version de l’extension de médailles.<br />Vous devrez d’abord désinstaller cette version<br />Assurez-vous de faire les sauvegardes en premier.',

	'ACL_U_AWARD_MEDALS'			=> 'Peut attribuer des médailles aux utilisateurs',
	'ACL_U_NOMINATE_MEDALS'			=> 'Peut proposer des médailles à d’autres utilisateurs',
	'ACL_A_MANAGE_MEDALS'			=> 'Peut utiliser le module de gestion des médailles',

// Medals Management
	'ACP_MEDAL_MGT_TITLE'				=> 'Gestion des médailles',
	'ACP_MEDAL_MGT_DESC'				=> 'Ici, vous pouvez afficher, créer, modifier et supprimer des catégories de médailles',

	'ACP_MEDALS'						=> 'Médailles',
	'ACP_MEDALS_DESC'					=> 'Ici vous pouvez voir, créer, modifier et supprimer des médailles pour cette catégorie.',
	'ACP_MULT_TO_USER'					=> 'Nombre de prix par utilisateur',
	'ACP_USER_NOMINATED'				=> 'Utilisateur nommé',
	'ACP_MEDAL_LEGEND'					=> 'Médaille',
	'ACP_MEDAL_TITLE_EDIT'				=> 'Modifier la médaille',
	'ACP_MEDAL_TEXT_EDIT'				=> 'Modifier une médaille existante',
	'ACP_MEDAL_TITLE_ADD'				=> 'Créer une médaille',
	'ACP_MEDAL_TEXT_ADD'				=> 'Créer une nouvelle médaille à partir de zéro',
	'ACP_MEDAL_DELETE_GOOD'				=> 'La médaille a été retirée avec succès.<br /><br /> Cliquez sur <a href="%s">ici</a> revenir à la catégorie précédente',
	'ACP_MEDAL_EDIT_GOOD'				=> 'La médaille a été mise à jour avec succès.<br /><br /> Cliquez sur <a href="%s">ici</a> pour aller dans la catégorie de la médaille',
	'ACP_MEDAL_ADD_GOOD'				=> 'La médaille a été ajoutée avec succès.<br /><br /> Cliquez sur <a href="%s">ici</a> pour aller dans la catégorie de la médaille',
	'ACP_CONFIRM_MSG_1'					=> 'Etes-vous sûr de vouloir supprimer cette médaille? Cela supprimera également cette médaille de tous les utilisateurs . <br /><br /><form method="post"><fieldset class="submit-buttons"><input class="button1" type="submit" name="confirm" value="Yes" />&nbsp;<input type="submit" class="button2" name="cancelmedal" value="No" /></fieldset></form>',
	'ACP_NAME_TITLE'					=> 'Nom de la médaille',
	'ACP_NAME_DESC'						=> 'Description de la médaille',
	'ACP_IMAGE_TITLE'					=> 'Image de la médaille',
	'ACP_IMAGE_EXPLAIN'					=> 'L’image gif pour la médaille à l’intérieur des images/médailles/ annuaire',
	'ACP_DEVICE_TITLE'					=> 'Image du périphérique',
	'ACP_DEVICE_EXPLAIN'				=> 'Le nom de base de l’image gif dans le répertoire images / medals / devices, à appliquer pour créer dynamiquement des médailles.<br /> Ex. device-2.gif = device',
	'ACP_PARENT_TITLE'					=> 'Catégorie de médaille',
	'ACP_PARENT_EXPLAIN'				=> 'La catégorie dans laquelle la médaille doit être mise',
	'ACP_DYNAMIC_TITLE'					=> 'Image de la médaille dynamique',
	'ACP_DYNAMIC_EXPLAIN'				=> 'Créer dynamiquement l’image pour plusieurs attributions.',
	'ACP_NOMINATED_TITLE'				=> 'Nominations aux médailles',
	'ACP_NOMINATED_EXPLAIN'				=> 'Les utilisateurs peuvent-ils nommer d’autres utilisateurs pour cette médaille?',
	'ACP_CREATE_MEDAL'					=> 'Créer une médaille',
	'ACP_NO_MEDALS'						=> 'Pas de médailles',
	'ACP_NUMBER'						=> 'Nombre de prix',
	'ACP_NUMBER_EXPLAIN'				=> 'Définit combien de fois cette médaille peut être attribuée à un utilisateur.',
	'ACP_POINTS'						=> 'Points',
	'ACP_POINTS_EXPLAIN'				=> 'Définit comment les points sont attribués (ou soustraits) pour recevoir cette médaille.<br />Fonctionne avec Ultimate Points Mod.',

	'ACP_MEDALS_MGT_INDEX'				=> 'Catégories de médailles',
	'ACP_MEDAL_TITLE_CAT'				=> 'Modifier la catégorie',
	'ACP_MEDAL_TEXT_CAT'				=> 'Modifier une catégorie existante',
	'ACP_MEDAL_LEGEND_CAT'				=> 'Catégorie',
	'ACP_NAME_TITLE_CAT'				=> 'Nom de catégorie',
	'ACP_CREATE_CAT'					=> 'Créer une catégorie',
	'ACP_CAT_ADD_FAIL'					=> 'Aucun nom de catégorie n’a été ajouté pour l’ajout.<br /><br /> Cliquez sur <a href="%s">ici</a> pour retourner la page de liste des catégories',
	'ACP_CAT_ADD_GOOD'					=> 'La catégorie a été ajoutée avec succès.<br /><br /> Cliquez sur <a href="%s">ici</a> pour retourner la page de liste des catégories',
	'ACP_CAT_EDIT_GOOD'					=> 'La catégorie a été modifiée avec succès.<br /><br /> Cliquez sur <a href="%s">ici</a> pour retourner la page de liste des catégories',
	'ACP_CAT_DELETE_CONFIRM'			=> 'Dans quelle catégorie souhaitez-vous déplacer toutes les médailles de cette catégorie lors de la suppression? <br /><form method="post"><fieldset class="submit-buttons"><select name="newcat">%s</select><br /><br /><input class="button1" type="submit" name="moveall" value="Move All Medals" />&nbsp;<input class="button2" type="submit" name="deleteall" value="Delete All Medals" />&nbsp;<input type="submit" class="button2" name="cancelcat" value="Cancel Deletion" /></fieldset></form>',
	'ACP_CAT_DELETE_CONFIRM_ELSE'		=> 'Il n’y a pas d’autres catégories pour déplacer ces médailles .<br /> Êtes-vous sûr de vouloir supprimer cette catégorie et toutes ses médailles?<br /><form method="post"><fieldset class="submit-buttons"><br /><input class="button2" type="submit" name="deleteall" value="Yes" />&nbsp;<input type="submit" class="button2" name="cancelcat" value="No" /></fieldset></form>',
	'ACP_CAT_DELETE_GOOD'				=> 'Cette catégorie , tout son contenu ont été supprimés avec succès <br /><br /> Cliquez sur <a href="%s">ici</a> pour retourner la page de liste des catégories',
	'ACP_CAT_DELETE_MOVE_GOOD'			=> 'Toutes les médailles de "%1$s" ont été déplacés à "%2$s" et la catégorie a été supprimée avec succès.<br /><br /> Cliquez sur <a href="%3$s">ici</a> pour retourner la page de liste des catégories',
	'ACP_NO_CAT_ID'						=> 'Pas de catégories',

// Medals Configuration
	'ACP_CONFIG_TITLE'					=> 'Configuration des médailles',
	'ACP_CONFIG_DESC'					=> 'Ici vous pouvez définir des options pour le système de la médaille 0.21.0',
	'ACP_MEDALS_CONF_SETTINGS'			=> 'Paramètres de configuration des médailles',
	'ACP_MEDALS_CONF_SAVED'				=> 'Configuration des médailles enregistrée<br /><br /> Cliquez sur <a href="%s">ici</a> aller à la configuration ACP de la médaille',
	'ACP_MEDALS_SM_IMG_WIDTH'			=> 'Largeur de l’image en pixel',
	'ACP_MEDALS_SM_IMG_WIDTH_EXPLAIN'	=> 'La largeur (en pixels) des médailles affichées dans la section des informations sur la vue et la médaille de profil.<br />Défini sur 0 pour ne pas définir une largeur.',
	'ACP_MEDALS_SM_IMG_HT'				=> 'Hauteur de l’image en pixel',
	'ACP_MEDALS_SM_IMG_HT_EXPLAIN'		=> 'La hauteur (en pixels) des médailles affichées dans la section des informations sur la vue et la médaille de profil.<br />Mettre à 0 pour ne pas définir de hauteur.',
	'ACP_MEDALS_VT_SETTINGS'			=> 'Paramètres d’affichage Viewtopic',
	'ACP_MEDALS_TOPIC_DISPLAY'			=> 'Autoriser l’affichage des médailles dans Viewtopic',
	'ACP_MEDALS_TOPIC_ROW'				=> 'Nombre de médailles avant de',
	'ACP_MEDALS_TOPIC_ROW_EXPLAIN'		=> 'Nombre de médailles à afficher dans Viewtopic.',
	'ACP_MEDALS_TOPIC_COL'				=> 'Nombre de médailles vers le bas',
	'ACP_MEDALS_TOPIC_COL_EXPLAIN'		=> 'Nombre de médailles à afficher dans le Viewtopic.',
	'ACP_MEDALS_PROFILE_ACROSS'			=> 'Médailles à afficher dans le profil',
	'ACP_MEDALS_PROFILE_ACROSS_EXPLAIN'	=> 'Nombre de médailles à afficher dans la section Informations sur les médailles du profil.',
	'ACP_MEDALS_ACTIVATE' 				=> 'Activation des médailles activée',
));
