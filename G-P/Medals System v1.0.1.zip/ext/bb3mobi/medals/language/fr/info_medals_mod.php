<?php
/***************************************************************************
*
* @package Medals Mod for phpBB3
* @version $Id: medals.php,v 0.7.0 2008/01/23 Gremlinn$
* @copyright (c) 2008 Nathan DuPra (mods@dupra.net)
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @ traduit par Ansoba => http://www.pirate-ansoba.fr
***************************************************************************/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
// pms
	'PM_MESSAGE'					=> '%1$s' . "\n" . '[b]Vous avez reçu la médaille "%2$s" par %3$s.' . "\n" . '%3$s vous a également envoyé le message suivant:[/b]' . "\n\n",
	'PM_MESSAGE_POINTS_EARN'		=> '<br />Vous avez gagné %1$s point%2$s.' . "\n\n",
	'PM_MESSAGE_POINTS_DEDUCT'		=> '<br />%1$s point%2$s ont été déduits.' . "\n\n",
	'PM_MESSAGE_NOMINATED'			=> '%1$s' . "\n" . '[b]Vous avez reçu la médaille "%2$s" par %3$s après avoir été nommé pour cela par %4$s.' . "\n" . '%3$s après avoir été nommé pour cela par:[/b]' . "\n\n",
	'PM_MSG_SUBJECT'				=> '%s vous a décerné une médaille!',

// medals awarding
	'AWARDED_BY'					=> 'Attribué par',
	'AWARDED_MEDAL'					=> 'Médailles attribuées',
	'AWARDED_MEDAL_TO'				=> 'Médailles de',
	'AWARD_MEDAL'					=> 'Médaille de prix',
	'AWARD_TIME'					=> 'Heure du prix',
	'AWARD_TO'						=> 'Médaille de récompense à',
	'MEDAL_AWARD_GOOD'				=> 'Médaille décernée avec succès!',
	'NOT_MEDALS_AWARDED'			=> 'La médaille n’a pas été décernée!',
	'MEDAL_REMOVE_GOOD'				=> 'Médaille supprimée avec succès!',
	'MEDAL_REMOVE_CONFIRM'			=> 'Vous êtes sur le point de retirer la médaille d’un utilisateur! Êtes-vous sûr de vouloir effectuer cette opération?',
	'MEDAL_REMOVE_NO'				=> 'Aucune médaille supprimée',
	'MEDAL_EDIT'					=> 'Modifier',
	'NO_USER_SELECTED'				=> 'Aucun nom d’utilisateur n’a été entré. Vous allez être redirigé momentanément',

// medals nominate
	'APPROVE'						=> 'Approuver',
	'USER_NOMINATED'				=> 'Utilisateur nommé',
	'USER_IS_NOMINATED'				=> ' [<a href="%s" title="Cet utilisateur a été nominé pour une médaille!">!</a>]',
	'MEDAL_NOMINATE_GOOD'			=> 'Médaille nommée avec succès!',
	'NOMINATABLE'					=> '[Nominable]',
	'NOMINATE'						=> 'Nominer la médaille',
	'NOMINATE_FOR'					=> 'Nomination Médaille pour',
	'NOMINATE_MEDAL'				=> 'Gérer les nominations',
	'NOMINATE_MESSAGE'				=> '<strong>%1$s nomme cet utilisateur pour la médaille "%2$s" pour la raison suivante:</strong>' . "\n\n",
	'NOMINATE_USER_LOG'				=> 'Gérer les nominations pour %s',
	'NOMINATED_BY'					=> '[Nominé par %s]',
	'NOMINATED_EXPLAIN'				=> 'Les utilisateurs peuvent-ils nommer d’autres utilisateurs pour cette médaille?',
	'NOMINATED_TITLE'				=> 'Nominations aux médailles',
	'NO_MEDALS_NOMINATED'			=> 'Médaille non nominée',
	'NOMINATIONS_REMOVE_GOOD'		=> 'Les nominations retirées avec succès!',

// Images
	'IMAGE_PREVIEW'					=> 'Aperçu',
	'MEDAL_IMG'						=> 'Image',

// medals view
	'MEDAL'							=> 'Médaille',
	'MEDALS'						=> 'Médailles',
	'MEDALS_VIEW_BUTTON'			=> 'Détails du prix',
	'MEDALS_VIEW'					=> 'Médailles',
	'MEDAL_DETAIL'					=> 'Medal Detail',
	'MEDAL_DESCRIPTION'				=> 'Détails de la médaille',
	'MEDAL_DESC'					=> 'La description',
	'MEDAL_AWARDED'					=> 'Destinataires',
	'MEDAL_AWARDED_EXPLAIN'			=> '<br />Cliquez sur le nom d’utilisateur pour administrer leur médaille (s)',
	'MEDAL_AWARD_REASON'			=> 'Raison du prix',
	'MEDAL_AWARD_REASON_EXPLAIN'	=> '<br />Entrez la raison de l’attribution de cette médaille',
	'MEDAL_NOMINATE_REASON'			=> 'Nominez la raison',
	'MEDAL_NOMINATE_REASON_EXPLAIN'	=> '<br />Entrez la raison de la nomination de cette médaille',
	'MEDAL_AWARD_USER_EXPLAIN'		=> '<br />Entrez les utilisateurs pour recevoir cette médaille (chaque nom sur une ligne distincte)',
	'MEDAL_INFORMATION'				=> 'Information sur la médaille',
	'MEDAL_INFO'					=> 'Information',
	'MEDAL_MOD'						=> 'Prix',
	'MEDAL_NAME'					=> 'Prénom',
	'NO_MEDALS_ISSUED'				=> 'Médaille non délivrée',
	'MEDAL_CP'						=> 'Panneau de contrôle des médailles',
	'MEDAL_AWARD_PANEL'				=> 'Palmarès des médailles',
	'MEDAL_NOM_BY'					=> 'Nominé par',
	'MEDAL_AMOUNT'					=> 'Montant',

// Error messages
	'CANNOT_AWARD_MULTIPLE'	=> 'Cet utilisateur a reçu le montant maximum attribué à cette médaille',
	'IMAGE_ERROR'			=> 'Vous ne pouvez pas sélectionner ceci comme une médaille pour attribuer',
	'IMAGE_ERROR_NOM'		=> 'Vous ne pouvez pas sélectionner ceci comme une médaille pour nommer',
	'NO_CAT_ID'				=> 'Aucun ID de catégorie n’a été spécifié.',
	'NO_CATS'				=> 'Pas de catégories',
	'NO_GOOD_PERMS'			=> 'Vous n’avez pas les permissions nécessaires pour accéder à cette page.<br /><br /><a href="index.php">Retour à l’index du conseil</a>',
	'NO_MEDAL_ID'			=> 'Aucune médaille n’a été sélectionnée ou aucune n’est disponible. Vous allez être redirigé momentanément',
	'NO_MEDAL_MSG'			=> 'Le champ de message était vide.<br /><br /><a href="%s">retournez à la page précédente</a>',
	'NO_MEDALS'				=> 'Aucune médaille disponible',
	'NO_MEDALS_TO_NOMINATE'	=> 'Il n’y a pas de médailles disponibles pour proposer à cet utilisateur<br /><br /><a href="%s">retournez à la page précédente</a>',
	'NO_USER_ID'			=> 'Aucun ID utilisateur n’a été spécifié',
	'NO_USER_MEDALS'		=> 'Cet utilisateur n’a reçu aucune médaille',
	'NO_USER_NOMINATIONS'	=> 'Cet utilisateur n’a pas été nominé pour des médailles',
	'NO_SWAP_ID'			=> 'Aucun ID d’échange n’a été spécifié',
	'NOT_SELF'				=> 'Vous ne pouvez pas vous nommer',

	'EXT_AUTHOR_COPY'		=> 'Anvar 2015 BB3.Mobi &copy; <a href="http://bb3.mobi/forum/viewtopic.php?t=78" title="Development Extension - Anvar Stybaev" >Medals System Extension</a>',
));
