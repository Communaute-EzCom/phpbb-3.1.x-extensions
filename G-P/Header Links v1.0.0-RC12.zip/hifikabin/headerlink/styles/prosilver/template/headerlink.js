$(function () {
    'use strict';

	// Swap .nojs and .hasjs
    phpbb.isTouch = (window && typeof window.ontouchstart !== 'undefined');
    $('#phpbb.nojs').toggleClass('nojs hasjs');
    $('#phpbb').toggleClass('hastouch', phpbb.isTouch);
    $('#phpbb.hastouch').removeClass('notouch');

    function isIE() {
        return navigator.userAgent.match(/MSIE \d\.\d+/);
    }

    var $phpbbNavbar = $('#phpbb-navbar');
    var $phpbbMenu = $('#phpbb-menu');
    var $phpbbSidebar;
    var $phpbbSidebarToggle;

    // Responsive navbar menu
    $phpbbNavbar.find('#phpbb-menu-toggle').on('click', function (e) {
        $phpbbMenu.toggleClass('show');
        $phpbbNavbar.toggleClass('menu-open');

        e.preventDefault();
    });

    // Add fly-out toggle buttons for responsive submenus
    if (phpbb.isTouch) {
        $phpbbMenu.find('.nav-button').each(function() {
            if($(this).children('.sub-menu').length) {
                $(this).prepend('<a href="#" class="submenu-toggle"></a>');
            }
            $(this).children('.submenu-toggle').on('click', function(e) {
                var $itemMenu = $(this).siblings('.sub-menu');
                $itemMenu.toggle();

                // close all other sub-menus
                $phpbbMenu.find('.sub-menu').not($itemMenu).each(function() {
                    $(this).toggle(false);
                });

                e.preventDefault();
            });
        });
    }

    // Responsive side-bar menu
    var $extras = $('#extras');

    if ($extras.length) {
        $extras.wrap('<div id="phpbb-sidebar" class="sidebar"></div>').before('<a href="#" id="phpbb-sidebar-toggle" class="sidebar-toggle" title="Toggle sidebar"></a>');
        $('#main').addClass('has-sidebar');
        $phpbbSidebar = $('#phpbb-sidebar');
        $phpbbSidebarToggle = $('#phpbb-sidebar-toggle');

        $phpbbSidebarToggle.on('click', function(e) {
            $phpbbSidebar.toggleClass('show');

            e.preventDefault();
        });
    }

    // Hide active dropdowns/menus when click event happens outside
    $('body').click(function(e) {
        var $parents = $(e.target).parents();
        if (!$parents.is($phpbbNavbar)) {
            $phpbbMenu.removeClass('show');
            $phpbbNavbar.removeClass('menu-open');
        }
        if (typeof $phpbbSidebar !== 'undefined' && !$parents.is($phpbbSidebar)) {
            $phpbbSidebar.removeClass('show');
        }
    });


    // Autofocus cookies debugger thing
    $('form[action="cookies.php"] [name="url"]').focus();

    // Showcase click tracker
    $('.showcase').on('click', 'a:[href*="http"]', function () {
        var href = this.href,
            location,
            letsGo = function () {
                location = href;

                // Only happen once!
                letsGo = function () {};
            };

        // Maximum 200ms
        $.get(location, {urlClicked: href}, letsGo);
        setTimeout(letsGo, 200);

        return false; // Yup, we want to stop propagation
    });

});

$.fn.toggleFadeSlide = function (duration, easing, callback) {
    "use strict";

    return this.animate({
        opacity: 'toggle',
        height: 'toggle'
    }, duration, easing, callback);
};