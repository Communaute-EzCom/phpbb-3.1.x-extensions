birthdaycontrol
===============

PhpBB 3.1 Birth Day controll extension

This little tool allows to control user registration by age. It allows user age to be shown in profile and topic rows.

![Build Status](https://travis-ci.org/satanasov/birthdaycontrol.svg?branch=master)