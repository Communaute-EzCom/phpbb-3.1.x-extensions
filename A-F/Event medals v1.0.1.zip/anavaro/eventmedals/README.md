[![Build Status](https://travis-ci.org/lucifer4o/eventmedals.svg?branch=master)](https://travis-ci.org/lucifer4o/eventmedals)

Event Medals
============
  
Description:
  
  Event Medals is a extension for PhpBB3 that adds support for event awards. 
  It is developed as a way to give awards in user profiles for attending live meetings. 
  But can be used for much more.
    
  Features:
    
    Forum:
      -show summary of user medals in profile field in postview
    
    Profile:
      -show list user medals in profile
      -show form for manual adding of madels ACL users
      -TO DO: Return to user profile after adding a medal
      
    UCP:
      -show ACL for who can view the medals in profile (Allways visible for admins and user it self)
      
    ACP:
      -form for mass addition of medals
	  -make sure medals are unique
	  -edit medals
	  -ACL who can add/edit medals
	  -Split Add and EDIT ACL
	  -Edit image of medals