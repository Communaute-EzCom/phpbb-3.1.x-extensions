<?php

// this file is not really needed, when empty it can be ommitted
// however you can override the default methods and add custom
// installation logic

namespace anavaro\eventmedals;

class ext extends \phpbb\extension\base
{
}
