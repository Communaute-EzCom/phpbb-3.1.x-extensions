# Changelog

## Version 1.x (for phpBB 3.2)

### v1.0.0 - 2018-02-25

Upgrade to phpBB 3.2 extension.

## Beta versions, never released (for phpBB 3.1)

### v1.0.0-beta2 - 2015-12-26

Code refactoring, unit tests - no functional changes.

### v1.0.0-beta1 - 2015-01-10

Initial release.

