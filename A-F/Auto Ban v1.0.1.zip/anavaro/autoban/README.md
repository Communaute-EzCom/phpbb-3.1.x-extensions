[![Build Status](https://travis-ci.org/satanasov/autoban.svg?branch=master)](https://travis-ci.org/satanasov/autoban)

Auto Ban
============
  
Description:
 
 Add abbility to ban users after N number of board wide warnings
 
 
Features:
  
  ACP:
    - Activate Auto Ban
    - Warnings Ban Limit
    - Auto Ban duration
    - Auto Ban reason
    
    
Installation:

  1. Create anavaro folder in %phpBB%/ext
  2. cd %phpBB%/ext/anavaro
  3. git clone https://github.com/satanasov/autoban.git
  4. Board Admin Panel -> Customize -> Manage extensions -> Enable Auto Ban
  5. Settings are in Board Settings menu in ACP.