<?php

/**
*
* Auto Ban extension for the phpBB Forum Software package.
*
* @copyright (c) 2014 Lucifer <http://www.anavaro.com>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace anavaro\autoban;

/**
* Extension class for Auto Ban
*/

class ext extends \phpbb\extension\base
{
}
