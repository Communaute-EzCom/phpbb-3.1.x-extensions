detailed_viewonline
===================

Extension for phpBB 3.1 which provides more detailed information about a place on the board on viewonline page.
