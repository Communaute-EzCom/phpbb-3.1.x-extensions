<?php
/**
*
* Forum Posts Per Page [French]
* French translation by Galixte (http://www.galixte.com)
*
* @package language Forum Posts Per Page
* @copyright (c) 2014 RMcGirr83
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	// ACP
	'FORUM_POSTS_PAGE'		=> 'Messages par page',
	'FORUM_POSTS_PAGE_EXPLAIN'		=> 'Nombre de messages par page à afficher dans les sujets de ce forum. Si défini sur 0, ce paramètre sera ignoré.',
));
