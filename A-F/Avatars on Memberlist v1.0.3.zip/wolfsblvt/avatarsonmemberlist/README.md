avatarsonmemberlist
===================

Shows user avatars on memberlist.

<b>Please note:</b>
This GitHub repository is just for sharing purposes.
I use it to publish my development code to view, not to install. <b style="color:red;">DO NOT install this extension from here.</b> I will not give support on it and it may not work cause of incompatibilities.<br />
Please visit http://www.pinkes-forum.de/dev/find.php to see a list of all extension and actual links.
