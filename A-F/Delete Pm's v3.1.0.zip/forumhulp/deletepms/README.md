Delete_pms
=====================

An extension for phpBB 3.1 that will automatically delete pm's using the phpBB3 Cron.

[![Build Status](https://travis-ci.org/ForumHulp/Delete_PMs.svg?branch=master)](https://travis-ci.org/ForumHulp/Delete_PMs)
