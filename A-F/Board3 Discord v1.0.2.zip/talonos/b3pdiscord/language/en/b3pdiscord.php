<?php
/**** @package Board3 Portal v2.1+ - Board3 Discord V1.0.2* @copyright (c) Board3 Group ( www.board3.de )* @license http://opensource.org/licenses/gpl-license.php GNU Public License* @Board3 Discord V1.0.2 by Talonos @ http://pretereo-stormrage.co.uk*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}


$lang = array_merge($lang, array(
	'PORTAL_DISCORD_TITLE'			=> 'Discord',
	'PORTAL_DISCORD_TITLE_EXP'			=> 'Use this page to change settings for the Discord block. <BR>V1.0.2 by Talonos @ <a target="_blank" href="http://pretereo-stormrage.co.uk/">Pretereo-Stormrage</a>',

	'PORTAL_DISCORD_SERVERID'			=> 'Discord Serverid',
	'PORTAL_DISCORD_SERVERID_EXP'			=> 'This is required so the module knows which server to display',

	'PORTAL_DISCORD_JOIN'			=> 'Display Join Button',
	'PORTAL_DISCORD_JOIN_EXP'			=> 'Display the "Join Server" button within the block',

	'PORTAL_DISCORD_ALPHA'			=> 'Channel alphabetical order',
	'PORTAL_DISCORD_ALPHA_EXP'			=> 'Display channels in alphabetical order',
	
	'PORTAL_DISCORD_SHOWALLUSERS'			=> 'Show All Users',
	'PORTAL_DISCORD_SHOWALLUSERS_EXP'			=> 'Show all users Currently Connected to the Discord server ("No" hides users that are not in a channel)',
	
	'PORTAL_DISCORD_SHOWGAMES'			=> 'Show Games',
	'PORTAL_DISCORD_SHOWGAMES_EXP'			=> 'Show Games being played currently by connected users ("YES" may not look right on some themes)',
	
	'PORTAL_DISCORD_USERSTATE'			=> 'All users expanded',
	'PORTAL_DISCORD_USERSTATE_EXP'			=> 'Have "All Users" expanded to display all connected users (Removed if "Show ALL Users" == NO)',
	
	'PORTAL_DISCORD_THEME'			=> 'Theme Selection',
	'PORTAL_DISCORD_THEME_EXP'			=> 'Choose from 4 different themes ("No Style" == inherit from board style)',
	
	'PORTAL_DISCORD_SERVERTITLE'			=> 'Display Server Title',
	'PORTAL_DISCORD_SERVERTITLE_EXP'			=> 'Display the name of the discord server as a title inside of block',
	
	'PORTAL_DISCORD_ONLINE'			=> 'Online Users',
	'PORTAL_DISCORD_JOINSERVER'			=> 'Join Server',
	
	
	'PORTAL_DISCORD_UPDATE'			=> 'Update limit',
	'PORTAL_DISCORD_UPDATE_EXP'			=> 'How often to update block in minutes 1-99(restarts on page refresh)',	'PORTAL_DISCORD_HIDECHANNAMES'			=> 'Hide Channels',	'PORTAL_DISCORD_HIDECHANNAMES_EXP'			=> 'Use this to hide certain channels. <br>hide named channels: <strong>AFK\', \'Raiding</strong> <br>disable hiding of channels: <strong>false</strong><br>Hide all channels: leave the box EMPTY',	
));
