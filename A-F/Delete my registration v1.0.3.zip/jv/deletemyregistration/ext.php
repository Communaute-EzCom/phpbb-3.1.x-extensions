<?php
/**
*
* @package phpBB Arcade
* @version $Id: ext.php 7 2015-09-03 00:33:59Z killbill $
* @author 2011-2015 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2015 https://jv-arcade.com/ - support@jv-arcade.com
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\deletemyregistration;

class ext extends \phpbb\extension\base
{
}
