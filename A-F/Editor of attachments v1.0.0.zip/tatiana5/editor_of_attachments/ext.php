<?php
/**
*
* @package editor_of_attachments
* @copyright (c) 2014 Татьяна5
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace tatiana5\editor_of_attachments;

/**
* Main extension class for this extension.
*/
class ext extends \phpbb\extension\base
{
}
