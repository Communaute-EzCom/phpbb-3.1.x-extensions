phpbb-3.1-annualstars
=========================

Extension will display stars for the number of years a user has been registered on a forum.

This extension is the 3.1.x version of the 3.0.x Annual Stars Mod](https://www.phpbb.com/customise/db/mod/annual_stars_2/)

[![Build Status](https://travis-ci.org/phpbbmodders/phpbb-3.1-annualstars.svg?branch=master)](https://travis-ci.org/phpbbmodders/phpbb-3.1-annualstars)
## Installation

### 1. clone
Clone (or download and move) the repository into the folder ext/phpbbmodders/annualstars:

```
cd phpBB3
git clone https://github.com/phpbbmodders/phpbb-3.1-annualstars.git ext/phpbbmodders/annualstars/
```

### 2. activate
Go to admin panel -> tab customise -> Manage extensions -> enable Annual Stars

