# fixednavbar
Extension phpBB 3.1/3.2 - Sticky navbar when scrolling down.

Using jQuery function of [Arty's styles] (https://github.com/cyberalien/phpbb31_styles)
