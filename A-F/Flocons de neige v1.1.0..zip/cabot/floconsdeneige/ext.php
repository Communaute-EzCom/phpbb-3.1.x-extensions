<?php
/**
*
* @package phpBB Extension - Flocons de neige
* @copyright (c) cabot
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

namespace cabot\floconsdeneige;

/**
* @ignore
*/

class ext extends \phpbb\extension\base
{
}
