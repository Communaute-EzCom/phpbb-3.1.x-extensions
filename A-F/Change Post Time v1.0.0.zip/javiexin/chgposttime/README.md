# chgpostime
Change Post Time extension for phpbb 3.1

Adds the option for a moderator to change the posting date and time of a post.

This is a port of the abandoned 3.0 mod found here: https://www.phpbb.com/community/viewtopic.php?p=12881195
<b>Please note:</b>
This GitHub repository is just for sharing purposes. <b style="color:red;">DO NOT install this extension from here.</b>

