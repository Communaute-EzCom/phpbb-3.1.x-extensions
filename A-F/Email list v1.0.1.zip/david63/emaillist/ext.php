<?php
/**
*
* @package Email List Extension
* @copyright (c) 2015 david63
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace david63\emaillist;

class ext extends \phpbb\extension\base
{
	const EMAIL_LIST_VERSION	= '1.0.1';
}
