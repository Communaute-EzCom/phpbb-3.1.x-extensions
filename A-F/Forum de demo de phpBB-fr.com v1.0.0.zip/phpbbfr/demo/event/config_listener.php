<?php
/**
 *
 * @package Extension phpbb-fr demo
 * @copyright (c) 2015 phpBB-fr.com website team
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

namespace phpbbfr\demo\event;

/**
 * @ignore
 */
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * Event listener
 */
class config_listener implements EventSubscriberInterface
{
	static public function getSubscribedEvents()
	{
		return array(
			'core.common'								=> 'remove_write_access',
			'core.page_footer_after'					=> 'force_config_option',
			'core.adm_page_footer'						=> 'force_config_option',
		);
	}

	static protected function config_vars_forced()
	{
		return array(
			//'config_name'					=> array('value_to_force', 'ERROR_MESSAGE'),

			'cookie_domain'					=> array(null, null),
			'cookie_path'					=> array(null, null),
			'cookie_secure'					=> array(null, null),
			'use_system_cron'				=> array(null, null),
			'server_protocol'				=> array(null, null),
			'server_name'					=> array(null, null),
			'server_port'					=> array(null, null),
			'script_path'					=> array(null, null),

			'img_imagick'					=> array('', 'ACP_DEMO_CONFIG_ATTACHMENTS_DENIED'), //Force imagick path to be empty
			'tpl_allow_php'					=> array(false, 'ACP_DEMO_CONFIG_PHP_DENIED'), //Always deny php in templates !
			'allow_attachments'				=> array(false, 'ACP_DEMO_CONFIG_ATTACHMENTS_DENIED'), //Disable attachment
			'allow_pm_attach'				=> array(false, 'ACP_DEMO_CONFIG_ATTACHMENTS_DENIED'), //Disable attachment in PM
			'email_enable'					=> array(false, 'ACP_DEMO_CONFIG_MAIL_DENIED'), //Disable email
			'jab_enable'					=> array(false, 'ACP_DEMO_CONFIG_JABBER_DENIED'), //Disable jabber
			'allow_avatar_upload'			=> array(false, 'ACP_DEMO_CONFIG_AVATARS_DENIED'), //Disable avatars upload
			'allow_avatar_remote_upload'	=> array(false, 'ACP_DEMO_CONFIG_AVATARS_DENIED'), //Disable avatars remote upload
		);
	}

	/* @var \phpbb\template\template */
	protected $template;

	/* @var \phpbb\user */
	protected $user;

	/* @var \phpbb\config\config */
	protected $config;

	/** @var string phpBB root path */
	protected $root_path;

	/**
	 * Constructor
	 *
	 * @param \phpbb\template\template	$template			Template object
	 * @param \phpbb\user				$user				User object
	 * @param \phpbb\config\config		$config				Config object
	 * @param string					$root_path			phpBB root path
	 */
	public function __construct(\phpbb\template\template $template, \phpbb\user $user, \phpbb\config\config $config, $root_path)
	{
		$this->template = $template;
		$this->user = $user;
		$this->config = $config;
		$this->root_path = $root_path;
	}

	public function remove_write_access()
	{
		//Remove writing possibility in "files" directory
		if (phpbb_is_writable($this->root_path . 'files/'))
		{
			//phpBB chmod's function does not work because want to keep right related to this path.
			//phpbb_chmod($phpbb_root_path . 'files/', CHMOD_READ);
			//So set to read only for all unless owner.
			chmod($this->root_path . 'files/', 0544);
		}

		//Remove writing possibility in "images/avatars/upload" directory
		if (phpbb_is_writable($this->root_path . 'images/avatars/upload/'))
		{
			chmod($this->root_path . 'images/avatars/upload/', 0544);
		}

		//Remove writing possibility in "store" directory
		if (phpbb_is_writable($this->root_path . 'store/'))
		{
			chmod($this->root_path . 'store/', 0544);
		}

		// We also backup some config vars ...
		if (empty($this->config['config_backup_done']))
		{
			foreach(static::config_vars_forced() as $config_name => $params)
			{
				if (is_null($params[0]))
				{
					$this->config->set($config_name . '_backup', $this->config[$config_name]);
				}
			}

			$this->config->set('config_backup_done', true);
		}
	}

	public function force_config_option()
	{
		foreach(static::config_vars_forced() as $config_name => $params)
		{
			if (is_null($params[0]))
			{
				if ($this->config[$config_name] != $this->config[$config_name . '_backup'])
				{
					$this->config->set($config_name, $this->config[$config_name . '_backup']);
					if (!is_null($params[1])) $errors[] = $this->user->lang($params[1]);
				}
			}
			else
			{
				if ($this->config[$config_name] != $params[0])
				{
					$this->config->set($config_name, $params[0]);
					if (!is_null($params[1])) $errors[] = $this->user->lang($params[1]);
				}
			}
		}

		if (!defined('IN_ADMIN') || empty($errors))
		{
			return;
		}

		$message = implode('<br />', $errors);

		global $module;
		$message .= adm_back_link($module->module->u_action);

		if (!defined('IN_ERROR_HANDLER'))
		{
			trigger_error($message, E_USER_WARNING);
		}
		else
		{
			$this->template->assign_vars(array(
					'MESSAGE_TEXT'		=> $message,
					'S_USER_WARNING'	=> true,
					'S_USER_NOTICE'		=> false,
			));
		}
	}
}