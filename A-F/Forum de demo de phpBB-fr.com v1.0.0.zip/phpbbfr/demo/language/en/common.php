<?php
/**
 *
 * @package Extension phpbb-fr demo
 * @copyright (c) 2015 phpBB-fr.com website team
 * @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
 *
 */

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	'ACP_DEMO_CANT_DISABLED'			=> 'This extension cannot be disabled.',
	'ACP_DEMO_PHPINFO_DISABLED'			=> 'You can`t access to the PHP information on the demo board.',
	'ACP_DEMO_STATS_DISABLED'			=> 'You can`t send the statistical information on the demo board',
	'ACP_DEMO_BACKUP_DISABLED'			=> 'You can`t do a backup of the demo board`s database.',

	'ACP_DEMO_CONFIG_PHP_DENIED'		=> 'For security reasons, the PHP is disallowed on the demo board.',
	'ACP_DEMO_CONFIG_ATTACHMENTS_DENIED'=> 'The attachments features is disabled on the demo board.',
	'ACP_DEMO_CONFIG_MAIL_DENIED'		=> 'Emails are disallowed on the demo board.',
	'ACP_DEMO_CONFIG_JABBER_DENIED'		=> 'Jabber is disallowed on the demo board.',
	'ACP_DEMO_CONFIG_AVATARS_DENIED'	=> 'You can`t upload avatars to the demo board.'
));