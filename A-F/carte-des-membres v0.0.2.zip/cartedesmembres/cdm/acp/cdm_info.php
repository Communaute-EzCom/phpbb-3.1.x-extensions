<?php
/**
*
* cdm extension for the phpBB Forum Software package.
*
* @copyright (c) 2015 Lionel Retif <http://www.carte-des-membres.com/>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

namespace cartedesmembres\cdm\acp;

class cdm_info
{
	public function module()
	{
		return array(
			'filename'	=> '\cartedesmembres\cdm\acp\main_module',
			'title'		=> 'ACP_CDM_TITLE',
			'modes'		=> array(
				'settings'	=> array('title'=>'ACP_CDM', 'auth' => 'ext_cartedesmembres/cdm && acl_a_board', 'cat' => array('ACP_CDM_TITLE')),
			),
		);
	}
}
