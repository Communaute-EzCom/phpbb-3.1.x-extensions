<?php
/**
*
* @package - cdm language
* @copyright (c) 2015 Lionel
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
	'CDM'				=> 'Localisation',
	'CDM_URL'			=> 'http://www.carte-des-membres.com',
	'CDM_LINK_NAME'		=> 'Member map',
	'CDM_YES'			=> 'Configured',
	'CDM_NO'			=> 'Not configured',
	'CDM_HAVE_TO_LOGIN'	=> 'Log in to modify your localisation',
  'CDM_NO_CONFIG'		=> 'The member’s map isn’t configured. Contact administrators to solve this problem.',	
  'ACP_CDM_ID'			=> 'CDM_ID',
	'ACP_CDM_CODE'		=> 'CDM_CODE',
	'ACP_CDM_NOM'		=> 'CDM_NOM',
	'ACP_CDM_TITLE'		=> 'Member’s map settings',
	'ACP_CDM'			=> 'Settings',
	'ACP_CDM_SETTING_SAVED'  => 'Settings have been saved!',
	'ACP_CDM_EXPLAIN_CONFIG' => 'Go to <a href="http://www.carte-des-membres.com/w/" target="_blank">http://www.carte-des-membres.com/w/</a> to obtain settings dedicated to your member map.',
));

