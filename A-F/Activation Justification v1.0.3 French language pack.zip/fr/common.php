<?php
/**
 *
 * Activation Justification. An extension for the phpBB Forum Software package.
 * French translation by tomberaid & Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2017 RMcGirr83
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'ACTIVATION_JUSTIFICATION'	=> '<strong>Raison d’enregistrement</strong>',
	'JUSTIFICATION_EXPLAIN'		=> 'L’enregistrement sur ce forum est sujet à validation par ses administrateurs. Merci de saisir une raison, celle-ci permettra à l’équipe du forum de s’assurer du bien-fondé de votre démarche d’enregistrement.',
	'JUSTIFICATION'				=> 'Justification',
	'NO_JUSTIFICATION'			=> '<em>La raison de l’enregistrement n’a pas été saisie.</em>',
	'TOO_SHORT_JUSTIFICATION'	=> 'La raison de l’enregistrement est trop courte.',
	'JUSTIFY_YOU_HAVE'			=> 'Le texte de justification d’enregistrement peut contenir encore',
	'JUSTIFY_CHARS_REMAINING'	=> 'caractères supplémentaires.',
	'SURE_ACTIVATE'				=> 'Confirmer l’activation du compte utilisateur : <strong>%s</strong>.', // %s will be a username.
	'ACTIVATED_SUCCESS'			=> '<strong>L’utilisateur a été activé avec succès !</strong>',
));
