# Forum Legend
Icon legend for forum and index for phpBB 3.1

Gives members of your board a visual legend for the forum icons on the board index page as well as the view forum pages.

# Installation

    1 Copy the entire contents of the repository to ext/spaceace/forumlegend
    2 Navigate in the ACP to Customise -> Extension Management
    3 Click Enable for Forum Legend
