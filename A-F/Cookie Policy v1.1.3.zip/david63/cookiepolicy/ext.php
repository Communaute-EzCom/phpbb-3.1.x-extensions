<?php
/**
*
* @package Cookie Policy Extension
* @copyright (c) 2014 david63
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace david63\cookiepolicy;

class ext extends \phpbb\extension\base
{
	const COOKIE_POLICY_VERSION	= '1.1.3';
}
