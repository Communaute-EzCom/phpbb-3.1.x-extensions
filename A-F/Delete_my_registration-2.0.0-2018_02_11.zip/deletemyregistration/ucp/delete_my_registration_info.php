<?php
/**
*
* @package Delete my registration
* @version $Id: delete_my_registration_info.php 280 2018-02-11 17:21:53Z killbill $
* @author 2011-2018 KillBill - killbill@jatek-vilag.com
* @copyright (c) 2014-2018 https://jv-arcade.com/ - support@jv-arcade.com
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace jv\deletemyregistration\ucp;

class delete_my_registration_info
{
	function module()
	{
		return array(
			'filename'	=> '\jv\deletemyregistration\ucp\delete_my_registration_module',
			'title'		=> 'UCP_PROFILE',
			'modes'		=> array(
				'my_acc_delete' => array('title' => 'UCP_PROFILE_MY_ACC_DELETE', 'auth' => 'ext_jv/deletemyregistration', 'cat' => array('UCP_PROFILE'))
			)
		);
	}
}
