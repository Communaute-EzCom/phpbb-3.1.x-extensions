# Changelog

## 2.0.0 - 2018-02-11

- [Fixed] few smaller html5 code.

## 1.0.3 - 2015-09-11

- Added the following language: Danish
- Fixed the following languages: Dutch, French

## 1.0.2 - 2015-06-08

- Added migration script - check exists the default 'Permission roles'.
- Added the following languages: Arabic, Chinese, Croatian, Dutch, Estonian, French, German, Greek, Italian, Polish, Spanish, Turkish

## 1.0.1 - 2014-12-08

- Fixed delete my registration module auth
- Added Check old MOD installation

## 1.0.0 - 2014-10-31

- First release
