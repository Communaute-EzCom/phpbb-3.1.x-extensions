# Changelog

## 1.1.2 - 2017-01-10

- Various code improvements and fixes
- Added Czech translation

## 1.1.1 - 2016-05-01

- Refactored entire codebase
- Log results of the check table operation
- Added American English translation
- Added French translation
- Added Turkish translation
- Added Japanese translation
- Added Italian translation

## 1.1.0 - 2014-11-26

- Added a confirm dialog prior to running a table operation
- Various code improvements and fixes

## 1.1.0-b2 - 2014-07-12

- Updated for compatibility with phpBB 3.1.0-RC2

## 1.1.0-b1 - 2014-06-06

- First beta release of the MOD ported into an extension
