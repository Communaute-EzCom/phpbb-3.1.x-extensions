AddonForThanksForPosts
======================
[![Build Status](https://travis-ci.org/alg5/AddonForThanksForPosts.svg?branch=master)](https://travis-ci.org/alg5/AddonForThanksForPosts)
