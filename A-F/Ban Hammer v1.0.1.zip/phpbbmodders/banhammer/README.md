# ban-hammer
Ban Hammer for phpBB 3.1.x line (was One Click Ban)

Gives possibility to ban users directly from their profile. Along with banning you can automatically move the user to a certain group, delete their posts, delete their private messages, delete their avatar, signature, and profile information.

[![Build Status](https://travis-ci.org/phpbbmodders/ban-hammer.svg?branch=master)](https://travis-ci.org/phpbbmodders/ban-hammer)
