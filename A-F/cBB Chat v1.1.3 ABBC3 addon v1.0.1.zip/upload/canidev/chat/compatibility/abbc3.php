<?php
/*
* @name abbc3.php
* @package cBB Chat Compatibility
* @version v1.0.1 06/10/2015
*
* @copyright (c) 2015 CaniDev
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*/

namespace canidev\chat\compatibility;

// @ignore
if(!defined('IN_PHPBB'))
{
	exit;
}

class abbc3 extends base
{
	const BBVIDEO_DEFAULT 			= 'youtube.com';
	const bbvideo_default_width		= 560;
    const bbvideo_default_height	= 315;

	public $name = 'vse/abbc3';

	private $abbc3_icon_path = 'ext/vse/abbc3/images/icons/';
	
	public function is_runnable()
	{
		return $this->ext_manager->is_enabled($this->name);
	}
	
	public function get_core_events()
	{
		return array(
			'chat.custom_bbcodes_modify_sql'	=> 'on_bbcodes_modify_sql',
			'chat.generate_bbcodes'				=> 'on_generate_bbcodes',
			
			'core.common'			=> 'on_init',
		);
	}
	
	public function on_bbcodes_modify_sql($event)
	{
		$sql_ary = $event['sql_ary'];
		$sql_ary['SELECT'] .= ', b.bbcode_group';
		$sql_ary['ORDER_BY'] = 'b.bbcode_order, b.bbcode_id';
		$event['sql_ary'] = $sql_ary;
	}
	
	public function on_generate_bbcodes($event)
	{
		global $chat;

		if($event['template_key'] == 'chat_custom_tags')
		{
			$item 		= $event['item_ary'];
			$imagename	= $this->abbc3_icon_path . strtolower($event['bbcode_name']) . '.gif';

			if(file_exists($chat->phpbb_root_path . $imagename))
			{
				$item['S_IMAGE'] = $chat->web_path . $imagename;
				$event['item_ary'] = $item;
			}
			
			$event['template_key'] = 'chat_abbc3_tags';
		}
	}
	
	public function on_init()
	{
		global $phpbb_hook;
		$phpbb_hook->register('phpbb_user_session_handler', array($this, 'parse_ajax'));
	}
	
	public function parse_ajax()
	{
		global $request, $template;

		if($request->is_set_post('abbc3ajx') && !defined('ADMIN_START'))
		{
			$bbcode_id = $request->variable('bbcode', '');
			
			if($bbcode_id == 'BBvideo')
			{
				$this->generate_bbvideo_wizard();
			}
			
			$template->assign_var('S_ABBC3_BBCODE', $bbcode_id);
			
			$template->set_filenames(array(
				'abbc3' => 'abbc3_wizards.html'
			));

			$template->set_style(array('ext/canidev/chat/styles'));
			$template->display('abbc3');

			exit_handler();
		}
	}
	
	protected function generate_bbvideo_wizard()
	{
		global $user, $template, $phpbb_root_path;

		$json_file					= $phpbb_root_path . 'ext/vse/abbc3/assets/bbvideo.json';
		$bbvideo_size_presets_array	= array('560,315', '640,360', '853,480', '1280,720');
		$bbvideo_sites_array		= array();

		if($file_contents = @file_get_contents($json_file))
		{
			$bbvideo_sites_array = json_decode($file_contents, true);
		}

		// Construct BBvideo allowed site select options
		foreach($bbvideo_sites_array as $site => $example)
		{
			$template->assign_block_vars('bbvideo_site', array(
				'VALUE'			=> $example,
				'LABEL'			=> $site,
				'S_SELECTED'	=> $site == self::BBVIDEO_DEFAULT,
			));
		}

		// Construct BBvideo size preset select options
		foreach($bbvideo_size_presets_array as $preset)
		{
			$template->assign_block_vars('bbvideo_size', array(
				'VALUE'			=> $preset,
				'LABEL'			=> str_replace(',', ' ' . $user->lang('ABBC3_BBVIDEO_SEPARATOR') . ' ', $preset),
			));
		}

		$template->assign_vars(array(
			'ABBC3_BBVIDEO_LINK_EX'	=> (isset($bbvideo_sites_array[self::BBVIDEO_DEFAULT])) ? $bbvideo_sites_array[self::BBVIDEO_DEFAULT] : '',
			'ABBC3_BBVIDEO_HEIGHT'	=> self::bbvideo_default_height,
			'ABBC3_BBVIDEO_WIDTH'	=> self::bbvideo_default_width,
		));
	}

	public function get_js_events()
	{
		global $user;

		return array(
			'chat.beforeInit'	=> "function() {
				$.chat.abbc3_dispatch = function(e) {
					var data 		= $(this).getdata('#!', '/'),
						action 		= (data[1]) ? data[1] : '',
						bbcodeId	= '';
						
					if(action != 'bbcode')
					{
						return false;
					}
					
					switch(data[2])
					{
						case 'align=':
							bbcodeId = 'align=center';
						break;

						case 'float=':
						case 'marq=':
							bbcodeId = data[2] + '=left';
						break;

						case 'dir=':
							bbcodeId = 'dir=rtl';
						break;

						case 'mod=':
							bbcodeId = 'mod=" . $user->data['username'] . "';
						break;

						case 'highlight=':
							bbcodeId = 'highlight=yellow';
						break;

						case 'glow=':
							bbcodeId = 'glow=red';
						break;

						case 'shadow=':
						case 'dropshadow=':
						case 'blur=':
							bbcodeId = data[2] + '=blue';
						break;

						case 'BBvideo=':
						case 'url':
							xhr = $.ajax({
								url			: $.chat.id.find('form').attr('action'),
								data		: {
									abbc3ajx	: 1,
									bbcode		: data[2].replace('=', '')
								},
								dataType	: 'html',
								type		: 'POST',
								proccessData: false,
								success: function(data, textStatus, jqXHR) {
									$.dialog.init({
										width : 500,
										onInit: function() {
											$.dialog.show(data);
											
											$.dialog.find('#bbvideo_wizard_sites').change(function() {
												$('#bbvideo_wizard_example').val($(this).val());
											});
											
											$.dialog.find('#bbvideo_wizard_size_presets').change(function() {
												if($(this).val())
												{
													var dims = $(this).val().split(',');
													$('#bbvideo_wizard_width').val(dims[0]);
													$('#bbvideo_wizard_height').val(dims[1]);
												}
												
												$(this).val('');
											});
										},
										onSubmit: function(xdata) {
											var msg		= $.chat.id.find('textarea:first'),
												text	= msg.val(),
												ca 		= msg.caret();
											
											var before	= text.substring(0, ca.start),
												after	= text.substring(ca.end, text.length);

											text = before;

											switch(xdata.abbc3_bbcode)
											{
												case 'url':
													var link 		= xdata.bbcode_wizard_link,
														description	= xdata.bbcode_wizard_description;
														
													text += '[url' + ((description.length) ? '=' + link : '') + ']' + ((description.length) ? description : link) + '[/url]';
												break;
												
												case 'BBvideo':
													text += '[BBvideo=' + xdata.bbvideo_wizard_width + ',' + xdata.bbvideo_wizard_height + ']' + xdata.bbvideo_wizard_link + '[/BBvideo]';
												break;
											}
											
											text += after;
											
											ca.start 	= text.length;
											ca.end		= text.length;
											
											msg.editable('update', text, [ca.start, ca.end]);
										}
									});
								},
								error: function() {
									switch(data[2])
									{
										case 'BBvideo=':
											$.chat.insert_bbcode('BBvideo=560,315', true);
										break;
										
										default:
											$.chat.insert_bbcode(data[2], true);
										break;
									}
								}
							});
							
							return false;
						break;

						default:
							bbcodeId = data[2];
						break;
					}
					
					$.chat.insert_bbcode(bbcodeId, ((bbcodeId == '*') ? false : true));
					e.preventDefault();
				};
			}",
			'chat.onInit'		=> "function() {
				$('#abbc3-font-select').change(function() {
					var font = $(this).val();
					
					if(font)
					{
						$.chat.insert_bbcode('font=' + font, true);
						$(this).children('option').eq(0).prop('selected', true);
					}
				});
				
				$.chat.id.find('.bbcode-box a').unbind();
				
				if($.browser.isMobile)
				{
					$.chat.id.find('.bbcode-box a').touch($.chat.abbc3_dispatch);
				}
				else
				{
					$.chat.id.find('.bbcode-box a').click($.chat.abbc3_dispatch);
				}
			}",
			'chat.onBindRows'	=> "function() {
				if($.fn.bbvideo && $.chat.mode != 'archive')
				{
					$('.chat-row .bbvideo')
						.attr('data-bbvideo', '200,150')
						.bbvideo()
						.remove();
				}
			}",
		);
	}
}