<?php
/**
 *
 * Advanced login. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2017 Galandas <http://phpbb3world.altervista.org>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'ACP_WIDTH_ADVLOGIN'			=> 'Largeur en pixels',
	'ACP_WIDTH_ADVLOGIN_EXPLAIN'	=> 'Permet de saisir la valeur de la largeur en pixels. Il est recommandé de ne pas excéder les valeurs recommandées pour un meilleur affichage sur les périphériques mobiles. Valeurs recommandées : entre 300 et 350 pixels.',
	'ACP_HEIGHT_ADVLOGIN'			=> 'Hauteur en pixels',
	'ACP_HEIGHT_ADVLOGIN_EXPLAIN'	=> 'Permet de saisir la valeur de la hauteur en pixels. Il est recommandé de ne pas excéder les valeurs recommandées pour un meilleur affichage sur les périphériques mobiles. Valeurs recommandées : entre 150 et 600 pixels.',
	'ACP_ADVLOGIN'			        => 'Connexion avancée',
	'ACP_ADVLOGIN_SETTINGS'	        => 'Paramètres',
	'ACP_ADVLOGIN_CONFIG_SET'		=> 'Activation',
	'ACP_ADVLOGIN_CONFIG'		    => 'Saisie du texte',
	'ACP_ADVLOGIN_CONFIG_SAVED'		=> 'Les paramètres ont été sauvegardés avec succès !',
	'ACP_ADVLOGIN_VERSION'			=> 'Version',
	'ACP_ADVLOGIN_DONATE'			=> '« <a href="https://www.paypal.me/Galandas"><strong>PayPal</strong></a> ».',
	'ACP_ADVLOGIN_DONATE_EXPLAIN'	=> 'Si cette extension est appréciée il est possible de faire un don au moyen de : ',	
	'ACP_ADVLOGIN_CREDITS'			=> 'Extension « Advanced login » développée par <a href="http://phpbb3world.altervista.org"><strong>Galandas</strong></a>.',
	'ACP_ADVLOGIN_ENABLE'			=> 'Activer la connexion avancée',
	'ACP_ADVLOGIN_ENABLE_EXPLAIN'	=> 'Permet d’activer l’affichage de la connexion avancée sur tout le forum.',
	'ACP_ADVLOGIN_TEXT'				=> 'Afficher le texte',
	'ACP_ADVLOGIN_TEXT_EXPLAIN'		=> 'Permet de saisir le texte à afficher dans la boite de connexion avancée, le language HTML est autorisé.',
	'ACP_ADVLOGIN_COLOR'			=> 'Couleur d’arrière-plan',
	'ACP_ADVLOGIN_COLOR_EXPLAIN'	=> 'Permet de saisir la valeur de la couleur de l’arrière-plan de la boite de la connexion avancée, le language HEXADECIMAL est autorisé, tel que : A1D490. Laisser ce champ vide pour utiliser la couleur par défaut.',
	'ACP_ADVLOGIN_ASPECT'           => 'Choisir une apparence',
	'ACP_ADVLOGIN_ASPECT_EXPLAIN'   => 'Permet de sélectionner l’apparence par défaut de la boite de la connexion avancée. L’apparence n°1 affiche une image au-dessus du titre de la boite, l’image est modifiable dans le répertoire : ./ext/galandas/advlogin/styles/all/theme/images/.<br />Tandis que l’apparence n°2 n’affiche pas d’image et le texte est affiché par défaut en rouge.',
    // Appearance choice	
	'ACP_ASPECT_A'           => 'Apparence n°1',
	'ACP_ASPECT_B'           => 'Apparence n°2',
));
