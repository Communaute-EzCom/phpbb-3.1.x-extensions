
The below files are created by Bruno Maia, IconTexto (http://www.icontexto.com)
and licensed under CC License Attribution-Noncommercial 3.0 (http://creativecommons.org/licenses/by-nc/3.0/)

icon-help-32x32.png
icon-info-32x32.png