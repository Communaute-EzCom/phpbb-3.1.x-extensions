<?php
/*
* @name main_module.php
* @package cBB Chat
* @version v1.1.3 10/03/2017
*
* @copyright (c) 2017 CaniDev
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
*/

namespace canidev\chat\acp;

// @ignore
if(!defined('IN_PHPBB'))
{
	exit;
}

/**
* @package acp
*/
class main_module
{
	var $u_action;
	var $new_config 	= array();
	var $exclude_files 	= array('app', 'chat', 'common', 'config', 'cron', 'feed', 'report');
	
	protected $cache;
	protected $chat;
	protected $config;
	protected $db;
	protected $log;
	protected $request;
	protected $template;
	protected $user;
	
	protected $phpbb_root_path;
	protected $php_ext;

	function main($id, $mode)
	{
		global $cache, $db, $user, $template, $config, $request, $phpbb_log, $chat, $phpbb_root_path, $phpEx;
		
		$this->cache	= $cache;
		$this->chat		= $chat;
		$this->config	= $config;
		$this->db		= $db;
		$this->log		= $phpbb_log;
		$this->request	= $request;
		$this->template = $template;
		$this->user 	= $user;
		
		$this->phpbb_root_path	= $phpbb_root_path;
		$this->php_ext			= $phpEx;

		$this->user->add_lang_ext('canidev/chat', array('acp', 'main'));

		$action = $this->request->variable('action', '');
		$error	= $notice = array();
		$submit = ($this->request->is_set_post('submit')) ? true : false;
		
		// Delete the cache in the first call after the installation (prevent error to load chat template events without clear the cache manually)
		if(strpos($this->config['chat_version'], 'p') !== false)
		{
			$this->config->set('chat_version', str_replace('p', '', $this->config['chat_version']));
			$this->cache->purge();
		}
		
		// Security check
		if(in_array($action, array('delete', 'add_auth')) && !$this->request->is_set_post('icajx'))
		{
			exit_handler();
		}

		if(!method_exists($this, "_mode_$mode"))
		{
			trigger_error('NO_MODE', E_USER_WARNING);
		}

		call_user_func_array(array($this, "_mode_$mode"), array($action, $submit, &$error, &$notice));

		$this->page_title 	= (empty($this->page_title) ? 'CHAT_' . strtoupper($mode) . '_TITLE' : $this->page_title);
		$this->page_title	= $this->user->lang($this->page_title);
		$this->page_explain = (empty($this->page_explain) ? 'CHAT_' . strtoupper($mode) . '_EXPLAIN' : $this->page_explain);

		$this->template->assign_vars(array(
			'IN_CHAT_ADMIN'		=> true,
			'L_TITLE'			=> $this->page_title,
			'L_TITLE_EXPLAIN'	=> $this->user->lang($this->page_explain),

			'U_ACTION'			=> $this->u_action,
			'U_HELP'			=> 'http://www.canidev.com/docs.php?i=cbb-chat-v' . $this->config['chat_version'],
		));
		
		if(sizeof($error) || sizeof($notice))
		{
			$notice_rows = (sizeof($error) ? $error : $notice);
			
			foreach($notice_rows as $id => $value)
			{
				if(isset($this->user->lang[$value]))
				{
					$notice_rows[$id] = $this->user->lang[$value];
				}
			}
			
			$this->template->assign_vars(array(
				'NOTICE'		=> implode('<br />', $notice_rows),
				'NOTICE_ERROR'	=> (sizeof($error) ? true : false),
			));
		}
		
		$this->page_title = $this->user->lang['CHAT'] . ' &bull; ' . $this->page_title;
	}
	
	function _mode_config($action, $submit, &$error, &$notice)
	{
		global $phpbb_dispatcher;
		
		$this->tpl_name = 'chat_config';

		$display_vars = array(
			'legend1'			=> 'CHAT_MAIN_CONFIG',
			'chat_enabled'				=> array('lang' => 'CHAT_ENABLED',				'validate' => 'bool',		'type' => 'radio:yes_no'),
			'chat_page_enabled'			=> array('lang' => 'CHAT_PAGE_ENABLED',			'validate' => 'bool',		'type' => 'radio:yes_no'),
			'chat_forum_posts'			=> array('lang' => 'CHAT_FORUM_POSTS',			'type' => 'custom',			'method' => 'make_select',	'params' => array('{KEY}', '{CONFIG_VALUE}')),
			'chat_autoconnect'			=> array('lang' => 'CHAT_AUTOCONNECT',			'validate' => 'bool',		'type' => 'radio:yes_no'),
			'chat_anonymous_allowed'	=> array('lang' => 'CHAT_ANONYMOUS_ALLOWED',	'validate' => 'bool',		'type' => 'radio:yes_no'),
			'chat_sound'				=> array('lang' => 'CHAT_SOUND_ENABLED',		'validate' => 'bool',		'type' => 'radio:yes_no'),
			'chat_flood_time'			=> array('lang' => 'CHAT_FLOOD',				'validate' => 'int:0:60',	'type' => 'text:3:2'),
			'chat_height'				=> array('lang' => 'CHAT_HEIGHT',				'validate' => 'int:50:800',	'type' => 'text:4:3'),
			'chat_refresh'				=> array('lang' => 'CHAT_REFRESH_TIME',			'validate' => 'int:5:60',	'type' => 'text:3:2'),

			'legend2'			=> 'CHAT_USERS_CONFIG',
			'chat_timeout'				=> array('lang' => 'CHAT_TIMEOUT',			'validate' => 'int:0:60',	'type' => 'text:3:2'),
			'chat_auto_away'			=> array('lang' => 'CHAT_AUTO_AWAY',		'validate' => 'int:0:60',	'type' => 'text:3:2'),
			'chat_remember_status'		=> array('lang' => 'CHAT_REMEMBER_STATUS',	'validate' => 'bool',		'type' => 'radio:yes_no'),
			'chat_group_users'			=> array('lang' => 'CHAT_GROUP_USERS',		'validate' => 'bool',		'type' => 'radio:yes_no'),
		
			'legend3'			=> 'CHAT_MESSAGES_CONFIG',
			'chat_direction'			=> array('lang' => 'CHAT_DIRECTION',		'validate' => 'string',		'type' => 'custom',	'method' => 'make_select',	'params' => array('{KEY}', '{CONFIG_VALUE}')),
			'chat_max_rows'				=> array('lang' => 'CHAT_ROWS',				'validate' => 'int:1:100',	'type' => 'text:4:3'),
			'chat_max_chars'			=> array('lang' => 'CHAT_CHARS',			'validate' => 'int',		'type' => 'text:4:4'),
			'chat_show_avatars'			=> array('lang' => 'CHAT_AVATARS',			'validate' => 'bool',		'type' => 'radio:yes_no'),
			'chat_allow_bbcode'			=> array('lang' => 'CHAT_ALLOW_BBCODE',		'validate' => 'bool',		'type' => 'radio:yes_no'),
			'chat_disallowed_bbcode'	=> array('lang' => 'CHAT_DISALLOWED_BBCODE',	'type' => 'custom',		'method' => 'make_select',	'params' => array('{KEY}', '{CONFIG_VALUE}', 8)),
			'chat_bbcode_format'		=> array('lang' => 'CHAT_BBCODE_FORMAT',	'type' => 'custom',			'method' => 'make_select',	'params' => array('{KEY}', '{CONFIG_VALUE}')),
		
			'legend4'		=> 'CHAT_PM_CONFIG',
			'chat_allow_pm'			=> array('lang' => 'CHAT_ALLOW_PM',			'validate' => 'bool',		'type' => 'radio:yes_no'),
			'chat_max_pm'			=> array('lang' => 'CHAT_MAX_PM',			'validate' => 'int:0:60',	'type' => 'text:3:2'),
		);
		
		/**
		* Event to add and/or modify configurations
		*
		* @event chat.acp_config_vars
		* @var	array	display_vars	Array of config values to display and process
		* @var	boolean	submit			Do we display the form or process the submission
		* @since 1.1.1
		*/
		$vars = array('display_vars', 'submit');
		extract($phpbb_dispatcher->trigger_event('chat.acp_config_vars', compact($vars)));
		
		$cfg_array	= $this->config;
		
		if(isset($_REQUEST['config']))
		{
			$cfg_array = utf8_normalize_nfc($this->request->variable('config', array('' => ''), true));
			$cfg_array['chat_disallowed_bbcode'] = $this->request->variable('chat_disallowed_bbcode', array(0));
			
			if(!empty($cfg_array['chat_disallowed_bbcode']))
			{
				$bitfield = new \bitfield();
				
				foreach($cfg_array['chat_disallowed_bbcode'] as $bbcode_id)
				{
					$bitfield->set($bbcode_id);
				}
				
				$cfg_array['chat_disallowed_bbcode'] = $bitfield->get_base64();
			}
			else
			{
				$cfg_array['chat_disallowed_bbcode'] = '';
			}
		}

		// We validate the complete config if whished
		validate_config_vars($display_vars, $cfg_array, $error);
		
		// Validate the timeouts
		if($cfg_array['chat_timeout'] && $cfg_array['chat_auto_away'] && $cfg_array['chat_timeout'] <= $cfg_array['chat_auto_away'])
		{
			$error[] = 'CHAT_AUTO_AWAY_ERROR';
		}
		
		// Do not write values if there is an error
		if(sizeof($error))
		{
			$submit = false;
		}
		
		// We go through the display_vars to make sure no one is trying to set variables he/she is not allowed to...
		foreach($display_vars as $config_name => $null)
		{
			if(!isset($cfg_array[$config_name]) || strpos($config_name, 'legend') !== false)
			{
				continue;
			}

			$this->new_config[$config_name] = $config_value = $cfg_array[$config_name];

			if($submit)
			{
				// Delete the guest sessions is neccessary here
				if($config_name == 'chat_anonymous_allowed' && $this->config['chat_anonymous_allowed'] != $config_value)
				{
					$sql = 'DELETE FROM ' . CHAT_USERS_TABLE . '
						WHERE user_id = ' . ANONYMOUS;
					$this->db->sql_query($sql);
				}
				
				$this->config->set($config_name, $config_value);
			}
		}

		if($submit)
		{
			$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_CHAT_CONFIG');
			$notice[] = 'CONFIG_UPDATED';
		}
		
		$this->display_vars($display_vars);
	}
	
	function _mode_pages($action, $submit, &$error, &$notice)
	{
		$this->tpl_name = 'chat_pages';
		
		$page_id = $this->request->variable('id', 0);
		
		switch($action)
		{
			case 'edit':
				$sql = 'SELECT *
					FROM ' . CHAT_PAGES_TABLE . "
					WHERE page_id = $page_id";
				$result = $this->db->sql_query($sql);
				$page_data = $this->db->sql_fetchrow($result);
				$this->db->sql_freeresult($result);
				
				if(!$page_data)
				{
					$action = '';
					break;
				}

				$page_data['page_data'] = ($page_data['page_data']) ? @unserialize($page_data['page_data']) : array();
				
			// no break

			case 'add':
				$display_vars = array(
					'legend1'		=> 'CHAT_PAGE_CONFIG',
					'page_file'			=> array('lang' => 'CHAT_PAGE_FILE',	'type' => 'custom',			'method' => 'make_select',	'params' => array('{KEY}', '{CONFIG_VALUE}', 1, $action)),
					'custom_file'		=> array('lang' => 'CHAT_PAGE_CUSTOM',	'validate' => 'string',		'type' => 'text:40:255',	'display' => false),
					'page_alias'		=> array('lang' => 'CHAT_PAGE_ALIAS',	'validate' => 'string',		'type' => 'text:40:50',		'display' => false),
					'chat_position'		=> array('lang' => 'CHAT_POSITION',		'type' => 'custom',			'method' => 'make_select',	'params' => array('{KEY}', '{CONFIG_VALUE}')),
					'chat_height'		=> array('lang' => 'CHAT_HEIGHT_PAGE',	'validate' => 'int:0:800',	'type' => 'text:4:3'),
					'forum_ids'			=> array('lang' => 'CHAT_PAGE_FORUMS',	'type' => 'custom',			'method' => 'make_select',	'params' => array('{KEY}', '{CONFIG_VALUE}'),	'display' => false),
				);
				
				if($action == 'add')
				{
					$page_data = array(
						'page_alias'	=> '',
						'page_filename'	=> '',
						'page_path'		=> '',
						'page_data'		=> array(),
					);
				}
				
				$page_data['forum_ids'] = (!empty($page_data['page_data']['forum_ids']) ? $page_data['page_data']['forum_ids'] : array());
				
				if($submit)
				{
					$this->new_config = utf8_normalize_nfc($this->request->variable('config', array('' => ''), true));
					
					if($this->new_config['page_file'] == '-')
					{
						if(!preg_match('#^(?:\.\/|\/)?(.*\/)?([\w\d\-\_]+)(\.' . $this->php_ext . ')?$#', $this->new_config['custom_file'], $matches))
						{
							$error[] = 'INVALID_FILE';
						}
						
						if(!sizeof($error))
						{
							$filename = $this->phpbb_root_path . $matches[1] . $matches[2] . $matches[3];
							
							if(!$matches[1] && in_array($matches[2], $this->exclude_files))
							{
								$error[] = 'INVALID_FILE';
							}
							
							if(!$this->new_config['page_alias'])
							{
								$error[] = 'NO_ALIAS';
							}
							
							$this->new_config['page_filename']	= $matches[2] . $matches[3];
							$this->new_config['page_path']		= $matches[1];
						}
					}
					else
					{
						$this->new_config['page_alias']		= $this->new_config['page_file'];
						$this->new_config['page_filename']	= $this->new_config['page_file'] . '.' . $this->php_ext;
						$this->new_config['page_path']		= '';
					}
					
					if(in_array($this->new_config['page_alias'], array('viewforum', 'viewtopic')))
					{
						$this->new_config['forum_ids'] = $this->request->variable('forum_ids', array(0));
						
						$this->new_config['page_data'] = array(
							'forum_ids'		=> $this->new_config['forum_ids'],
						);
					}
					
					// Check if page already exists
					if(!sizeof($error))
					{
						$sql = 'SELECT page_id
							FROM ' . CHAT_PAGES_TABLE . "
							WHERE page_filename = '" . $this->db->sql_escape($this->new_config['page_filename']) . "'
							AND page_path = '" . $this->db->sql_escape($this->new_config['page_path']) . "'
							AND page_id <> $page_id";
						$result = $this->db->sql_query($sql);
						$already_page_id = (int)$this->db->sql_fetchfield('page_id');
						$this->db->sql_freeresult($result);
						
						if($already_page_id)
						{
							$error[] = 'PAGE_ALREADY_EXISTS';
						}
					}
					
					if(!sizeof($error))
					{
						$sql_ary = array(
							'page_alias'	=> str_replace(' ', '_', $this->new_config['page_alias']),
							'page_filename'	=> $this->new_config['page_filename'],
							'page_path'		=> $this->new_config['page_path'],
							'page_data'		=> (!empty($this->new_config['page_data']) ? @serialize($this->new_config['page_data']) : ''),
							'chat_position'	=> $this->new_config['chat_position'],
							'chat_height'	=> (int)$this->new_config['chat_height'],
						);
						
						if($action == 'add')
						{
							$sql = 'INSERT INTO ' . CHAT_PAGES_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
						}
						else
						{
							$sql = 'UPDATE ' . CHAT_PAGES_TABLE . '
								SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . "
								WHERE page_id = $page_id";
						}
						
						$this->db->sql_query($sql);
						
						$this->cache->destroy('_chat_pages');
						
						$action = '';
						break;
					}
				}
				else
				{
					$this->new_config = $page_data;
					
					if($page_data['page_path'])
					{
						$this->new_config = array_merge($this->new_config, array(
							'page_file'		=> '-',
							'custom_file'	=> $page_data['page_path'] . $page_data['page_filename'],
						));
					}
					else
					{
						$this->new_config['page_file']	= $page_data['page_alias'];
						$this->new_config['page_alias']	= '';
					}
				}
				
				if(in_array($this->new_config['page_file'], array('viewforum', 'viewtopic')))
				{
					$display_vars['forum_ids']['display'] = true;
				}
				
				$this->display_vars($display_vars);
				
				$this->template->assign_vars(array(
					'S_EDIT'	=> true,
					'U_BACK'	=> $this->u_action,
					
					'S_HIDDEN_FIELDS'	=> build_hidden_fields(array(
						'action'	=> $action,
						'id'		=> $page_id
					)),
				));
			break;
			
			case 'delete':
				$sql = 'DELETE FROM ' . CHAT_PAGES_TABLE . "
					WHERE page_id = $page_id";
				$this->db->sql_query($sql);
				
				$this->cache->destroy('_chat_pages');
				
				$this->set_json_display(array(
					'action'	=> 'delete_row',
					'row_id'	=> $page_id,
				));
			break;
		}

		if(!$action)
		{
			$sql = 'SELECT *
				FROM ' . CHAT_PAGES_TABLE . '
				ORDER BY page_alias';
			$result = $this->db->sql_query($sql);
			while($row = $this->db->sql_fetchrow($result))
			{
				$title = ($row['page_alias']) ? $row['page_alias'] : str_replace('.' . $this->php_ext, '', $row['page_filename']);
				$title = (isset($this->user->lang[strtoupper($title)]) ? $this->user->lang[strtoupper($title)] : ucfirst($title));
		
				$this->template->assign_block_vars('pagerow', array(
					'S_ID'		=> $row['page_id'],
					'S_TITLE'	=> $title,
					'S_URL'		=> generate_board_url() . '/' . $row['page_path'] . $row['page_filename'],
					
					'U_DELETE'	=> $this->u_action . '&amp;action=delete&amp;id=' . $row['page_id'],
					'U_EDIT'	=> $this->u_action . '&amp;action=edit&amp;id=' . $row['page_id'],
				));
			}
			$this->db->sql_freeresult($result);
			
			$this->template->assign_var('U_PAGE_ADD', $this->u_action . '&amp;action=add');
		}
	}
	
	function _mode_rooms($action, $submit, &$error, &$notice)
	{
		$this->tpl_name = 'chat_rooms';
		
		$room_id = $this->request->variable('id', 0);
		
		switch($action)
		{
			case 'delete':
				if(confirm_box(true))
				{
					if($room_id != CHAT_GUEST_ROOM)
					{
						// Get the title and key of the room before remove
						$sql = 'SELECT room_title, room_key
							FROM ' . CHAT_ROOMS_TABLE . '
							WHERE room_id = ' . $room_id;
						$result = $this->db->sql_query($sql);
						$data = $this->db->sql_fetchrow($result);
						$this->db->sql_freeresult($result);
						
						if($data)
						{
							$data['room_title'] = (isset($this->user->lang[$data['room_title']]) ? $this->user->lang[$data['room_title']] : $data['room_title']);
							
							// Delete the room
							$sql = 'DELETE FROM ' . CHAT_ROOMS_TABLE . '
								WHERE room_id = ' . $room_id;
							$this->db->sql_query($sql);
							
							// Delete the messages of the room
							$sql = 'DELETE FROM ' . CHAT_MESSAGES_TABLE . '
								WHERE dest_key = ' . $data['room_key'];
							$this->db->sql_query($sql);

							$this->log->add('admin', $this->user->data['user_id'], $this->user->ip, 'LOG_CHAT_ROOM_REMOVED', time(), array($data['room_title']));
							$this->cache->destroy('_chat_rooms');
				
							$this->set_json_display(array(
								'action'	=> 'delete_row',
								'row_id'	=> $room_id,
							));
						}
					}
				}
				else
				{
					$this->set_json_display(array(
						'action'	=> 'confirm'
					));
					
					$this->template->assign_vars(array(
						'S_CONFIRM_DIALOG'	=> true,
					));

					confirm_box(false, $this->user->lang['REMOVE_ROOM_CONFIRM'], '', 'chat_ajax.html');
				}
			break;

			case 'edit':
				$sql = 'SELECT *
					FROM ' . CHAT_ROOMS_TABLE . "
					WHERE room_id = $room_id";
				$result = $this->db->sql_query($sql);
				$room_data = $this->db->sql_fetchrow($result);
				$this->db->sql_freeresult($result);
				
				if(!$room_data)
				{
					$action = '';
					break;
				}
				
				$room_auth = @unserialize($room_data['room_data']);
				
				$room_data['room_groups']	= (empty($room_auth['groups']) ? array() : $room_auth['groups']);
				$room_data['room_users']	= (empty($room_auth['users']) ? '' : implode("\n", $room_auth['users']));
				
			// no break

			case 'add':
				$display_vars = array(
					'legend1'		=> 'CHAT_ROOM_CONFIG',
					'room_title'			=> array('lang' => 'CHAT_ROOM_TITLE',		'validate' => 'string:1:255',	'type' => 'text:40:255'),
					'room_enabled'			=> array('lang' => 'CHAT_ROOM_ENABLED',		'validate' => 'bool',			'type' => 'radio:yes_no'),
					'room_autopurge_time'	=> array('lang' => 'CHAT_ROOM_AUTOPURGE',	'validate' => 'int',			'type' => 'custom',	'method' => 'make_select',	'params' => array('{KEY}', '{CONFIG_VALUE}')),
					'room_msg_limit'		=> array('lang' => 'CHAT_ROOM_MSG_LIMIT',	'validate' => 'int:0:99999',	'type' => 'number:0:99999'),
				);
				
				if($room_id != CHAT_GUEST_ROOM)
				{
					$display_vars += array(
						'legend2'		=> 'CHAT_ROOM_AUTH',
						'room_groups'	=> array('lang' => 'CHAT_ROOM_GROUPS',	'type' => 'custom',	'method' => 'make_select',	'params' => array('{KEY}', '{CONFIG_VALUE}')),
						'room_users'	=> array('lang' => 'CHAT_ROOM_USERS',	'type' => 'textarea:5:5'),
					);
				}
				
				if($action == 'add')
				{
					$room_id = 0;

					$room_data = array(
						'room_enabled'	=> true,
						'room_groups'	=> array(),
						'room_users'	=> '',
					);
				}
				
				$this->new_config = $room_data;
				
				if($submit)
				{
					$this->new_config = utf8_normalize_nfc($this->request->variable('config', array('' => ''), true));
					$this->new_config['room_groups'] = $this->request->variable('room_groups', array(0));
					
					// We validate the complete config if whished
					validate_config_vars($display_vars, $this->new_config, $error);
					
					$data = array();
					
					if(!sizeof($error))
					{
						if($room_id != CHAT_GUEST_ROOM)
						{
							if(!empty($this->new_config['room_groups']))
							{
								$data['groups'] = $this->new_config['room_groups'];
							}
							
							if($this->new_config['room_users'])
							{
								$user_ary = array();
								
								foreach(explode("\n", $this->new_config['room_users']) as $username)
								{
									$username = trim($username);
									
									if($username)
									{
										$user_ary[] = utf8_clean_string($username);
									}
								}
								
								if(sizeof($user_ary))
								{
									$data['users'] = array();

									$sql = 'SELECT user_id, username
										FROM ' . USERS_TABLE . '
										WHERE ' . $this->db->sql_in_set('username_clean', $user_ary);
									$result = $this->db->sql_query($sql);
									while($row = $this->db->sql_fetchrow($result))
									{
										$data['users'][$row['user_id']] = $row['username'];
									}
									$this->db->sql_freeresult($result);
								}
							}
						}

						$sql_ary = array(
							'room_title'			=> $this->new_config['room_title'],
							'room_enabled'			=> ($room_id == CHAT_GUEST_ROOM) ? 1 : $this->new_config['room_enabled'],
							'room_autopurge_time'	=> $this->new_config['room_autopurge_time'],
							'room_msg_limit'		=> $this->new_config['room_msg_limit'],
							'room_data'				=> (sizeof($data) ? serialize($data) : ''),
						);
						
						if($action == 'add')
						{
							// Get max order
							$sql = 'SELECT MAX(room_order) AS max_order
								FROM ' . CHAT_ROOMS_TABLE;
							$result = $this->db->sql_query($sql);
							$sql_ary['room_order'] = (int)$this->db->sql_fetchfield('max_order') + 1;
							$this->db->sql_freeresult($result);
							
							$sql_ary['room_key'] = time() - 1001;

							$sql = 'INSERT INTO ' . CHAT_ROOMS_TABLE . ' ' . $this->db->sql_build_array('INSERT', $sql_ary);
							$notice[] = 'CHAT_ROOM_ADDED';
						}
						else
						{
							$sql = 'UPDATE ' . CHAT_ROOMS_TABLE . '
								SET ' . $this->db->sql_build_array('UPDATE', $sql_ary) . "
								WHERE room_id = $room_id";
								
							$notice[] = 'CHAT_ROOM_UPDATED';
						}
						
						$this->db->sql_query($sql);
						
						$this->cache->destroy('_chat_rooms');
					}

					$action = '';
					break;
				}

				if($room_id == CHAT_GUEST_ROOM)
				{
					$display_vars['room_enabled']['display'] = false;
				}
				
				$this->display_vars($display_vars);
				
				$this->template->assign_vars(array(
					'S_EDIT'	=> true,
					'S_HIDDEN_FIELDS'	=> build_hidden_fields(array(
						'action'	=> $action,
						'id'		=> $room_id
					)),
					
					'U_BACK'			=> $this->u_action,
					'U_FIND_USERNAME'	=> append_sid($this->phpbb_root_path . 'memberlist.' . $this->php_ext, 'mode=searchuser&amp;form=acp_chat_rooms&amp;field=room_users')
				));
			break;
			
			case 'sort':
				$rows = $this->request->variable('row', array(0 => 0));
				
				foreach($rows as $position => $room_id)
				{
					$sql = 'UPDATE ' . CHAT_ROOMS_TABLE . '
						SET room_order = ' . ((int)$position + 1) . "
						WHERE room_id = $room_id";
					$this->db->sql_query($sql);
				}
				
				$this->cache->destroy('_chat_rooms');
				exit_handler();
			break;
		}
		
		if(!$action)
		{
			$room_ary = array();

			$sql = 'SELECT *
				FROM ' . CHAT_ROOMS_TABLE . '
				ORDER BY room_order';
			$result = $this->db->sql_query($sql);
			while($row = $this->db->sql_fetchrow($result))
			{
				$title 		= $row['room_title'];
				$title 		= (isset($this->user->lang[strtoupper($title)]) ? $this->user->lang[strtoupper($title)] : ucfirst($title));

				$this->template->assign_block_vars('roomrow', array(
					'S_ID'		=> $row['room_id'],
					'S_KEY'		=> $row['room_key'],
					'S_TITLE'	=> $title,
					
					'U_DELETE'	=> ($row['room_id'] != CHAT_GUEST_ROOM) ? $this->u_action . '&amp;action=delete&amp;id=' . $row['room_id'] : '',
					'U_EDIT'	=> $this->u_action . '&amp;action=edit&amp;id=' . $row['room_id'],
				));
			}
			$this->db->sql_freeresult($result);

			$this->template->assign_vars(array(
				'S_HIDDEN_FIELDS'	=> build_hidden_fields(array(
					'action'	=> 'sort'
				)),
				
				'U_ROOM_ADD'	=> $this->u_action . '&amp;action=add'
			));
		}
	}
	
	function _mode_texts($action, $submit, &$error, &$notice)
	{
		$this->tpl_name = 'chat_texts';
		
		$text_id 	= $this->request->variable('id', 0);
		$text_type	= $this->request->variable('type', 0);
		
		$text_ary = array(
			CHAT_TEXT_NOTICE	=> array('title' => 'CHAT_NOTICES',	'rows' => array()),
			CHAT_TEXT_TIP		=> array('title' => 'CHAT_TIPS',	'rows' => array()),
			CHAT_TEXT_RULE		=> array('title' => 'CHAT_RULES',	'rows' => array()),
		);
		
		switch($action)
		{
			case 'edit':
				$sql = 'SELECT text_content, bbcode_uid
					FROM ' . CHAT_TEXTS_TABLE . "
					WHERE text_id = $text_id
					AND text_type = $text_type";
				$result = $this->db->sql_query($sql);
				$text_row = $this->db->sql_fetchrow($result);
				$this->db->sql_freeresult($result);
				
				if(!$text_row)
				{
					$action = '';
					break;
				}
				
				decode_message($text_row['text_content'], $text_row['bbcode_uid']);
				
				$this->new_config['text_content'] = $text_row['text_content'];
				unset($text_row);
				
			// no break

			case 'add':
				if(!isset($text_ary[$text_type]['title']))
				{
					$action = '';
					break;
				}

				$display_vars = array(
					'legend1'		=> 'CONTENT',
					'text_content'	=> array('lang' => $text_ary[$text_type]['title'] . '_ITEM',	'validate'	=> 'string:1',	'type' => 'textarea:5:40'),
				);
				
				if($action == 'add')
				{
					$this->new_config['text_content'] = '';
				}
				
				if($submit)
				{
					$this->new_config = utf8_normalize_nfc($this->request->variable('config', array('' => ''), true));
					
					// We validate the complete config if whished
					validate_config_vars($display_vars, $this->new_config, $error);
					
					// Do not write values if there is an error
					if(!sizeof($error))
					{
						$message = $this->new_config['text_content'];

						$this->new_config['bbcode_uid'] = $this->new_config['bbcode_bitfield'] = $options = '';
						$this->chat->generate_text_for_storage($this->new_config['text_content'], $this->new_config['bbcode_uid'], $this->new_config['bbcode_bitfield'], $options, $this->config['allow_bbcode'], $this->config['allow_post_links'], $this->config['allow_smilies']);
						
						if($action == 'add')
						{
							// Get last text position
							$sql = 'SELECT MAX(text_order) AS last_position
								FROM ' . CHAT_TEXTS_TABLE;
							$result = $this->db->sql_query($sql);
							$this->new_config['text_order'] = (int)$this->db->sql_fetchfield('last_position') + 1;
							$this->db->sql_freeresult($result);
							
							$this->new_config['text_type'] = $text_type;

							$sql = 'INSERT INTO ' . CHAT_TEXTS_TABLE . ' ' . $this->db->sql_build_array('INSERT', $this->new_config);
						}
						else
						{
							$sql = 'UPDATE ' . CHAT_TEXTS_TABLE . '
								SET ' . $this->db->sql_build_array('UPDATE', $this->new_config) . "
								WHERE text_id = $text_id
								AND text_type = $text_type";
						}
						$this->db->sql_query($sql);
	
						$this->cache->destroy('_chat_texts');
						
						$action = '';
						break;
					}
				}
				
				$this->display_vars($display_vars);
				
				$this->page_title = $text_ary[$text_type]['title'] . '_' . strtoupper($action);
				
				$this->template->assign_vars(array(
					'S_EDIT'	=> true,
					'U_BACK'	=> $this->u_action,
					
					'S_HIDDEN_FIELDS'	=> build_hidden_fields(array(
						'action'	=> $action,
						'type'		=> $text_type,
						'id'		=> $text_id,
					)),
				));
			break;
			
			case 'delete':
				$sql = 'DELETE FROM ' . CHAT_TEXTS_TABLE . "
					WHERE text_id = $text_id
					AND text_type = $text_type";
				$this->db->sql_query($sql);

				$this->cache->destroy('_chat_texts');
				
				$this->set_json_display(array(
					'action'	=> 'delete_row',
					'row_id'	=> $text_id,
				));
			break;
			
			case 'sort':
				$rows = $this->request->variable('row', array(0 => 0));
				
				foreach($rows as $position => $text_id)
				{
					$sql = 'UPDATE ' . CHAT_TEXTS_TABLE . '
						SET text_order = ' . ((int)$position + 1) . "
						WHERE text_id = $text_id";
					$this->db->sql_query($sql);
				}
				
				$this->cache->destroy('_chat_texts');
				exit_handler();
			break;
		}
		
		if(!$action)
		{
			$sql = 'SELECT *
				FROM ' . CHAT_TEXTS_TABLE . '
				ORDER BY text_order';
			$result = $this->db->sql_query($sql);
			while($row = $this->db->sql_fetchrow($result))
			{
				$row_type = (int)$row['text_type'];

				if(!isset($text_ary[$row_type]))
				{
					continue;
				}
				
				$text_ary[$row_type]['rows'][] = $row;
			}
			$this->db->sql_freeresult($result);
			
			foreach($text_ary as $text_type => $data_ary)
			{
				$s_title = $data_ary['title'];
	
				$this->template->assign_block_vars('textrow', array(
					'S_LEGEND'			=> (isset($this->user->lang[$s_title . '_TITLE']) ? $this->user->lang[$s_title . '_TITLE'] : $s_title),
					'S_EXPLAIN'			=> (isset($this->user->lang[$s_title . '_EXPLAIN']) ? $this->user->lang[$s_title . '_EXPLAIN'] : ''),
					'S_IS_EMPTY'		=> (sizeof($data_ary['rows']) ? false : true),
					'S_BUTTON_TITLE'	=> $this->user->lang($s_title . '_ADD'),
					'U_ADD'				=> $this->u_action . '&amp;action=add&amp;type=' . $text_type,
				));
				
				foreach($data_ary['rows'] as $row)
				{
					/*
					 * bbcode_bitfield is empty in some cases in phpBB 3.2 so, check if the text have some [/ to detect the presence of bbcode.
					 * If no bbcode, we decode the text to allow HTML tags.
					*/
					if(strpos($row['text_content'], '[/') !== false)
					{
						$parse_flags = ($row['bbcode_bitfield'] ? OPTION_FLAG_BBCODE : 0) | OPTION_FLAG_SMILIES;
						$row['text_content'] = generate_text_for_display($row['text_content'], $row['bbcode_uid'], $row['bbcode_bitfield'], $parse_flags, true);
					}
					else
					{
						$row['text_content'] = htmlspecialchars_decode($row['text_content']);
					}
					
					$this->chat->parse_lang_variables($row['text_content']);

					$row['text_content'] = bbcode_nl2br($row['text_content']);
					$row['text_content'] = smiley_text($row['text_content']);
					
					$this->template->assign_block_vars('textrow.item', array(
						'S_CONTENT'		=> $row['text_content'],
						'S_ID'			=> $row['text_id'],
						
						'U_DELETE'		=> $this->u_action . '&amp;action=delete&amp;type=' . $text_type . '&amp;id=' . $row['text_id'],
						'U_EDIT'		=> $this->u_action . '&amp;action=edit&amp;type=' . $text_type . '&amp;id=' . $row['text_id'],
					));
				}
			}
			
			$this->template->assign_vars(array(
				'S_HIDDEN_FIELDS'	=> build_hidden_fields(array(
					'action'	=> 'sort'
				))
			));
		}
	}
	
	function display_vars(&$display_vars)
	{
		foreach($display_vars as $config_key => $vars)
		{
			if(!is_array($vars) && strpos($config_key, 'legend') === false)
			{
				continue;
			}

			if(strpos($config_key, 'legend') !== false)
			{
				$this->template->assign_block_vars('options', array(
					'S_LEGEND'		=> true,
					'LEGEND'		=> (isset($this->user->lang[$vars])) ? $this->user->lang[$vars] : $vars)
				);

				continue;
			}

			$type 		= explode(':', $vars['type']);
			$content 	= build_cfg_template($type, $config_key, $this->new_config, $config_key, $vars);

			if(empty($content))
			{
				continue;
			}

			$this->template->assign_block_vars('options', array(
				'KEY'			=> $config_key,
				'TITLE'			=> (isset($this->user->lang[$vars['lang']])) ? $this->user->lang[$vars['lang']] : $vars['lang'],
				'S_EXPLAIN'		=> (isset($this->user->lang[$vars['lang'] . '_EXPLAIN'])) ? $this->user->lang[$vars['lang'] . '_EXPLAIN'] : '',
				'CONTENT'		=> $content,
				'IS_HIDDEN'		=> (isset($vars['display']) ? !$vars['display'] : false),
			));

			unset($display_vars[$config_key]);
		}
	}
	
	function make_select($key, $select_ids = '', $size = 5, $extra = '')
	{
		$multiple 	= false;
		$in_group	= false;
		
		switch($key)
		{
			case 'chat_bbcode_format':
				$ary = array(
					'button'	=> 'CHAT_BBCODE_INBUTTON',
					'select'	=> 'CHAT_BBCODE_INSELECT',
				);
			break;

			case 'chat_direction':
				$ary = array(
					'down'		=> 'CHAT_DIRECTION_DOWN',
					'up'		=> 'CHAT_DIRECTION_UP',
				);
			break;
			
			case 'chat_disallowed_bbcode':
				$bbcodes = array(
					'default' 	=> array(
						1	=> 'b',
						2	=> 'i',
						7	=> 'u',
						8	=> 'code',
						6	=> 'color',
						11	=> 'flash',
						4	=> 'img',
						9	=> 'list',
						0	=> 'quote',
						5	=> 'size',
						3	=> 'url'
					),
					'custom'	=> array()
				);
				
				// Custom BBcodes
				$sql = 'SELECT bbcode_id, bbcode_tag
					FROM ' . BBCODES_TABLE . '
					WHERE display_on_posting = 1
					ORDER BY bbcode_tag';
				$result = $this->db->sql_query($sql);
				while($row = $this->db->sql_fetchrow($result))
				{
					$bbcodes['custom'][$row['bbcode_id']] = $row['bbcode_tag'];
				}
				$this->db->sql_freeresult($result);
				
				$ary = array('legend1' => 'DEFAULT_BBCODES');
				
				foreach($bbcodes['default'] as $bbcode_id => $bbcode_tag)
				{
					$ary[$bbcode_id] = ucfirst($bbcode_tag);
				}
				
				if(sizeof($bbcodes['custom']))
				{
					$ary['legend2'] = 'CUSTOM_BBCODES';
					
					foreach($bbcodes['custom'] as $bbcode_id => $bbcode_tag)
					{
						$ary[$bbcode_id] = ucfirst($bbcode_tag);
					}
				}
				
				$bitfield = new \bitfield($select_ids);
				$select_ids = $bitfield->get_all_set();

				$multiple = true;
			break;
			
			case 'chat_forum_posts':
				$ary = array(
					CHAT_SHOW_NONE		=> 'CHAT_SHOW_NONE',
					CHAT_SHOW_TOPICS	=> 'CHAT_SHOW_TOPICS',
					CHAT_SHOW_POSTS		=> 'CHAT_SHOW_POSTS',
				);
			break;
			
			case 'chat_position':
				$ary = array(
					'top'		=> 'CHAT_POSITION_TOP',
					'bottom'	=> 'CHAT_POSITION_BOTTOM',
				);
			break;
			
			case 'forum_ids':
				$forum_ary = make_forum_select($select_ids, false, true, false, true, false, true);
				$ary = array();

				$legend_id = 1;
				
				foreach($forum_ary as $forum_id => $row)
				{
					if(!$row['padding'])
					{
						$ary['legend' . $legend_id] = $row['forum_name'];
						$legend_id++;
					}
					else
					{
						$ary[$forum_id] = $row['padding'] . $row['forum_name'];
					}
				}
				
				$multiple = true;
			break;
			
			case 'page_file':
				$ary = array(''	=> 'SELECT_PAGE');
				
				if($extra == 'add')
				{
					// Exclude files already in use
					$sql = 'SELECT page_alias
						FROM ' . CHAT_PAGES_TABLE . "
						WHERE page_path = ''";
					$result = $this->db->sql_query($sql);
					while($row = $this->db->sql_fetchrow($result))
					{
						$this->exclude_files[] = $row['page_alias'];
					}
					$this->db->sql_freeresult($result);
				}
				
				// Read all the avaliable files in phpbb root path
				if($dir = @opendir($this->phpbb_root_path))
				{
					$file_ary = array();

					while(($file = @readdir($dir)) !== false)
					{
						if(($pos = strpos($file, '.' . $this->php_ext)) !== false)
						{
							$filename = substr($file, 0, $pos);
						
							if($filename && !in_array($filename, $this->exclude_files))
							{
								$file_ary[$filename] = $file;
							}
						}
					}
					closedir($dir);
					
					if(sizeof($file_ary))
					{
						asort($file_ary);
						$ary = array_merge($ary, array('legend1' => 'FORUM_FILES'), $file_ary);
					}
				}
				
				$ary = array_merge($ary, array(
					'legend2'	=> 'CUSTOM_FILES',
					'-'			=> 'CUSTOM_FILE',
				));
			break;
			
			case 'room_groups':
				// Get all the groups
				$sql = 'SELECT DISTINCT group_type, group_name, group_id
					FROM ' . GROUPS_TABLE . '
					ORDER BY group_type DESC, group_name ASC';
				$result = $this->db->sql_query($sql);
				while($row = $this->db->sql_fetchrow($result))
				{
					$ary[$row['group_id']] = (($row['group_type'] == GROUP_SPECIAL) ? $this->user->lang['G_' . $row['group_name']] : $row['group_name']);
				}
				$this->db->sql_freeresult($result);

				$multiple = true;
			break;
			
			case 'room_autopurge_time':
				$ary = array(
					0			=> 'DISABLED',
					86400		=> 'EACH_DAY',
					604800		=> 'EACH_WEEK',
					2592000		=> 'EACH_MONTH',
					31104000	=> 'EACH_YEAR',
				);
			break;
			
			default:
				return '';
			break;
		}
		
		if(!is_array($select_ids))
		{
			$select_ids = explode('|', $select_ids);
		}
		
		if($multiple)
		{
			$result = '<select id="' . $key . '" name="' . $key . '[]" multiple="multiple" size="' . $size . '">';
		}
		else
		{
			$select_ids = array($select_ids[0]);
			$result = '<select id="' . $key . '" name="config[' . $key . ']">';
		}
		
		foreach($ary as $value => $lang)
		{
			$title	= (isset($this->user->lang[$lang]) ? $this->user->lang[$lang] : $lang);

			if(strpos($value, 'legend') !== false)
			{
				$result .= (($in_group) ? '</optgroup>' : '') . '<optgroup label="' . $title . '">';
				$in_group = true;
				
				continue;
			}
			
			$selected = (in_array($value, $select_ids) ? ' selected="selected"' : '');
			$result .= '<option value="' . $value . '"' . $selected . '>' . $title . '</option>';
		}
		
		if($in_group)
		{
			$result .= '</optgroup>';
		}
		
		$result .= '</select>';
		
		return $result;
	}
	
	function set_json_display($json)
	{
		$this->tpl_name = 'chat_ajax';
		$this->template->assign_var('S_JSON_DATA', json_encode($json));
	}
}
