<?php
/**
* Usage:
* Download and unzip the file then RENAME it to index.php
* Into the code find "your site name goes here" and put your Board's/Site's name in there.
* SAVE this file.
*
* Rename your (i.e.: www.mydomain.com/phpBB3/index.php) to something else you like (as a backup)
* Upload THIS renamed file to your Board's root (i.e.: www.mydomain.com/phpBB3/)
* Point your browser to i.e.: www.mydomain.com/phpBB3/index.php), once finished delete this
* file and RENAME your backuped file back to (i.e.: www.mydomain.com/phpBB3/index.php).
*
* @package Maintenance Redirection v1.0.0 (11 May 2016)
* @copyright (c) 2016 3Di (Marco T.)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/
header("HTTP/1.1 503 Service Unavailable");
header("Status: 503 Service Unavailable");
header("Retry-After: 3600");

/* Create a HTML5 page */
echo '<!DOCTYPE html>';
echo '<html>';
echo '<head>';
echo '<title>Temporarily Unavailable</title>';
echo '<meta name="robots" content="none" />';
echo '<style type="text/css">
body {
	font-size: 1.1em;
	background-color: lightyellow ;
	width: 1000px;
	margin: 1em auto 0;
}
</style>';
echo '</head>';
echo '<body>';
echo 'The site <font style="color:darkblue"><i><b>your site name goes here</b></i></font> is under temporary maintenance.';
echo '<br /><br />';
echo 'Due to the fact we don\'t want that search engines index that page while doing this job..';
echo '<br />';
echo '.. the <i>"HTTP/1.1 503 Service Unavailable"</i> Header is given.';
echo '<br /><br />';
echo 'Hope you\'ll understand. :) .. <font style="color:darkgreen"><b>The Board\'s management.</b></font>';
echo '<br /><br />';
echo 'We are doing our best to make this story short. Please try again later.';
echo '</body>';
echo '</html>';
echo '<br /><br />';
echo '<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top"><input type="hidden" name="cmd" value="_s-xclick"><input type="hidden" name="hosted_button_id" value="ZLN6KTV2WQSRN"><input type="image" src="https://www.paypal.com/en_GB/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="PayPal – The safer, easier way to pay online."><img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1"><font color="darkred"> Help the development of this Tool by a donation of your choice.</font></form>';
