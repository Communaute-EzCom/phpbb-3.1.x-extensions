<?php
/***
* Usage: Download and unzip the file, upload it to your Board's root (i.e.: www.mydomain.com/phpBB3/)
*	 Point your browser to i.e.: www.mydomain.com/phpBB3/modission_reset_3110.php) and follow instructions.
*
* Version 2.2.5 (3Di in 13-Ott-2016 for phpBB 3.1.10) - Oyabun1 2015
*
* This script is free software. It comes without any warranty.
* license http://opensource.org/licenses/GPL-2.0 GNU General Public License v2.
*
* 3Di side note: make sure you have a backup of your Database before to run this tool
*/

define('IN_PHPBB', true);
$phpbb_root_path = (defined('PHPBB_ROOT_PATH')) ? PHPBB_ROOT_PATH : './';
$phpEx = substr(strrchr(__FILE__, '.'), 1);
include($phpbb_root_path . 'common.' . $phpEx);
include_once($phpbb_root_path . 'includes/functions_admin.' . $phpEx);

// Start session management
$user->session_begin();
$auth->acl($user->data);

/* If ANONYMOUS = login box */
if ((int) $user->data['user_id'] == ANONYMOUS)
{
	login_box(request_var('redirect', "modission_reset_3110.$phpEx"));
}

// Limit this to founders or admins
if ((int) $user->data['user_type'] !== USER_FOUNDER || !$auth->acl_get('a_'))
{
	trigger_error('You don\'t have permission to alter the database.
	You need to be logged in as a founder or administrator.');
}

$ascraeus = isset($request) && ($request instanceof \phpbb\request\request_interface) ? true : false;

// Check if any extensions are installed, used later to control available options
$ext_exists = false;
if($ascraeus)
{
	$sql = "SHOW TABLES LIKE '" . EXT_TABLE . "'";
	$result = $db->sql_query($sql);
	if($result->num_rows > 0)
	{
		$sql = 'SELECT ext_name FROM ' . EXT_TABLE;
		$result = $db->sql_query($sql);
		if($result->num_rows > 0)
		{
			$ext_exists = true;
		}
	}
}

// Create a HTML5 page to add some form elements and display stuff
echo '<!DOCTYPE html>';
echo '<html>';
echo '<head>';
echo '<meta http-equiv="content-type" content="text/html; charset=UTF-8" />';
echo '<title>' . basename(__FILE__) . '</title>';

echo '<style type="text/css">
	body {
		font-size: 1em;
		background-color: #C0C0C0 ;
		width: 600px;
		margin: 2em auto 0;
	}

	form {
		text-align: center;
		line-height: 230%;
	}

	fieldset {
		-moz-border-radius:7px;
		border-radius: 7px;
		-webkit-border-radius: 7px;
	}

	h3 {
		text-align: center;
	}
	label {
		cursor: pointer;
		background-color: #FFD700;
		border-style: outset;
		border-width; 1px;
		border-radius: 7px;
		border-color: #808080;
		font-size: 1.1em;
		padding: 2px;
		margin: 2px;
	}

	input[type="checkbox"]:disabled {
    opacity:0;
	}

	input[type="checkbox"]{
		cursor: pointer;
	}

	img.mid {
		display: block;
		margin-top: 1em;
		margin-left: auto;
		margin-right: auto
	}

	/* Buttons based on Pressable CSS Buttons by Joshua Hibbert */
	.button {
		background-image: -webkit-linear-gradient(hsla(0,0%,100%,.05), hsla(0,0%,0%,.1));
		background-image:    -moz-linear-gradient(hsla(0,0%,100%,.05), hsla(0,0%,0%,.1));
		background-image:     -ms-linear-gradient(hsla(0,0%,100%,.05), hsla(0,0%,0%,.1));
		background-image:      -o-linear-gradient(hsla(0,0%,100%,.05), hsla(0,0%,0%,.1));
		background-image:         linear-gradient(hsla(0,0%,100%,.05), hsla(0,0%,0%,.1));
		border: none;
		border-radius: 1.25em;
		box-shadow: inset 0 0 0 1px hsla(0,0%,0%,.25),
					inset 0 2px 0 hsla(0,0%,100%,.1),
					inset 0 1.2em 0 hsla(0,0%,100%,.05),
					inset 0 -.2em 0 hsla(0,0%,100%,.1),
					inset 0 -.25em 0 hsla(0,0%,0%,.5),
					0 .25em .25em hsla(0,0%,0%,.1);
		color: #fff;
		text-shadow: 0 -1px 1px hsla(0,0%,0%,.25);
		cursor: pointer;
		display: inline-block;
		font-family: sans-serif;
		font-size: 1.1em;
		font-weight: bold;
		line-height: 150%;
		margin: 0 .5em;
		padding: .25em .75em .5em;
		position: relative;
		text-decoration: none;
		vertical-align: middle;
	}
	.button:hover {
		outline: none;
	}
	.button:hover,
	.button:focus {
		box-shadow: inset 0 0 0 1px hsla(0,0%,0%,.25),
					inset 0 2px 0 hsla(0,0%,100%,.1),
					inset 0 1.2em 0 hsla(0,0%,100%,.05),
					inset 0 -.2em 0 hsla(0,0%,100%,.1),
					inset 0 -.25em 0 hsla(0,0%,0%,.5),
					inset 0 0 0 3em hsla(0,0%,100%,.2),
					0 .25em .25em hsla(0,0%,0%,.1);
	}
	.button:active {
		box-shadow: inset 0 0 0 1px hsla(0,0%,0%,.25),
					inset 0 2px 0 hsla(0,0%,100%,.1),
					inset 0 1.2em 0 hsla(0,0%,100%,.05),
					inset 0 0 0 3em hsla(0,0%,100%,.2),
					inset 0 .25em .5em hsla(0,0%,0%,.05),
					0 -1px 1px hsla(0,0%,0%,.1),
					0 1px 1px hsla(0,0%,100%,.25);
		margin-top: .25em;
		outline: none;
		padding-bottom: .5em;
	}

	.green {
		background-color: #228B22;
	}

	.remove_me {
		color: #FFFFFF;
		width: 560px;
		margin: 2em auto 0;
		padding: .5em;
		font-size: 1.1em;
		background-color: #8B0000;
	}

</style>';

echo '</head>';
echo '<body>';

// Create a form with some checkboxes
echo '<h3>Delete Non-standard Modules and Permissions, and AutoMOD</h3>';
echo '<fieldset><legend><strong>Check selection(s) and click the Run button.</strong></legend>';
echo '<form action="' . basename(__FILE__) . '" method="post" onsubmit="return confirm(\'Make sure you first have a database backup. \n If you click OK there is no going back.\')">';
if(!$ext_exists && $ascraeus)
{
	echo '<label title="Remove non-standard modules"><input type="checkbox" name="chkModules" value="Yes" checked />
		Modules&nbsp;</label>&nbsp;';
}
if(!$ext_exists && $ascraeus)
{
	echo '<label title="Remove non-standard permissions"><input type="checkbox" name="chkPerms"
		value="Yes" checked />Permissions&nbsp;</label>&nbsp;';
}
echo '<label title="Remove AutoMOD database changes"><input type="checkbox" name="chkAmod"
	value="Yes" checked />AutoMOD&nbsp;</label>&nbsp;';
echo '<p><button type="submit" class="button green";>Run</button></p>';
echo '</form>';
echo '</fieldset><br>';
echo '<fieldset style="background-color:#F5FCFF; border-color:#00CC00; border-style: solid;"><legend>
		<strong>Result</strong></legend>';

// Try to delete this file
function remove_me()
{
	@unlink(__FILE__);  // Eat any errors

	// Windows IIS servers may have a problem with unlinking recently created files.
	// So check if file exists and give a message
	if (file_exists(__FILE__))
	{
		echo '<p class="remove_me">File could not be deleted. You will
		need to manually delete the ' . basename(__FILE__) . ' file from the server.</p>';
	}
}

// Use request_var() to get the returned values of selections
$chk_modules = (request_var('chkModules', ''));
$chk_perms = (request_var('chkPerms', ''));
$chk_autom = (request_var('chkAmod', ''));

// Some version checking
// includes/constants.php
$version = PHPBB_VERSION;

// config table
$sql = 'SELECT config_value FROM ' . CONFIG_TABLE . ' WHERE config_name = "version"';
$result = $db->sql_query($sql);
$row = $db->sql_fetchrow($result);
$db_vers = $row['config_value'];
$db->sql_freeresult($result);

// First check if versions are the same
if ($version == $db_vers)
{
	// AutoMOD stuff
	// Remove database changes from AutoMOD install
	if($chk_autom == 'Yes')
	{
		// Drop modules if not already cleaned
		if (!$chk_modules == 'Yes')
		{
			$sql = 'DELETE FROM ' . MODULES_TABLE . ' WHERE module_langname IN (
				"ACP_CAT_MODS",
				"ACP_MODS",
				"ACP_AUTOMOD",
				"ACP_AUTOMOD_CONFIG"
			)';
			$result = $db->sql_query($sql);
			$num_mods_deleted = $db->sql_affectedrows();
			$db->sql_freeresult($result);
			echo 'Modules deleted: ' . $num_mods_deleted . '<br>';
		}
		// Drop permission if not already cleaned
		if (!$chk_perms == 'Yes')
		{
			$sql = 'DELETE FROM ' . ACL_OPTIONS_TABLE . ' WHERE auth_option IN (
				"a_mods"
			)';
			$result = $db->sql_query($sql);
			$num_perms_deleted = $db->sql_affectedrows();
			$db->sql_freeresult($result);
			echo 'Permissions deleted: ' . $num_perms_deleted . '<br>';
		}
		// Drop the rows from the config table
		$sql = 'DELETE FROM ' . CONFIG_TABLE . ' WHERE config_name IN (
			"am_dir_perms",
			"am_file_perms",
			"automod_version",
			"compress_method",
			"ftp_method",
			"ftp_host",
			"ftp_username",
			"ftp_root_path",
			"ftp_port",
			"ftp_timeout",
			"preview_changes",
			"write_method"
		)';
		$result = $db->sql_query($sql);
		$num_config_deleted = $db->sql_affectedrows();
		$db->sql_freeresult($result);
		echo 'Config values deleted: ' . $num_config_deleted . '<br>';

		// Drop the mods table
		define('MODS_TABLE', $table_prefix . 'mods');
		$result = $db->sql_query('SHOW TABLE STATUS LIKE \'' . MODS_TABLE . '\'');
		if($result->num_rows > 0)
		{
			$db->sql_query('DROP TABLE IF EXISTS ' . MODS_TABLE);
			$table_drop = '<code>' . MODS_TABLE . '</code> table dropped<br>';
		}
		else
		{
			$table_drop = '<code>' . MODS_TABLE . '</code> table not found<br>';
		}
		echo $table_drop;

		// Config values, permissions, and modules are cached so we'll do a purge
		$cache->purge();
		// We'll also clear the cached user permissions
		$auth->acl_clear_prefetch();
		// And throw in a log entry
		add_log('admin', 'LOG_PURGE_CACHE');
	}

	// We need to be more careful in removing other modules and permissions, so check the version is in the verified range
	if ( version_compare(PHPBB_VERSION, "3.1.10", "=") )
	{
			// Remove non standard modules
			if($chk_modules == 'Yes' && !$ext_exists)
			{
				// If modules aren't in the list they are deleted otherwise they are ignored
				$sql = 'DELETE FROM ' . MODULES_TABLE . ' WHERE module_langname NOT IN (
				"ACP_CAT_GENERAL",
				"ACP_QUICK_ACCESS",
				"ACP_BOARD_CONFIGURATION",
				"ACP_CLIENT_COMMUNICATION",
				"ACP_SERVER_CONFIGURATION",
				"ACP_CAT_FORUMS",
				"ACP_MANAGE_FORUMS",
				"ACP_FORUM_BASED_PERMISSIONS",
				"ACP_CAT_POSTING",
				"ACP_MESSAGES",
				"ACP_ATTACHMENTS",
				"ACP_CAT_USERGROUP",
				"ACP_CAT_USERS",
				"ACP_GROUPS",
				"ACP_USER_SECURITY",
				"ACP_CAT_PERMISSIONS",
				"ACP_GLOBAL_PERMISSIONS",
				"ACP_FORUM_BASED_PERMISSIONS",
				"ACP_PERMISSION_ROLES",
				"ACP_PERMISSION_MASKS",
				"ACP_CAT_CUSTOMISE",
				"ACP_STYLE_MANAGEMENT",
				"ACP_EXTENSION_MANAGEMENT",
				"ACP_LANGUAGE",
				"ACP_CAT_MAINTENANCE",
				"ACP_FORUM_LOGS",
				"ACP_CAT_DATABASE",
				"ACP_CAT_SYSTEM",
				"ACP_AUTOMATION",
				"ACP_GENERAL_TASKS",
				"ACP_MODULE_MANAGEMENT",
				"ACP_CAT_DOT_MODS",
				"ACP_ATTACHMENT_SETTINGS",
				"ACP_ATTACHMENT_SETTINGS",
				"ACP_MANAGE_EXTENSIONS",
				"ACP_EXTENSION_GROUPS",
				"ACP_ORPHAN_ATTACHMENTS",
				"ACP_MANAGE_ATTACHMENTS",
				"ACP_BAN_EMAILS",
				"ACP_BAN_IPS",
				"ACP_BAN_USERNAMES",
				"ACP_BBCODES",
				"ACP_BOARD_SETTINGS",
				"ACP_BOARD_FEATURES",
				"ACP_AVATAR_SETTINGS",
				"ACP_MESSAGE_SETTINGS",
				"ACP_MESSAGE_SETTINGS",
				"ACP_POST_SETTINGS",
				"ACP_POST_SETTINGS",
				"ACP_SIGNATURE_SETTINGS",
				"ACP_FEED_SETTINGS",
				"ACP_REGISTER_SETTINGS",
				"ACP_AUTH_SETTINGS",
				"ACP_EMAIL_SETTINGS",
				"ACP_COOKIE_SETTINGS",
				"ACP_SERVER_SETTINGS",
				"ACP_SECURITY_SETTINGS",
				"ACP_LOAD_SETTINGS",
				"ACP_BOTS",
				"ACP_VC_SETTINGS",
				"ACP_VC_CAPTCHA_DISPLAY",
				"ACP_CONTACT_SETTINGS",
				"ACP_BACKUP",
				"ACP_RESTORE",
				"ACP_DISALLOW_USERNAMES",
				"ACP_MASS_EMAIL",
				"ACP_EXTENSIONS",
				"ACP_MANAGE_FORUMS",
				"ACP_GROUPS_MANAGE",
				"ACP_GROUPS_POSITION",
				"ACP_ICONS",
				"ACP_SMILIES",
				"ACP_INACTIVE_USERS",
				"ACP_JABBER_SETTINGS",
				"ACP_LANGUAGE_PACKS",
				"ACP_ADMIN_LOGS",
				"ACP_MOD_LOGS",
				"ACP_USERS_LOGS",
				"ACP_CRITICAL_LOGS",
				"ACP_INDEX",
				"ACP",
				"UCP",
				"MCP",
				"ACP_ADMIN_ROLES",
				"ACP_USER_ROLES",
				"ACP_MOD_ROLES",
				"ACP_FORUM_ROLES",
				"ACP_PERMISSIONS",
				"ACP_PERMISSION_TRACE",
				"ACP_FORUM_PERMISSIONS",
				"ACP_FORUM_PERMISSIONS_COPY",
				"ACP_FORUM_MODERATORS",
				"ACP_USERS_PERMISSIONS",
				"ACP_USERS_PERMISSIONS",
				"ACP_USERS_FORUM_PERMISSIONS",
				"ACP_USERS_FORUM_PERMISSIONS",
				"ACP_GROUPS_PERMISSIONS",
				"ACP_GROUPS_PERMISSIONS",
				"ACP_GROUPS_FORUM_PERMISSIONS",
				"ACP_GROUPS_FORUM_PERMISSIONS",
				"ACP_ADMINISTRATORS",
				"ACP_GLOBAL_MODERATORS",
				"ACP_VIEW_ADMIN_PERMISSIONS",
				"ACP_VIEW_USER_PERMISSIONS",
				"ACP_VIEW_GLOBAL_MOD_PERMISSIONS",
				"ACP_VIEW_FORUM_MOD_PERMISSIONS",
				"ACP_VIEW_FORUM_PERMISSIONS",
				"ACP_PHP_INFO",
				"ACP_CUSTOM_PROFILE_FIELDS",
				"ACP_PRUNE_FORUMS",
				"ACP_PRUNE_USERS",
				"ACP_MANAGE_RANKS",
				"ACP_MANAGE_REASONS",
				"ACP_SEARCH_SETTINGS",
				"ACP_SEARCH_INDEX",
				"ACP_SEND_STATISTICS",
				"ACP_STYLES",
				"ACP_STYLES_INSTALL",
				"ACP_VERSION_CHECK",
				"ACP_MANAGE_USERS",
				"ACP_USER_FEEDBACK",
				"ACP_USER_WARNINGS",
				"ACP_USER_PROFILE",
				"ACP_USER_PREFS",
				"ACP_USER_AVATAR",
				"ACP_USER_RANK",
				"ACP_USER_SIG",
				"ACP_USER_GROUPS",
				"ACP_USER_PERM",
				"ACP_USER_ATTACH",
				"ACP_WORDS",
				"ACP_MANAGE_USERS",
				"ACP_GROUPS_MANAGE",
				"ACP_MANAGE_FORUMS",
				"ACP_MOD_LOGS",
				"ACP_BOTS",
				"ACP_PHP_INFO",
				"ACP_FORUM_PERMISSIONS",
				"ACP_FORUM_PERMISSIONS_COPY",
				"ACP_FORUM_MODERATORS",
				"ACP_USERS_FORUM_PERMISSIONS",
				"ACP_GROUPS_FORUM_PERMISSIONS",
				"MCP_MAIN",
				"MCP_QUEUE",
				"MCP_REPORTS",
				"MCP_NOTES",
				"MCP_WARN",
				"MCP_LOGS",
				"MCP_BAN",
				"MCP_BAN_USERNAMES",
				"MCP_BAN_IPS",
				"MCP_BAN_EMAILS",
				"MCP_LOGS_FRONT",
				"MCP_LOGS_FORUM_VIEW",
				"MCP_LOGS_TOPIC_VIEW",
				"MCP_MAIN_FRONT",
				"MCP_MAIN_FORUM_VIEW",
				"MCP_MAIN_TOPIC_VIEW",
				"MCP_MAIN_POST_DETAILS",
				"MCP_NOTES_FRONT",
				"MCP_NOTES_USER",
				"MCP_PM_REPORTS_OPEN",
				"MCP_PM_REPORTS_CLOSED",
				"MCP_PM_REPORT_DETAILS",
				"MCP_QUEUE_UNAPPROVED_TOPICS",
				"MCP_QUEUE_UNAPPROVED_POSTS",
				"MCP_QUEUE_DELETED_TOPICS",
				"MCP_QUEUE_DELETED_POSTS",
				"MCP_QUEUE_APPROVE_DETAILS",
				"MCP_REPORTS_OPEN",
				"MCP_REPORTS_CLOSED",
				"MCP_REPORT_DETAILS",
				"MCP_WARN_FRONT",
				"MCP_WARN_LIST",
				"MCP_WARN_USER",
				"MCP_WARN_POST",
				"UCP_MAIN",
				"UCP_PROFILE",
				"UCP_PREFS",
				"UCP_PM",
				"UCP_USERGROUPS",
				"UCP_ZEBRA",
				"UCP_MAIN_ATTACHMENTS",
				"UCP_AUTH_LINK_MANAGE",
				"UCP_USERGROUPS_MEMBER",
				"UCP_USERGROUPS_MANAGE",
				"UCP_MAIN_FRONT",
				"UCP_MAIN_SUBSCRIBED",
				"UCP_MAIN_BOOKMARKS",
				"UCP_MAIN_DRAFTS",
				"UCP_NOTIFICATION_OPTIONS",
				"UCP_NOTIFICATION_LIST",
				"UCP_PM_VIEW",
				"UCP_PM_COMPOSE",
				"UCP_PM_DRAFTS",
				"UCP_PM_OPTIONS",
				"UCP_PREFS_PERSONAL",
				"UCP_PREFS_POST",
				"UCP_PREFS_VIEW",
				"UCP_PROFILE_PROFILE_INFO",
				"UCP_PROFILE_SIGNATURE",
				"UCP_PROFILE_AVATAR",
				"UCP_PROFILE_REG_DETAILS",
				"UCP_PROFILE_AUTOLOGIN_KEYS",
				"UCP_ZEBRA_FRIENDS",
				"UCP_ZEBRA_FOES"
				)';
				$result = $db->sql_query($sql);
				$num_mods_deleted = $db->sql_affectedrows();
				$db->sql_freeresult($result);

				echo 'Modules deleted: ' . $num_mods_deleted . '<br>';

				// Modules are cached so we'll spifflicate that
				if (!$chk_autom == 'Yes')
				{
					$cache->destroy('_modules_acp', '_modules_mcp', '_modules_ucp');
				}
			}

			// Remove non standard permissions
			if($chk_perms == 'Yes')
			{
				// If permissions aren't in the list they are deleted otherwise they are ignored
				// 3Di add "m_pm_report", added in 3.1.7-RC1
				$sql = 'DELETE FROM ' . ACL_OPTIONS_TABLE . ' WHERE auth_option NOT IN (
				"f_",
				"f_announce",
				"f_attach",
				"f_bbcode",
				"f_bump",
				"f_delete",
				"f_download",
				"f_edit",
				"f_email",
				"f_flash",
				"f_icons",
				"f_ignoreflood",
				"f_img",
				"f_list",
				"f_noapprove",
				"f_poll",
				"f_post",
				"f_postcount",
				"f_print",
				"f_read",
				"f_reply",
				"f_report",
				"f_search",
				"f_sigs",
				"f_smilies",
				"f_sticky",
				"f_subscribe",
				"f_user_lock",
				"f_vote",
				"f_votechg",
				"f_softdelete",
				"m_",
				"m_approve",
				"m_chgposter",
				"m_delete",
				"m_edit",
				"m_info",
				"m_lock",
				"m_merge",
				"m_move",
				"m_report",
				"m_pm_report",
				"m_split",
				"m_softdelete",
				"m_ban",
				"m_warn",
				"a_",
				"a_aauth",
				"a_attach",
				"a_authgroups",
				"a_authusers",
				"a_backup",
				"a_ban",
				"a_bbcode",
				"a_board",
				"a_bots",
				"a_clearlogs",
				"a_email",
				"a_extensions",
				"a_fauth",
				"a_forum",
				"a_forumadd",
				"a_forumdel",
				"a_group",
				"a_groupadd",
				"a_groupdel",
				"a_icons",
				"a_jabber",
				"a_language",
				"a_mauth",
				"a_modules",
				"a_names",
				"a_phpinfo",
				"a_profile",
				"a_prune",
				"a_ranks",
				"a_reasons",
				"a_roles",
				"a_search",
				"a_server",
				"a_styles",
				"a_switchperm",
				"a_uauth",
				"a_user",
				"a_userdel",
				"a_viewauth",
				"a_viewlogs",
				"a_words",
				"u_",
				"u_attach",
				"u_chgavatar",
				"u_chgcensors",
				"u_chgemail",
				"u_chggrp",
				"u_chgname",
				"u_chgpasswd",
				"u_chgprofileinfo",
				"u_download",
				"u_hideonline",
				"u_ignoreflood",
				"u_masspm",
				"u_masspm_group",
				"u_pm_attach",
				"u_pm_bbcode",
				"u_pm_delete",
				"u_pm_download",
				"u_pm_edit",
				"u_pm_emailpm",
				"u_pm_flash",
				"u_pm_forward",
				"u_pm_img",
				"u_pm_printpm",
				"u_pm_smilies",
				"u_readpm",
				"u_savedrafts",
				"u_search",
				"u_sendemail",
				"u_sendim",
				"u_sendpm",
				"u_sig",
				"u_viewonline",
				"u_viewprofile"
				)';
				$result = $db->sql_query($sql);
				$num_perms_deleted = $db->sql_affectedrows();
				$db->sql_freeresult($result);

				echo 'Permissions deleted: ' . $num_perms_deleted . '<br>';

				// Now to clear cached permissions
				if(!$chk_autom == 'Yes')
				{
					$cache->destroy('_acl_options');
					$auth->acl_clear_prefetch();
					$cache->destroy('_role_cache');
				}
				phpbb_cache_moderators($db, $cache, $auth);
			}
		echo '<form action="https://www.paypal.com/cgi-bin/webscr" method="post" target="_top"><input type="hidden" name="cmd" value="_s-xclick"><input type="hidden" name="hosted_button_id" value="ZLN6KTV2WQSRN"><input type="image" src="https://www.paypal.com/en_GB/i/btn/btn_donate_LG.gif" border="0" name="submit" alt="PayPal – The safer, easier way to pay online."><img alt="" border="0" src="https://www.paypalobjects.com/en_GB/i/scr/pixel.gif" width="1" height="1"><font color="darkred"> Help the development and maintainment of this Tool by a donation of your choice.</font></form>';
	}
	else
	{
		// If not correct version tell them
		if (!$ascraeus)
		{
			echo 'Version is not 3.1.x so only the AutoMOD option is available<br>';
		}
		elseif (version_compare(PHPBB_VERSION, "3.1.10", "<>"))
		{
			echo 'Version is ' . PHPBB_VERSION . ', since this file has not been fully verified to
			work correctly with that only the AutoMOD option is available<br>';
		}
		else
		{
			echo 'phpBB version inappropriate so nothing can be deleted<br>';
		}
		remove_me();
	}

	if($chk_modules == 'Yes' || $chk_perms == 'Yes' || $chk_autom == 'Yes')
	{
		remove_me();
	}

}
else
{
	// If versions don't match we could trash the database, but we'll be nice and just tell them
	echo 'Version mismatch:<br>/includes/constants.php ' . $version .
		'<br>config table ' . $db_vers . '<br>Since the version isn\'t
		clear nothing will be deleted<br>';
	remove_me();
}

echo '</form>';
echo '</fieldset>';
echo '</body>';
echo '</html>';
