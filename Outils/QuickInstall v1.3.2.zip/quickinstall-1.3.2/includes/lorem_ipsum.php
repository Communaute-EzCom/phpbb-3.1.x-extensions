<?php
/**
*
* @package quickinstall
* @copyright (c) 2010 phpBB Limited
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
* @author Jari Kanerva (tumba25)
*
*/

/**
 * This file contains only lorem ipsum, a dummy text to fill the posts.
 * http://en.wikipedia.org/wiki/Lorem_ipsum
 * This string should not be translated but you can edit it if you want to.
 */

/**
* @ignore
*/
if (!defined('IN_QUICKINSTALL'))
{
	exit;
}

$lorem_ipsum = 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.';
