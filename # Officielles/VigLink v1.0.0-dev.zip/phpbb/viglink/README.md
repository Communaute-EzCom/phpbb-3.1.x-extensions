# VigLink Extension

This is the repository for the development of the VigLink extension for phpBB.

[![Build Status](https://travis-ci.org/phpbb-extensions/viglink.png)](https://travis-ci.org/phpbb-extensions/viglink)

To-do:
- [ ] Add phpBB's API key
- [ ] Update the language used in the ACP module

Note: This extension is currently under development and is not ready to install on any forum.

## License
[GNU General Public License v2](http://opensource.org/licenses/GPL-2.0)
