# Changelog

## 1.0.1 - 2014-11-28

- Fixed issues in the README.md
- Added a new template event `phpbb_googleanalytics_alter_ga_requirements` which may be used by other extensions to add more tracking options (like the ability to track advertisements). See here for a example: https://support.google.com/analytics/answer/2444872?hl=en&utm_id=ad
- Added Arabic language pack
- Added Dutch language pack
- Added French language pack
- Added Mandarin Chinese language pack
- Added Polish language pack
- Added Portuguese language pack
- Added Romanian language pack
- Added Spanish language pack
- Added Swedish language pack

## 1.0.0 - 2014-10-21

- First release
