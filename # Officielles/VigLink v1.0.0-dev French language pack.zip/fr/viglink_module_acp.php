<?php
/**
*
* VigLink extension for the phpBB Forum Software package.
* French translation by Galixte (http://www.galixte.com)
*
* @copyright (c) 2014 phpBB Limited <https://www.phpbb.com>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(
	'ACP_VIGLINK_SETTINGS'			=> 'Paramètres VigLink',
	'ACP_VIGLINK_SETTINGS_EXPLAIN'	=> 'VigLink est un service tiers non envahissant permettant de monétiser les liens existants postés par les utilisateurs sur votre forum. Lorsque les utilisateurs cliquent sur ces liens existants et réalisent certaines actions, tel que l’achat, le marchand paient une commission à VigLink, dont une part est reversée au projet phpBB. En activant VigLink et les dons au projet phpBB, vous soutenez notre organisation open source et assurez notre situation financière continuellement.',
	'ACP_VIGLINK_ENABLE'			=> 'Activer VigLink',
	'ACP_VIGLINK_ENABLE_EXPLAIN'	=> 'Permettre l’utilisation des services de VigLink.',
	'ACP_VIGLINK_EARNINGS'			=> 'Réclamez vos propres revenus (facultatif)',
	'ACP_VIGLINK_EARNINGS_EXPLAIN'	=> 'Vous pouvez gagner une commission sur les liens monétisés par VigLink, en utilisant votre propre clé de l’API de VigLink. Pour obtenir une clé, créez un compte « VigLink Convert » sur <a href="http://www.viglink.com/products/convert/">VigLink.com</a>.',
	'ACP_VIGLINK_API_KEY'			=> 'Clé de l’API de VigLink',
	'ACP_VIGLINK_API_KEY_EXPLAIN'	=> 'Saisissez une clé valide de l’API de VigLink Convert.',
	'ACP_VIGLINK_API_KEY_INVALID'	=> '« %s » n’est pas une clé valide de l’API de VigLink Convert.',
	'ACP_VIGLINK_DISABLED_GLOBAL'	=> 'Les services de VigLink ont été désactivés par phpBB.',
	'ACP_VIGLINK_DISABLED_PHPBB'	=> 'Les services de VigLink ont été désactivés par phpBB. Vous pouvez toujours utiliser votre propre clé VigLink pour être rémunéré.',
));
