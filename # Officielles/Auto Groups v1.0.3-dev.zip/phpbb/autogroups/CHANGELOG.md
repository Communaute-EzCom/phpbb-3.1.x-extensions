# Changelog

## 1.0.2 - 2016-11-30

- Fixed new years day bug in the auto group by user age condition
- Various code improvements and maintenance
- Added Croatian language packs
- Added Chinese language packs
- Added Dutch language pack
- Added Russian language pack

## 1.0.1 - 2015-09-05

- Do not allow identical min/max values to be set
- Fixed an issue where users not belonging to any group(s) created PHP notices
- Fixed an issue where the "warnings" type could generate invalid SQL queries
- Added Arabic language pack
- Added Brazilian Portuguese language pack
- Added Estonian language pack
- Added French language pack
- Added German language pack
- Added Italian language pack
- Added Spanish language pack

## 1.0.0 - 2015-05-14

- First release
