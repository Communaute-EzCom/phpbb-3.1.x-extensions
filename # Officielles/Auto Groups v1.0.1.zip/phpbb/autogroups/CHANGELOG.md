# Changelog

## 1.0.1 - 2015-09-05

- Do not allow identical min/max values to be set
- Fixed an issue where users not belonging to any group(s) created PHP notices
- Fixed an issue where the "warnings" type could generate invalid SQL queries
- Added Arabic language pack
- Added Brazilian Portuguese language pack
- Added Estonian language pack
- Added French language pack
- Added German language pack
- Added Italian language pack
- Added Spanish language pack

## 1.0.0 - 2015-05-14

- First release
