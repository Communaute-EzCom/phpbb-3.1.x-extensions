# phpBB Topic Prefixes

This is the repository for the development of the Topic Prefixes phpBB extension.

[![Build Status](https://travis-ci.org/phpbb-extensions/topicprefixes.png)](https://travis-ci.org/phpbb-extensions/topicprefixes)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/phpbb-extensions/topicprefixes/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/phpbb-extensions/topicprefixes/?branch=master)

Note: This extension is currently under development and is not ready to install on any live forum.

## License

[GPLv2](license.txt)
