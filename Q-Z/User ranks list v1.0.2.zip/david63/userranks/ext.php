<?php
/**
*
* @package User Ranks Extension
* @copyright (c) 2015 david63
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace david63\userranks;

class ext extends \phpbb\extension\base
{
	const USER_RANKS_VERSION	= '1.0.2';
}
