<?php
/**
*
* @package phpBB Extension - Right Header Image
* @copyright (c) 2015 HiFiKabin
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/


/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
   exit;
}

if (empty($lang) || !is_array($lang))
{
   $lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(

   'INSTALL_RIGHTHEADERIMAGE'              => 'Install Right Header Image',
   'INSTALL_RIGHTHEADERIMAGE_CONFIRM'         => 'Are you ready to install the Right Header Image Ext.?',
   'RIGHTHEADERIMAGE'                   => 'Right Header Image',
   'RIGHTHEADERIMAGE_EXPLAIN'              => 'Install Right Header Image database changes with UMIL auto method.',
   'UNINSTALL_RIGHTHEADERIMAGE'            => 'Uninstall Right Header Image',
   'UNINSTALL_RIGHTHEADERIMAGE_CONFIRM'    => 'Are you ready to uninstall the Right Header Image? All settings and data saved by this ext. will be removed!',
   'UPDATE_RIGHTHEADERIMAGE'               => 'Update Right Header Image',
   'UPDATE_RIGHTHEADERIMAGE_CONFIRM'       => 'Are you ready to update the Right Header Image Ext.?',

   'ACP_RIGHTHEADERIMAGE_CONFIG'           => 'Right Header Image',
   'ACP_RIGHTHEADERIMAGE_CONFIG_EXPLAIN'      => 'This is configuration page for the Right Header Image extension. The header bar of your forum will size automatically to accommodate the image size.',
   'RIGHTHEADERIMAGE_VERSION'              => 'Version',

   'ACP_RIGHTHEADERIMAGE_CONFIG_SET'       => 'Configuration',
   'RIGHTHEADERIMAGE_CONFIG_SAVED'         => 'Right Header Image settings saved',
      
   'RIGHTHEADERIMAGE_ENABLE'               => 'Enable Right Header Image',
   'RIGHTHEADERIMAGE_ENABLE_EXPLAIN'       => 'Do you want to enable the Right Header Image EXT?',

   'RIGHTHEADERIMAGE_SEARCH'               => 'Search',
   'RIGHTHEADERIMAGE_SEARCH_EXPLAIN'       => 'Do you want to show the Search in the NavBar when Right Header Image is enabled?',

   'RIGHTHEADERIMAGE_IMAGE_URL'              => 'Right Header Image URL',
   'RIGHTHEADERIMAGE_IMAGE_URL_EXPLAIN'         => 'Enter the full URL of the image INCLUDING  http:// ',
   'RIGHTHEADERIMAGE_IMAGE_URL_PLACEHOLDER'     => 'http://image.jpg',

   'RIGHTHEADERIMAGE_IMAGE_LINK'             => 'Right Header Image Link URL',
   'RIGHTHEADERIMAGE_IMAGE_LINK_EXPLAIN'        => 'Enter the full URL of the page you wish to link the image to INCLUDING http:// ',
   'RIGHTHEADERIMAGE_IMAGE_LINK_PLACEHOLDER'     => 'http://link.html',

   'RIGHTHEADERIMAGE_TARGET'              => 'Link Target',
   'RIGHTHEADERIMAGE_TARGET_EXPLAIN'         => 'Do you want the link to open in a new tab/page?',

));
