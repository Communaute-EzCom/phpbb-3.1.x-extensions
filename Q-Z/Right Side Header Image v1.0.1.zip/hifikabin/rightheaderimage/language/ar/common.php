<?php
/**
*
* @package phpBB Extension - Right Header Image
* @copyright (c) 2015 HiFiKabin
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
* Translated By : Bassel Taha Alhitary - www.alhitary.net
*/


/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
   exit;
}

if (empty($lang) || !is_array($lang))
{
   $lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(

   'INSTALL_RIGHTHEADERIMAGE'              => 'تنصيب الصورة في يسار الترويسة ',
   'INSTALL_RIGHTHEADERIMAGE_CONFIRM'         => 'هل بالفعل تريد تنصيب الإضافة : الصورة في يسار الترويسة ?',
   'RIGHTHEADERIMAGE'                   => 'الصورة في يسار الترويسة ',
   'RIGHTHEADERIMAGE_EXPLAIN'              => 'قاعدة البيانات لهذه الإضافة تتغير بواسطة الطريقة التلقائية UMIL.',
   'UNINSTALL_RIGHTHEADERIMAGE'            => 'إزالة الصورة في يسار الترويسة ',
   'UNINSTALL_RIGHTHEADERIMAGE_CONFIRM'    => 'هل بالفعل تريد إزالة الإضافة : الصورة في يسار الترويسة ? سيتم حذف جميع الإعدادات والبيانات الخاصة بهذه الإضافة !',
   'UPDATE_RIGHTHEADERIMAGE'               => 'تحديث الصورة في يسار الترويسة ',
   'UPDATE_RIGHTHEADERIMAGE_CONFIRM'       => 'هل بالفعل تريد تحديث الإضافة : الصورة في يسار الترويسة ?',

   'ACP_RIGHTHEADERIMAGE_CONFIG'           => 'الصورة في يسار الترويسة',
   'ACP_RIGHTHEADERIMAGE_CONFIG_EXPLAIN'      => 'من هنا تستطيع ضبط الإعدادات للإضافة : الصورة في يسار الترويسة. سيتغير مقاس ترويسة منتداك تلقائياً بحسب مقاس الصورة التي أضفتها.',
   'RIGHTHEADERIMAGE_VERSION'              => 'الإصدار ',

   'ACP_RIGHTHEADERIMAGE_CONFIG_SET'       => 'ضبط الإعدادات',
   'RIGHTHEADERIMAGE_CONFIG_SAVED'         => 'تم حفظ الإعدادات بنجاح',
      
   'RIGHTHEADERIMAGE_ENABLE'               => 'تفعيل ',
   'RIGHTHEADERIMAGE_ENABLE_EXPLAIN'       => 'هل تريد تفعيل الإضافة : الصورة في يسار الترويسة ?',

   'RIGHTHEADERIMAGE_SEARCH'               => 'البحث ',
   'RIGHTHEADERIMAGE_SEARCH_EXPLAIN'       => 'هل تريد إظهار شريط البحث في شريط التنقل ( العلوي ) أسفل الترويسة ؟ لأنه سيتم إخفاء "البحث" عند تفعيل الإضافة : الصورة في يسار الترويسة.',

   'RIGHTHEADERIMAGE_IMAGE_URL'              => 'رابط الصورة ',
   'RIGHTHEADERIMAGE_IMAGE_URL_EXPLAIN'         => 'اكتب رابط الصورة كاملاً مع http:// ',
   'RIGHTHEADERIMAGE_IMAGE_URL_PLACEHOLDER'     => 'http://image.jpg',

   'RIGHTHEADERIMAGE_IMAGE_LINK'             => 'رابط الصفحة ',
   'RIGHTHEADERIMAGE_IMAGE_LINK_EXPLAIN'        => 'اكتب رابط الصفحة كاملاً مع http:// لو ترغب في ربط الصورة بأي صفحة.',
   'RIGHTHEADERIMAGE_IMAGE_LINK_PLACEHOLDER'     => 'http://link.html',

   'RIGHTHEADERIMAGE_TARGET'              => 'فتح الصفحة ',
   'RIGHTHEADERIMAGE_TARGET_EXPLAIN'         => 'هل تريد فتح الصفحة في نافذة / علامة تبويب جديدة ؟',

));
