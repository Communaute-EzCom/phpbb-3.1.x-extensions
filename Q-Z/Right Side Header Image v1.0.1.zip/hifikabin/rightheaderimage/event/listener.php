<?php
/**
*
* @package phpBB Extension - Right Header Image
* @copyright (c) 2015 HiFiKabin
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace hifikabin\rightheaderimage\event;

/**
* @ignore
*/
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
* Event listener
*/
class listener implements EventSubscriberInterface
{
   static public function getSubscribedEvents()
   {
      return array(
         'core.user_setup'   => 'load_language_on_setup',
         'core.page_header'   => 'add_page_header_link',
      );
   }

   protected $helper;

   protected $template;

   public function __construct(\phpbb\controller\helper $helper, \phpbb\template\template $template, \phpbb\config\config $config)
   {
      $this->helper = $helper;
      $this->template = $template;
      $this->config = $config;      
   }

   public function load_language_on_setup($event)
   {
      $lang_set_ext = $event['lang_set_ext'];
      $lang_set_ext[] = array(
         'ext_name' => 'hifikabin/rightheaderimage',
         'lang_set' => 'common',
      );
      $event['lang_set_ext'] = $lang_set_ext;
   }

   
   public function add_page_header_link($event)
   {
      $this->template->assign_vars(array(
      'RIGHTHEADERIMAGE_ENABLE'         => $this->config['rightheaderimage_enable'] ? true : false,
      'RIGHTHEADERIMAGE_SEARCH'         => $this->config['rightheaderimage_search'] ? true : false,
      'RIGHTHEADERIMAGE_TARGET'         => $this->config['rightheaderimage_target'] ? '_blank' : '_self',
      'RIGHTHEADERIMAGE_IMAGE_URL'        => (isset($this->config['rightheaderimage_image_url'])) ? $this->config['rightheaderimage_image_url'] : '',
      'RIGHTHEADERIMAGE_IMAGE_LINK'    => (isset($this->config['rightheaderimage_image_link'])) ? $this->config['rightheaderimage_image_link'] : '',
      ));
   }
}
