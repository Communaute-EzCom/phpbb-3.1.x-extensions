$(function(){
    $("#header-image a").attr("target","_blank");
});