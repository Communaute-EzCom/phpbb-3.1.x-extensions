<?php
/**
*
* @package phpBB Extension - Right Header Image
* @copyright (c) 2015 HiFiKabin
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace hifikabin\rightheaderimage\event;

/**
* @ignore
*/
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
* Event listener
*/
class listener implements EventSubscriberInterface
{
    static public function getSubscribedEvents()
    {
        return array(
        'core.page_header'   => 'add_page_header_link',
        );
    }

    protected $helper;

    protected $template;

    public function __construct(\phpbb\controller\helper $helper, \phpbb\template\template $template, \phpbb\config\config $config)
        {
        $this->template = $template;
        $this->config = $config;
        }

   
    public function add_page_header_link($event)
    {
        $this->template->assign_vars(array(
        'RIGHTHEADERIMAGE_ENABLE'         => $this->config['rightheaderimage_enable'] ? true : false,
        'RIGHTHEADERIMAGE_SEARCH'         => $this->config['rightheaderimage_search'] ? true : false,
        'RIGHTHEADERIMAGE_TARGET'         => (isset($this->config['rightheaderimage_target'])) ? $this->config['rightheaderimage_target'] : '',
        'RIGHTHEADERIMAGE_IMAGE_URL'      => (isset($this->config['rightheaderimage_image_url'])) ? $this->config['rightheaderimage_image_url'] : '',
        'RIGHTHEADERIMAGE_IMAGE_LINK'     => (isset($this->config['rightheaderimage_image_link'])) ? $this->config['rightheaderimage_image_link'] : '',
        'RIGHTHEADERIMAGE_RESIZE'         => (isset($this->config['rightheaderimage_resize'])) ? $this->config['rightheaderimage_resize'] : '',
        ));
    }
}
