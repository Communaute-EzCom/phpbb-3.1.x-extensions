﻿/**
 * library - jquery_wolfsblvt_functions
 *
 * onload_global.js
 * http://www.pinkes-forum.de/
 * Author: Clemens Husung (Wolfsblvt)
 * 
 */

