﻿/**
 * library - jquery_wolfsblvt_functions
 *
 * startup_global.js
 * http://www.pinkes-forum.de/
 * Author: Clemens Husung (Wolfsblvt)
 * 
 */

// All cookies as json objects
$(document).ready(function () {
    $.cookie.json = true;
});