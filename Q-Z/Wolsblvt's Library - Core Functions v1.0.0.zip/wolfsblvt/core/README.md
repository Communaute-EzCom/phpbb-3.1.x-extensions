core
====

Adds the core functions and libraries used in all my extensions. This extension is needed cause my own libraries can change and will be updated regularly. I don't want to multiply my code and update it in different extensions.


<b>Please note:</b>
This GitHub repository is just for testing purposes. This is NOT the newest version, and you should not install the extension forum here.<br />
Please visit http://www.pinkes-forum.de/dev/find.php to see a list of all extension and actual links.
