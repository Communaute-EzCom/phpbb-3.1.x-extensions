<?php
/**
*
* @package User Login Redirect
* @copyright (c) 2014 david63
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace david63\loginredirect;

class ext extends \phpbb\extension\base
{
	const LOGIN_REDIRECT_VERSION	= '1.1.1';
}
