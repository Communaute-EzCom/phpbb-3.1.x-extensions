#phpBB User Merge Extension

[![Build Status](https://travis-ci.org/phpbbmodders/phpbb-3.1-ext-usermerge.svg)](https://travis-ci.org/phpbbmodders/phpbb-3.1-ext-usermerge)
##About
phpBB User Merge Extension allows an administrator of a forum to merge the accounts of two users.


##Installation
### 1. clone
Clone (or download and move) the repository into the folder ext/phpbbmodders/usermerge:

```
cd phpBB3
git clone https://github.com/phpbbmodders/phpbb-3.1-ext-usermerge ext/phpbbmodders/usermerge/
```

### 2. activate
Go to admin panel -> tab customise -> Manage extensions -> enable User Merge

##Licensing
phpBB Add User Mod is distributed under the terms of the GNU General Public
License 2 (GPL). A copy has been included in the package (license.txt).
