<?php
/**
*
* SiteSplat BBCore extension for the phpBB Forum Software package.
* French translation by Galixte (http://www.galixte.com)
*
* @copyright (c) 2017 phpBB Limited <http://sitesplat.com>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(

  'PM_NEW_MSG' => array(
    1 => 'Il y a %d nouveau message privé',
    2 => 'Il y a %d nouveaux messages privés',
  ),
  'PM_UNREAD_MSG' => array(
    1 => 'Il y a %d nouveau message privé non lu',
    2 => 'Il y a %d nouveaux messages privés non lus',
  ),
  'PM_NEW_MSG_BUBBLE' => array(
    1 => '%d',
    2 => '%d',
  ),
  
  'UCP_MAIN'                	 => 'Aperçu',
  'UCP_MAIN_FRONT'          	 => 'Page de couverture',
  'UCP_MAIN_SUBSCRIPTION'   	 => 'Gestion des surveillances',
  'UCP_MAIN_BOOKMARKS'      	 => 'Gestion des favoris',
  'UCP_MAIN_DRAFTS'         	 => 'Gestion des brouillons',
  'UCP_MAIN_ATTACHMENTS'    	 => 'Gestion des fichiers joints',
  
  'USER_PANEL'             	     => 'Panneau de l’utilisateur', 
  'UCP_PROFILE'             	 => 'Profil',   
  'UCP_PROFILE_PROFILE'    		 => 'Modifier le profil',   
  'UCP_PROFILE_SIGNITURE'  		 => 'Modifier la signature',   
  'UCP_PROFILE_AVATAR'      	 => 'Modifier l’avatar',   
  'UCP_PROFILE_SETTINGS'    	 => 'Modifier les paramètres du compte', 
  'UCP_AVATAR_SELECT_OPTIONS'    => 'Options de l’avatar', 
  'UCP_AVATAR_SELECT_UPLOAD'     => 'Charger depuis votre ordinateur',
  'UCP_SUBMIT_TO_UPLOAD'         => 'Cliquer ci-dessous pour démarrer l’envoi',
  
  'UCP_PREFERENCE'         		 => 'Préférences du forum',
  'UCP_PREFERENCE_SETTINGS' 	 => 'Modifier les préférences générales',
  'UCP_PREFERENCE_DEFAULTS' 	 => 'Modifier les préférences de message',
  'UCP_PREFERENCE_OPTIONS'  	 => 'Modifier les options d’affichage',
  
  'UCP_MESSAGES'            	 => 'Messages privés',   
  'UCP_PM_COMPOSE'          	 => 'Rédiger un message',   
  'UCP_PM_DRAFTS'           	 => 'Gestion des brouillons de MP',   
  'UCP_PM_INBOX'            	 => 'Boite de réception',   
  'UCP_PM_OUTBOX'           	 => 'Boite d’envoi',   
  'UCP_PM_SENTBOX'          	 => 'Messages envoyés',   
  'UCP_PM_OPTIONS'          	 => 'Filtres, dossiers et paramètres', 
  'UCP_NO_USER_CHANGE_ALLOWED'   => '**Le changement du nom d’utilisateur n’est pas autorisé**',
  'UCP_REGISTER_EMAIL_EXPLAIN'   => 'Merci de ne pas utiliser pas d’adresse e-mail jetable',
  
  'WIDTH_SIZE'            	     => 'largeur',   
  'PIXEL_SIZE'           	     => 'px',   
  'HEIGHT_SIZE'          	     => 'hauteur',
  
  'UCP_GROUPS'              	 => 'Groupes d’utilisateurs',   
  'UCP_GROUPS_MEMBERSHIP'   	 => 'Modifier mes adhésions',   
  'UCP_GROUPS_MANAGE'       	 => 'Gestion des groupes',   
  
  'UCP_ZEBRA'               	 => 'Amis et ignorés',   
  'UCP_ZEBRA_FRIENDS'       	 => 'Gestion des amis',   
  'UCP_ZEBRA_FOES'          	 => 'Gestion des ignorés', 
  'UCP_APPLY'                    => 'Envoyer', 
  'UCP_PM_DEFAULT_RULE_TAG'      => 'Action par défaut',
  'UCP_PM_DEFAULT_RULE'          => 'Refuser les nouveaux messages',
  'UCP_PM_DEFAULT_RULE_EXPLAIN'  => 'Cette action sera activée si aucune ci-dessus n’est applicable. Les nouveaux messages seront refusés dans l’attente d’espace disponible.',
  'UCP_PM_NEW_MESSAGE'           => 'Nouveau MP',
  'BIO'                          => 'Centres d’intérêt',
  'MANAGE'                       => 'Gérer',
  'JOINED_BOARD'                 => 'Rejoindre le forum',
  'VISITED_BOARD'                => 'Dernières visites',
  'SEE_MORE'                     => 'Plus',
  'ATTACH_SIGNATURE'             => 'Attacher ma signature',

  'DELETE_POST_SOFT'             => 'Supprimer le message',
  'DELETE_POST_PERMANENT'        => 'Supprimer définitivement le message',
  'DELETE_POST_SOFT_WARN'        => 'Il peut être restauré',
  'DELETE_POST_PERMANENT_WARN'   => 'Il ne peut pas être restauré',
  
  'POLL_MAX_OPTIONS_EXPLAIN_ALT' => 'Saisir le nombre maximum d’options souhaitées',
  'POLL_VOTE_CHANGE_LABEL'       => 'Permettre de voter à nouveau',
  'NO_VOTES_NA'                  => 'N/A (Non applicable)',
  'NOT_AVAILABLE'                => 'Non disponible',
  'POST_TOPIC_NEW'               => 'Nouveau sujet',
  'QUICK_REPLY_SHOW_HIDE'        => 'Afficher/masquer la réponse rapide',
  'CHARACTERS_COUNT'             => 'Caractères',
  'CHARACTERS_COUNT_REM'         => 'Restant',
  'BOOKMARKED_TOPICS_UCP'        => 'Sujets favoris',
  'ATTACH_EXPLANATION_SORTABLE'  => 'Cliquer pour trier',
  'ATTACH_FORUM'                 => 'Fichier(s) joint(s)',
  'MCP_DETAILS_LOG'              => 'Détails',
  'MCP_DETAIL_U_IP'              => 'Nom d’utilisateur et adresse IP',
  'MCP_MANAG_BAN'                => 'Bannissements',
  'MCP_UNAPPROVED_POSTS_ZERO'    => 'Il n’y a aucun message en attente de modération.',
  'MCP_REPORTS_ZERO'             => 'Aucun rapport n’a été trouvé',
  'MCP_PM_REPORTS_ZERO'          => 'Aucun rapport n’a été trouvé',
  
  
  'FORUMLIST_UNAPPROVED'         => 'Au moins un sujet dans ce forum n’a pas été approuvé', 
  'FORUMLIST_UNAPPROVED_POST'    => 'Au moins un message dans ce forum n’a pas été approuvé', 
  'FORUMLIST_LASTPOST'           => 'Voir le dernier message', 
  'TOPICS_POSTS_STATISTICS'      => 'Statistiques',
  'TOPICS_ROW_REPORTED'          => 'Ce sujet a été rapporté',
  'TOPICS_ROW_NOT_APPROVED'      => 'Ce sujet n’a pas été rapporté',
  'TOPICS_ROW_DELETED'           => 'Ce sujet a été supprimé',
  'MODERATOR_PANEL_GENERAL'      => 'Panneau de modération',
  'ADMIN_PANEL_GENERAL'          => 'Panneau d’administration',
  'RANK_IMAGE'                   => 'Image de rang',
  
  'WELCOME_INDEX'                => 'Bienvenue',
  'FAQ'                          => 'FAQ',
  'CAPTION_FAQ'                  => 'Questions posées fréquemment',
  'CAPTION_SEARCH'               => 'Rechercher cela !',
  'CAPTION_MEMBERS'              => 'Rechercher un membre ?',
  'MEMBERS_CAP'                  => 'Membres',
  'CAPTION_UCP'                  => 'Modifier ses préférences',
  'UCP_CAP'                      => 'Panneau de l’utilisateur',
  'INDEX_CAPTION'                => 'Ceci est la page de l’index du forum',
  'VIEWTOPIC_CAP'                => 'Titre du sujet',
  'CAPTION_VIEWTOPIC'            => 'Description du sujet',
  'CAPTION_VIEWFORUM'            => 'Parcourir toutes les catégories du forum',
  'POSTINGS_CAP'                 => 'Éditeur de texte complet',
  'CAPTION_POSTINGS'             => 'Tout en publiant !',
  
  'MCP_CAPTION'                  => 'Lieu pour utiliser ses super pouvoirs ;-)',
  'BOOTSTRAP_ELEMENT'            => 'Éléments de Bootstrap',
  'BOOTSTRAP_ELEMENT_CAPTION'    => 'Documentation du forum KickStart',
  'MAIN_FORUM'                   => 'Forum',
  'MAIN_MAIN_STUFF'              => 'Points importants',
  'MAIN_TRENDS'                  => 'Voir les tendances',
  
  'MAIN_SEARCH_IT_UP'            => 'Rechercher-le',
  'SUB_NO_ICON'                  => 'Il n’y a pas d’icône ici',
  'EXAMPLE_WITH_ICON'            => 'Exemple avec une icône',
  'EXAMPLE_LINK'                 => 'Exemple de lien',
  'MAIN_SOCIAL'                  => 'Social',
  'SOCIAL_P'                     => 'Moyen de discuter ;-)',
  
  'MORE'          				 => 'Davantage',
  'EXPAND_CLOSE'          		 => 'Fermer la vue',
  'MARK_TOPICS_READ'  			 => 'Marquer les sujets comme lus',
  'CONTACT'           			 => 'Contact',
  'GET_IN_TOUCH'      			 => 'Entrer en contact',
  'HANG_AROUND'       			 => 'rester en contact',
  'JOIN_THE_CLUB'     			 => 'Rejoindre le club',
  'MENU'         				 => 'MENU',
  'YOU_ARE_HERE'      			 => 'Vous êtes ici',
  'IN_FOOTER'         			 => 'Dans :',
  'REPLY'        				 => 'Répondre',

  'LOGIN_REMEMBER'        		 => 'Rester connecté',
  'LOGIN_HIDE_ME'        		 => 'Être invisible',
  'LOGIN_ME_IN'        		     => 'Se connecter',
  'SIGN_IN_ACCOUNT'        		 => 'Se connecter à son compte',
  'CREATE_ACCOUNT'        		 => 'S’enregistrer',
  'GO_TO_SEARCH_ADV'             => 'Retourner à la recherche avancée',
  
  'CREATE_ACCOUNT_DISABLED'      => 'Les enregistrements sont fermés',
  'REGISTRATION_DISABLED'        => 'Pour le moment les enregistrements sont fermés. C’est peut-être une mesure temporaire, auquel cas contraire si c’est une erreur, merci de contacter l’administrateur du forum. L’équipe du forum présente ses excuses pour le dérangement occasionné. Les « Conditions d’utilisation » et la « Politique de vie privée » du forum sont disponibles ci-dessous.',
  'CONTACT_WEBMASTER'        	 => 'Contacter le Webmestre du forum',
  'CONFIRM_QA_EXPLAIN_ALT'       => 'Prouver que l’on est humain en répondant à cette question',
  
  'PLUPLOAD_PLACE_INLINE'        => 'Dans la ligne',
  'PLUPLOAD_DELETE_FILE'         => 'Supprimer',
  
  
  'REG_CREATING'        		 => 'Création de profil…',
  'LOADING'        				 => 'Chargement…',
  'SAVING'        				 => 'Sauvegarde…',
  'CANCELLING'        			 => 'Annulation…',
  'SENDING'        				 => 'Publication…',
  'SEARCHING'        			 => 'Recherche…',
  'LOADING_LOG_IN'        		 => 'Connexion en cours…',
  'FILE_UPLOADING'        		 => 'Envoi de fichier…',
  'CASTING_VOTE'        		 => 'Vote…',
  'LOADING_FORM'        		 => 'Chargement du formulaire…',

  
  'MEMBERLIST_P_JOINED'          => 'Inscrit(e) au forum',
  'MEMBERLIST_P_EXPL'            => 'Enregistré(e) le',
  'MEMBERLIST_P_DATE_EXPL'       => 'Dernière visite',
  'SPAMMER_PLACEHOLDER'          => 'Il n’est pas possible de polluer le forum puis de s’en sortir !',
  'MARK_PLACEHOLDER'      	     => 'Marquer son choix',
  'INFO_BOX'      			     => 'Information :',
  'USER_REMOVE_PLACEHOLDER'      => 'Cliquer pour retirer l’utilisateur',
  'GROUP_REMOVE_PLACEHOLDER'     => 'Cliquer pour retirer le groupe',
  'EDIT_LINK_PLACEHOLDER'        => 'Modifier le lien',
  'POST_IT_UP_PLACEHOLDER'       => 'Publier-le !',
  'MESSAGE_ENTER_PLACEHOLDER'    => 'Saisir son message…',
  'FILE_COMMENT_PLACEHOLDER'     => 'Commenter son fichier',
  'HEIGTH_PLACEHOLDER'       	 => 'hauteur',
  'WIDTH_PLACEHOLDER'       	 => 'largeur',
  'UCP_OCCUPATION_PLACEHOLDER'   => 'Décrire brièvement ses occupations…',
  'UCP_INTERESTS_PLACEHOLDER'    => 'Décrire ses intérêts…',
  'SOFT_DELETE_PLACEHOLDER'      => 'Saisir la raison de la suppression…',
  'ADD_DESCRIPTION'              => 'Ajouter une description',
  
  'FILE_SELECT'       			 => 'Sélectionner un fichier',
  'FILE_CHANGE'       			 => 'Modifier le fichier',
  'SELECT_IMAGE'       			 => 'Sélectionner une image',
  'NOTE'       			         => 'Noter',
  'EDIT_DRAFT'       			 => 'Modifier le brouillon',
  'PM_BALOON_NOTIFICATION'       => 'Activer les notifications pour les nouveaux MP (Message privé)',
  'DAYS_AGO'       			     => 'jours',
  'WORK_IN_PROGRESS'       		 => 'Maintenance',
  'DISABLE_MESSAGE'              => 'Forum indisponible',
  'DISABLE_RETURN'               => 'Retourner sur la page de l’index du forum',
  'BOARD_DISABLED_SHUFFLE'       => 'S’amuser à mélanger les lettres :-)',
  'DISABLE_TEXT_TRY'             => 'Tester cela pour soi-même !',
  'DISABLE_TEXT_TYPE'            => 'Saisir n’importe quoi',
  
  'GRAVATAR_EXPLAIN'          	 => 'Si une image <a href="//gravatar.com/" target="_blank">GRAVATAR</a> est associée à l’adresse e-mail saisie, elle sera paramétrée par défaut.',
  'GRAVATAR_EXPLAIN_CONFIRM'     => 'Merci de confirmer l’adresse e-mail',
  
  'DELETE_POLL'       			 => 'Supprimer le sondage',
  'POLL_DELETE_HELPER'       	 => '(ceci supprime le sondage uniquement) vérifier puis envoyer',
  'JUMP_TO_POST'       			 => 'Se rendre au message',
  'JUMP_SELECT_FORUM'            => 'Sélectionner le forum où se rendre',
  'JUMP_TO_PAGE_NUMBER'          => 'Se rendre à la page #',
  'VIEW_FIRST_UNREAD'            => 'Voir le premier message non lu',
  'BOOKMARK_TOPIC_REMOVE'        => 'Supprimer ce favori',
  
  'NEW_MESSAGES'	             => 'Nouveaux messages',
  'YOU_HAVE'        	   		 => 'Il y a',
  'AND'        					 => 'et',
  'HELLO'            		     => 'Bienvenue',
  'DISMISS_PM'       			 => 'Rejeter le MP 5 min',
  'READ_NOW'      			     => 'Lire maintenant',
  'PRIVATE_MESSAGE_NEW'	         => 'nouveau message privé',
  'PRIVATE_MESSAGE_UNREAD'	     => 'message privé non lu',
  'NO_PMS_INFO'	                 => 'Rédiger un nouveau MP ?',
  
  'DATES'       			     => 'DATE',
  'POWERED'       			     => 'Application réalisée par',
  'HANDCRAFTED'       			 => 'Créé artisanalement avec',
  'BY'       					 => 'Par',

  'RECENT_TOPICS'       		 => 'Sujets récents',
  'TWITTER'       				 => 'Twitter',
  'FAVORITES'       			 => 'Favoris',

  'GALLERY'       				 => 'Galerie',
  'CHAT'       					 => 'Tchat',
  'ABOUT'       				 => 'À propos',
  'ABOUT_PART_ONE'       		 => 'BBOOTS&#8482; est l’un des premiers style HTML5/CSS3 non officiel pour phpBB et entièrement compatible avec le « Responsive design ». Sa conception est exempte de toute différence suivant le navigateur Web et le périphérique utilisé.',
  'ABOUT_PART_TWO'       		 => 'Basé sur la technologie Bootstrap qui fut longuement attendue par tous les adeptes du fan club de phpBB.',
  'ABOUT_PART_THREE'       		 => 'Style non officiel et responsive',
  'BB'       		             => 'B',
  'BOOTS'                		 => 'BOOTS',
  'BBOOTS'       		         => 'BBOOTS',
  
  'BBOOTS_VERSION'    			 => '<a href="http://www.sitesplat.com/phpBB3/">BBOOTS</a>',
  'U_LOGOUT'          			 => 'Se déconnecter',

  'SITESPLAT_STATISTICS'		 => 'Statistiques',
  'SITESPLAT_SEE_DETAILS'		 => 'Voir les détails',
  'SITESPLAT_SEARCH_LAST_DAY'    => 'Messages des dernières 24h',
  'SITESPLAT_SEARCH_WEEK'		 => 'Messages des 7 derniers jours',
  
  'SITESPLAT_TOTAL_POSTS'		 => 'Total des messages',
  'SITESPLAT_TOTAL_TOPICS'	     => 'Total des sujets',
  'SITESPLAT_TOTAL_USERS'		 => 'Total des membres',
  'SITESPLAT_NEWEST_MEMBER'		 => 'Nouveau membre',
  'SITESPLAT_USERS_ONLINE'		 => 'Membres en ligne',
  'SITESPLAT_MOST_USERS_ONLINE'	 => 'La plupart des membres en ligne',
  
  'BOOTSTRAP_VERSION'	         => '3.3.6',
  'FLATBOOTS'	                 => 'FLATBOOTS',
  'CHANGE_AVATAR'	             => 'Modifier l’avatar',
  'CHANGE_PASSWORD'	             => 'Changer de mot de passe',
  
  'ADMIN_TIPS'	                 => 'Trucs & astuces pour administrateur',
  'ADMIN_TIP_INTRO'	             => 'Il est possible de créer son forum phpBB sécurisé en suivant ces quelques conseils !',
  'ADMIN_TIP_ONE'	             => 'Maintenir à jour son forum phpBB.',
  'ADMIN_TIP_TWO'	             => 'Toujours utiliser un mot de passe complexe contenant aléatoirement des lettres, chiffres et caractères spéciaux.',
  'ADMIN_TIP_THREE'	             => 'Restreindre l’accès au répertoire des administrateurs…',
  'ADMIN_CHECK_IT_BTN'	         => 'Merci de visiter le site Web : SiteSplat.com pour davantage d’informations.',
  
  'USER_MINI_PROFILE'	         => 'Mini-profil de l’utilisateur',
  'USER_MINI_PROFILE_VIEW_FULL'	 => 'Voir le profil complet',
  'OFF_LINE'	                 => 'Hors-ligne',
  'USER_STATUS'	                 => 'Statut',
  'USER'	                     => 'Utilisateur',
  'TITLE'	                     => 'Titre',
  'END_TIMELINE'	             => 'Fin de la chronologie',
  'MEMBERS'	                     => 'Membres',
  'DRAFTS'	                     => 'Brouillons',
  'REPORTS'	                     => 'Rapports',
  'MODERATOR_LOGS'	             => 'Journal de modération',
  'QUEUE'	                     => 'Queue',
  'LINKS'	                     => 'Liens',
  'TOPIC_PERMISSIONS'	         => 'Permissions des sujets',
  'MODERATOR_OPTIONS'	         => 'Modérer',
  'PASSWORD_EXPLAIN_CONFIRM'	 => 'Répéter la saisie du mot de passe',
  'FORUM_REDIRECTS'	             => 'Redirections :',
  
  'FANCY_TOPICS_TITLE'	         => 'Sujets récents du forum',
  'POST_BY'	                     => 'Message par',
  'REPLY_BY'	                 => 'Réponse par',
  'NO_REPLIES'	                 => 'Aucune réponse',
  'READ_MORE'	                 => 'Lire davantage',
  'RT_READ_MORE'	             => 'LIRE DAVANTAGE',
  'RT_LOAD_MORE'	             => 'Afficher plus de messages',
  'VIEW_MORE_TOPICS'	         => 'Voir davantage de sujets',
  'BACK_TO_START'	             => 'REVENIR AU DÉBUT',
  
  'TOGGLE_NAV'	                 => 'Permuter la navigation',
  
  'DEMO_LINK'	                 => 'Aucune icône pour le lien de démonstration',
  'DEMO_HEADER_MENU'	         => 'Exemple d’entête',
  
  'FLATBOOTS_INTRO'	             => 'Cadre de travail Bootstrap',
  'FLATBOOTS_EXPLAIN'	         => 'Multitude de composants permettant l’affichage des icônes, menus déroulants, entrées, navigation, alertes, etc…',
  'CALL_TO_ACTION_FOOTER'        => 'Modifier les add-ons, utiliser uniquement ce dont on a besoin !',
  'PURCHASE_NOW_BTN'             => 'Acheter maintenant',
  'FLATBOOTS_ABOUT_PART_ONE'     => 'Pourquoi s’embêter avec moins lorsque l’on peut avoir plus ? Prière de faire attention aux promesses d’autres styles premium à caractères marketing. FLATBOOTS est conçu pour servir, conçu pour durer, conçu avec soin, rien de moins.',
  'FLATBOOTS_ABOUT_TITLE'	     => 'Conçu pour durer',
  'DMCA'	                     => 'Lien personnalisé',
  'TERMS'	                     => 'Conditions d’utilisation',
  'ADVERTISE'	                 => 'FLATBOOTS',
  'SITESPLAT'	                 => 'SiteSplat',
  'SITESPLAT_URL'	             => '<a href="http://sitesplat.com" class="btn btn-default" target="blank">SiteSplat.com</a>',
  'JOIN_US_TWITTER'	             => 'Nous rejoindre sur Twitter',
  'TWEET_EXAMPLE'	             => 'BBOOTS a atteint les 1000 ventes ! Remerciement à tous les supporters de ce projet et contributeurs de la communauté SiteSplat. Quelle est la suite ? Rester attentif en nous suivant sur Twitter : <a href="#">http://bit.ly/000fefs</a>.',
  
));
