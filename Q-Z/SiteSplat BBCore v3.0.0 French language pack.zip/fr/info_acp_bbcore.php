<?php
/**
*
* common [English]
*
* @package language
* @version $Id$
* @copyright (c) 2014 SiteSplat.com
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
    
	'ACP_SITESPLAT_UPDATE_MANAGER'=>  'Gestion des mises à jour SiteSplat',
    'ACP_SITESPLAT_V_INSTALLED'   =>  'Version installée',

    'LOG_FILES_CHANGED'			    => '<strong>BBcore a modifié les fichiers %s :</strong><br />» %s',
    'LOG_THEME_INSTALLED'			=> '<strong>BBcore installé avec succès</strong>',
    'LOG_FILES_CHANGED_FAILED'	    => '<strong>BBcore n’a pas été installé avec succès</strong><br />» Plusieurs fonctionnalités ne devraient pas fonctionner !',
    'LOG_THEME_UNINSTALLED'		    => '<strong>BBcore désinstallé avec succès</strong>',
  
    'LOG_FILE_NOT_REPLACED'		    => '<strong>BBcore pourrait ne pas remplacer les fichiers originaux :</strong><br />» %s',
    'LOG_FILE_NOT_UPDATED'		    => '<strong>BBcore pourrait ne pas mettre à jour les fichiers suivants %s :</strong><br />» %s',
    
	
	
	'LOG_BBCORE_INSTALLED'			=> '<strong>BBCore Sitesplat installé avec succès</strong>',
	'LOG_BBCORE_UNINSTALLED'		=> '<strong>BBCore Sitesplat désinstallé avec succès</strong>',

	'LOG_BBCORE_NOT_REPLACED'		=> '<strong>BBCore Sitesplat n’a pas été désinstallé avec succès</strong><br />N’a pu remplacer le(s) fichier(s) suivant(s)<br />» %s',
	'LOG_BBCORE_NOT_UPDATED'		=> '<strong>BBCore Sitesplat n’a pas été installé avec succès</strong><br />N’a pu mettre à jour le(s) fichier(s) suivant(s)<br />» %s',
    
	'ACP_BBCORE_MSG_FILES_FAIL'		=> 'Tous les fichiers n’ont pas été modifiés ! Merci de remplacer manuellement les fichiers mentionnés dans le Journal d’administration depuis l’onglet « MAINTENANCE ».',
	'ACP_BBCORE_MSG_SETTINGS'		=> 'Il n’y a pas de paramètres de configuration pour cette extension.<br />Cependant, toutes les mises à jour n’ont pas été correctement réalisées en raison des permissions des fichiers sur le serveur ou de fichiers manquants. <br />Voir le journal d’administration pour davantage de d’informations.<br /><br />Merci de mettre à jour manuellement les fichiers afin de profiter de l’ensemble des fonctionnalités.',
	
));

?>