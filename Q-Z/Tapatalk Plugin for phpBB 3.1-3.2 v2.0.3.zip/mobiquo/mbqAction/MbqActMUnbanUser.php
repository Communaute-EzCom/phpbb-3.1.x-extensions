<?php

defined('MBQ_IN_IT') or exit;

MbqMain::$oClk->includeClass('MbqBaseActMUnbanUser');

/**
 * m_unban_user action
 */
Class MbqActMUnbanUser extends MbqBaseActMUnbanUser {
    
    public function __construct() {
        parent::__construct();
    }
    
    /**
     * action implement
     */
    public function actionImplement($in) {
        parent::actionImplement($in);
    }
  
}
