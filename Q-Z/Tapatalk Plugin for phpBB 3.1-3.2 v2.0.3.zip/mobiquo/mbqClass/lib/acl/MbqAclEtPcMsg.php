<?php

defined('MBQ_IN_IT') or exit;

MbqMain::$oClk->includeClass('MbqBaseAclEtPcMsg');

/**
 * private conversation message acl class
 */
Class MbqAclEtPcMsg extends MbqBaseAclEtPcMsg {
    
    public function __construct() {
    }
  
}
