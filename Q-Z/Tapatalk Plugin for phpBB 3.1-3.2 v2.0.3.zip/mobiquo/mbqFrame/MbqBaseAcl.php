<?php

defined('MBQ_IN_IT') or exit;

/**
 * acl base class
 */
Abstract Class MbqBaseAcl {
    
    public function __construct() {
    }
  
}