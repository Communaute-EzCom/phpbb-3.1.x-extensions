<?php

/**
 * used for add extended classes
 */
//for example
//MbqMain::$oClk->reg('MbqActExttCmdName', MBQ_ACTION_PATH.'MbqActExttCmdName.php');
