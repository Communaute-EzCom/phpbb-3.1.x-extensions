<?php

/**
 * common config used for both tapatalk plugin and native system(forum)
 */
 
Class MbqCommonConfig {
    
    public static $cfg = array();
    
}

//custom config here,for example: 

