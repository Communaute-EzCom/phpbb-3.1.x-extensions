;(function($, window, document) {
	$('div.panel>div.inner>div.column2>dl.details>dd:eq(2)').after($('div.usertopiccount-hidden').contents());
})(jQuery, window, document);
