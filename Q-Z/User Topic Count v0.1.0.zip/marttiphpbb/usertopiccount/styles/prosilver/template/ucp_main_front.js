;(function($, window, document) {
	$('div.panel>div.inner>dl.details>dd:eq(1)').after($('div.usertopiccount-hidden').contents());
})(jQuery, window, document);
