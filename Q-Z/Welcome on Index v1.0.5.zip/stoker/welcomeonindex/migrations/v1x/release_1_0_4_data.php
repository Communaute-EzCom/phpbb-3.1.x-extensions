<?php
/**
*
* @package phpBB Extension - Welcome on Index
* @copyright (c) 2014 Stoker
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace stoker\welcomeonindex\migrations\v1x;

class release_1_0_4_data extends \phpbb\db\migration\migration
{
	static public function depends_on()
	{
		return array('\phpbb\db\migration\data\v310\dev');
	}

	public function update_data()
	{
		return array(
			array('config.add', array('enable_welcomeonindex', 1)),
			array('config.add', array('enable_welcomeonindex_avatar', 1)),
			array('config.add', array('enable_welcomeonindex_day_message', 1)),
			array('config.add', array('enable_welcomeonindex_joined', 1)),
			array('config_text.add', array('welcomeonindex_info', '')),
			array('config_text.add', array('welcomeonindex_info_uid', '')),
			array('config_text.add', array('welcomeonindex_info_bitfield', '')),
			array('config_text.add', array('welcomeonindex_info_flags', OPTION_FLAG_BBCODE + OPTION_FLAG_SMILIES + OPTION_FLAG_LINKS)),
		);
	}

	public function revert_data()
	{
		return array(
			array('config.remove', array('enable_welcomeonindex')),
			array('config.remove', array('enable_welcomeonindex_avatar')),
			array('config.remove', array('enable_welcomeonindex_day_message')),
			array('config.remove', array('enable_welcomeonindex_joined')),
			array('config_text.remove', array('welcomeonindex_info')),
			array('config_text.remove', array('welcomeonindex_info_uid')),
			array('config_text.remove', array('welcomeonindex_info_bitfield')),
			array('config_text.remove', array('welcomeonindex_info_flags')),
		);
	}
}
