<?php
/**
*
* @package phpBB Extension - Welcome on Index
* @copyright (c) 2014 Stoker
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace stoker\welcomeonindex\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
* Event listener
*/
class listener implements EventSubscriberInterface
{
	/** @var \phpbb\cache\driver\driver_interface */
	protected $cache;
	
	/* @var \phpbb\config\config */
	protected $config;

	/* @var \phpbb\config\db_text */
	protected $config_text;
	
	/** @var \phpbb\request\request */
	protected $request;

	/* @var \phpbb\template\template */
	protected $template;

	/* @var \phpbb\user */
	protected $user;
	
	/* @var \phpbb\controller\helper */
	protected $helper;

	/**
	* Constructor
	*
	* @param \phpbb\config\config        $config             Config object
	* @param \phpbb\template\template    $template           Template object
	* @return \stoker\welcomeonindex\event\listener
	* @access public
	*/
	public function __construct(\phpbb\cache\driver\driver_interface $cache, \phpbb\config\config $config, \phpbb\config\db_text $config_text, \phpbb\request\request $request, \phpbb\template\template $template, \phpbb\user $user, \phpbb\controller\helper $helper, \phpbb\collapsiblecategories\operator\operator $operator = null)
	{
		$this->cache = $cache;
		$this->config = $config;
		$this->config_text = $config_text;
		$this->request = $request;
		$this->template = $template;
		$this->user = $user;
		$this->helper = $helper;
		$this->operator = $operator;
	}


	/**
	* Assign functions defined in this class to event listeners in the core
	*
	* @return array
	* @static
	* @access public
	*/
	static public function getSubscribedEvents()
	{
		return array(
			'core.page_header'						=> 'main',
			'core.ucp_prefs_personal_data'			=> 'ucp_prefs_get_data',
			'core.ucp_prefs_personal_update_data'	=> 'ucp_prefs_set_data',
		);
	}

	public function main($event)
	{
		$this->user->add_lang_ext('stoker/welcomeonindex', 'common');
		$this->template->assign_vars(array(
			'S_WELCOMEONINDEX'		=>	!empty($this->user->data['user_welcomeonindex']) ? true : false,
		));
		$date = $this->user->format_date(time(), 'H');
		
		if ($this->operator !== null)
		{
			$fid = 'foo_welcomeonindex'; // can be any unique string to identify your extension's collapsible element
			$this->template->assign_vars(array(
				'S_FOO_WELCOMEONINDEX_HIDDEN' => in_array($fid, $this->operator->get_user_categories()),
				'U_FOO_WELCOMEONINDEX_COLLAPSE_URL' => $this->helper->route('phpbb_collapsiblecategories_main_controller', array(
					'forum_id' => $fid,
					'hash' => generate_link_hash("collapsible_$fid")))
			));
		}

		if ($this->user->data['is_registered'])
		{
			$u_user_name = get_username_string('full', $this->user->data['user_id'], $this->user->data['username'], $this->user->data['user_colour']);
		}
		else
		{
			$u_user_name = $this->user->lang['WELCOME_GUEST'];
		}    

		switch (true)
		{
				case ($date < 1):
					// if the hour is 01 - 23
					$s_welcome = sprintf($this->user->lang['GOOD_NIGHT'], $u_user_name);;
				break;
				
				case ($date < 4):
					// if the hour is 01 - 04
					$s_welcome = sprintf($this->user->lang['UP_LATE'], $u_user_name);
				break;
				
				case ($date < 7):
					// if the hour is 04 - 07 
					$s_welcome = sprintf($this->user->lang['UP_EARLY'], $u_user_name);
				break;
				
				case ($date < 10):
					// if the hour is 07 - 10 am
					$s_welcome = sprintf($this->user->lang['GOOD_MORNING'], $u_user_name);
				break;
				
				case ($date < 14):
					// if the hour is 10 - 14
					$s_welcome = sprintf($this->user->lang['GOOD_DAY'], $u_user_name);
				break;
				
				case ($date < 18):
					// if the hour is 14 - 18
					$s_welcome = sprintf($this->user->lang['GOOD_AFTERNOON'], $u_user_name);
				break;
				
				case ($date < 24):
					// if the hour is 18 - 24
					$s_welcome = sprintf($this->user->lang['GOOD_EVENING'], $u_user_name);;
				break;
		}

		// how long a member for
		$member_for = '';
		if ($this->user->data['is_registered'] && !$this->user->data['is_bot'])
		{
			$member_length = time() - $this->user->data['user_regdate'];
			$years = $months = $days = 0;
			$member_for = '';
			if ($member_length)
			{    
				if ($member_length >= 31536000)
				{
					$years = floor($member_length / 31536000);
					$member_length = $member_length - ($years * 31536000);
					$member_for .= $years > 1 ? ($years . '&nbsp;' . $this->user->lang['WELCOME_YEARS'] . ', ') : ($years . '&nbsp;' . $this->user->lang['WELCOME_YEAR'] . ', ');
				}
				$months = floor($member_length / 2628000);
				if ($months)
				{
					$months = $months > 1 ? ($months . '&nbsp;' . $this->user->lang['WELCOME_MONTHS'] . ', ') : ($months . '&nbsp;' . $this->user->lang['WELCOME_MONTHS'] . ', ');
					$member_length = $member_length - ($months * 2628000);
					$member_for .= $months;
				}
				$days = floor($member_length / 86400);
				if ($days)
				{
					$days = $days > 1 ? ($days . '&nbsp;' . $this->user->lang['WELCOME_DAYS']) : ($days . '&nbsp;' . $this->user->lang['WELCOME_DAY']);
					$member_for .= $days;
				}        
			}
		}
		
		$welcomeonindex_data = $this->cache->get('_welcomeonindex_data');
		$welcomeonindex_data = $this->config_text->get_array(array(
				'welcomeonindex_info',
				'welcomeonindex_info_uid',
				'welcomeonindex_info_bitfield',
				'welcomeonindex_info_flags',
		));
		$this->cache->put('_welcomeonindex', $welcomeonindex_data);

		$welcomeonindex_text = generate_text_for_display(
			$welcomeonindex_data['welcomeonindex_info'],
			$welcomeonindex_data['welcomeonindex_info_uid'],
			$welcomeonindex_data['welcomeonindex_info_bitfield'],
			$welcomeonindex_data['welcomeonindex_info_flags']
		);
		
		$this->template->assign_vars(array(  
			'S_WELCOME'            					=> $s_welcome,
			'S_JOINED_DATE'         				=> $this->user->format_date($this->user->data['user_regdate']),
			'MEMBER_FOR'           					=> (!empty($member_for)) ? $this->user->lang['MEMBER_FOR'] . '&nbsp;' . $member_for : '',
			'WELCOMEONINDEX_OUTPUT'					=> $welcomeonindex_text,
			'ENABLE_WELCOMEONINDEX'					=> $this->config['enable_welcomeonindex'],
			'ENABLE_WELCOMEONINDEX_AVATAR'			=> $this->config['enable_welcomeonindex_avatar'],
			'ENABLE_WELCOMEONINDEX_DAY_MESSAGE'		=> $this->config['enable_welcomeonindex_day_message'],
			'ENABLE_WELCOMEONINDEX_JOINED'			=> $this->config['enable_welcomeonindex_joined'],
		));
	}
	
	/**
	* Get user's option and display it in UCP Prefs View page
	*
	* @param object $event The event object
	* @return null
	* @access public
	*/
	public function ucp_prefs_get_data($event)
	{
		// Request the user option vars and add them to the data array
		$event['data'] = array_merge($event['data'], array(
			'welcomeonindex'			=> $this->request->variable('welcomeonindex', (int) $this->user->data['user_welcomeonindex']),
		));

		// Output the data vars to the template (except on form submit)
		if (!$event['submit'])
		{
			$this->user->add_lang_ext('stoker/welcomeonindex', 'welcomeonindex_ucp');
			$this->template->assign_vars(array(
				'S_UCP_WELCOMEONINDEX'		=> $event['data']['welcomeonindex'],
			));
		}
	}

	/**
	* Add user's welcome option state into the sql_array
	*
	* @param object $event The event object
	* @return null
	* @access public
	*/
	public function ucp_prefs_set_data($event)
	{
		$event['sql_ary'] = array_merge($event['sql_ary'], array(
			'user_welcomeonindex' => $event['data']['welcomeonindex'],
		));
	}
}