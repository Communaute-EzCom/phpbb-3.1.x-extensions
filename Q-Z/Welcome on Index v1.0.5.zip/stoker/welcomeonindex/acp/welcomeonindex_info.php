<?php
/**
*
* @package phpBB Extension - Welcome on Index
* @copyright (c) 2014 Stoker
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace stoker\welcomeonindex\acp;

/**
* @package module_install
*/
class welcomeonindex_info
{
	function module()
	{
		return array(
			'filename'	=> '\stoker\welcomeonindex\acp\welcomeonindex_module',
			'title'		=> 'ACP_WELCOMEONINDEX',
			'modes'		=> array(
				'settings'	=> array(
					'title' => 'ACP_WELCOMEONINDEX_SETTINGS',
					'auth' => 'ext_stoker/welcomeonindex && acl_a_board',
					'cat' => array('ACP_WELCOMEONINDEX')
				),
			),
		);
	}
}
