<?php
/**
*
* @package phpBB Extension - Welcome on Index
* @copyright (c) 2014 Stoker
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace stoker\welcomeonindex\acp;

/**
* @package acp
*/
class welcomeonindex_module
{
	public $u_action;

	public function main($id, $mode)
	{
		global $user, $request, $template, $config, $cache, $phpbb_root_path, $phpEx, $phpbb_container;
		
		$this->cache = $cache;
		
		$user->add_lang_ext('stoker/welcomeonindex', 'welcomeonindex_acp');
		
		$user->add_lang(array('acp/board', 'posting'));
		
		$this->tpl_name = 'acp_welcomeonindex';
		$this->page_title = 'ACP_WELCOMEONINDEX';
		
		$form_name = 'acp_welcomeonindex';
		add_form_key($form_name);
		$error = '';
		
		if (!function_exists('display_custom_bbcodes'))
		{
			include($phpbb_root_path . 'includes/functions_display.' . $phpEx);
		}
		
		if (!class_exists('parse_message'))
		{
			include($phpbb_root_path . 'includes/message_parser.' . $phpEx);
		}
		$config_text = $phpbb_container->get('config_text');
		$welcomeonindex_data	= $config_text->get_array(array(
		'welcomeonindex_info',
		'welcomeonindex_info_uid',
		'welcomeonindex_info_bitfield',
		'welcomeonindex_info_flags',
		));
		
		$welcomeonindex_info = $welcomeonindex_data['welcomeonindex_info'];
		$welcomeonindex_info_uid = $welcomeonindex_data['welcomeonindex_info_uid'];
		$welcomeonindex_info_bitfield = $welcomeonindex_data['welcomeonindex_info_bitfield'];
		$welcomeonindex_info_flags = $welcomeonindex_data['welcomeonindex_info_flags'];
		
		if ($request->is_set_post('submit') || $request->is_set_post('preview'))
		{
			if (!check_form_key($form_name))
			{
				$error = $user->lang('FORM_INVALID');
			}
			$welcomeonindex_info = $request->variable('welcomeonindex_info', '', true);
			generate_text_for_storage(
				$welcomeonindex_info,
				$welcomeonindex_info_uid,
				$welcomeonindex_info_bitfield,
				$welcomeonindex_info_flags,
				!$request->variable('disable_bbcode', false),
				!$request->variable('disable_magic_url', false),
				!$request->variable('disable_smilies', false)
			);
			if (empty($error) && $request->is_set_post('submit'))
			{
				$config->set('enable_welcomeonindex', $request->variable('enable_welcomeonindex', false));
				$config->set('enable_welcomeonindex_avatar', $request->variable('enable_welcomeonindex_avatar', false));
				$config->set('enable_welcomeonindex_day_message', $request->variable('enable_welcomeonindex_day_message', false));
				$config->set('enable_welcomeonindex_joined', $request->variable('enable_welcomeonindex_joined', false));

				$config_text->set_array(array(
				'welcomeonindex_info'	=> $welcomeonindex_info,
				'welcomeonindex_info_uid'	=> $welcomeonindex_info_uid,
				'welcomeonindex_info_bitfield'	=> $welcomeonindex_info_bitfield,
				'welcomeonindex_info_flags'	=> $welcomeonindex_info_flags,
				));
				$this->cache->destroy('_welcomeonindex_data');
				trigger_error($user->lang['WELCOMEONINDEX_UPDATED'] . adm_back_link($this->u_action));
			}
		}
		
		$welcomeonindex_info_preview = '';
		
		if ($request->is_set_post('preview'))
		{
			$welcomeonindex_info_preview = generate_text_for_display($welcomeonindex_info, $welcomeonindex_info_uid, $welcomeonindex_info_bitfield, $welcomeonindex_info_flags);
		}
		$welcomeonindex_edit = generate_text_for_edit($welcomeonindex_info, $welcomeonindex_info_uid, $welcomeonindex_info_flags);
		
		$template->assign_vars(array(
			'ERRORS'								=> $error,
			'ACP_WELCOMEONINDEX_INFO'				=> $welcomeonindex_edit['text'],
			'ACP_WELCOMEONINDEX_INFO_PREVIEW'		=> $welcomeonindex_info_preview,
			'ENABLE_WELCOMEONINDEX'					=> $config['enable_welcomeonindex'],
			'ENABLE_WELCOMEONINDEX_AVATAR'			=> $config['enable_welcomeonindex_avatar'],
			'ENABLE_WELCOMEONINDEX_DAY_MESSAGE'		=> $config['enable_welcomeonindex_day_message'],
			'ENABLE_WELCOMEONINDEX_JOINED'			=> $config['enable_welcomeonindex_joined'],
			'S_BBCODE_DISABLE_CHECKED'				=> !$welcomeonindex_edit['allow_bbcode'],
			'S_SMILIES_DISABLE_CHECKED'				=> !$welcomeonindex_edit['allow_smilies'],
			'S_MAGIC_URL_DISABLE_CHECKED'			=> !$welcomeonindex_edit['allow_urls'],
			'BBCODE_STATUS'							=> $user->lang('BBCODE_IS_ON', '<a href="' . append_sid("{$phpbb_root_path}faq.$phpEx", 'mode=bbcode') . '">', '</a>'),
			'SMILIES_STATUS'						=> $user->lang['SMILIES_ARE_ON'],
			'IMG_STATUS'							=> $user->lang['IMAGES_ARE_ON'],
			'FLASH_STATUS'							=> $user->lang['FLASH_IS_ON'],
			'URL_STATUS'							=> $user->lang['URL_IS_ON'],
			'S_BBCODE_ALLOWED'						=> true,
			'S_SMILIES_ALLOWED'						=> true,
			'S_BBCODE_IMG'							=> true,
			'S_BBCODE_FLASH'						=> true,
			'S_LINKS_ALLOWED'						=> true,
		));
	// Assigning custom bbcodes
	display_custom_bbcodes();
	}
}
 