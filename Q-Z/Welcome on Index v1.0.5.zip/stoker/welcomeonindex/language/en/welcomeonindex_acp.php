<?php
/**
*
* @package phpBB Extension - Welcome on Index
* @copyright (c) 2014 Stoker
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//

$lang = array_merge($lang, array(
	'WELCOMEONINDEX_UPDATED'					=> 'Welcome On Index settings updated',
	'ACP_WELCOMEONINDEX_DONATE'					=> 'Please consider a <a href="http://www.phpbb3bbcodes.com/donate.php" onclick="window.open(this.href);return false;"><strong>Donation</strong></a> if you like the Extension',
	'ACP_WELCOMEONINDEX_SETTINGS'				=> 'Welcome On Index settings',
	'ACP_WELCOMEONINDEX_INFO_PREVIEW'			=> 'Welcome On Index preview',
	
	'ACP_WELCOMEONINDEX_INFO'					=> 'Welcome text',
	'ACP_WELCOMEONINDEX_INFO_EXPLAIN'			=> 'You can edit the text which is displayed in the Welcome On Index box.',
	'ACP_ENABLE_WELCOMEONINDEX'					=> 'Enable Welcome On Index',
	'ACP_ENABLE_WELCOMEONINDEX_AVATAR'			=> 'Enable Avatar display',
	'ACP_ENABLE_WELCOMEONINDEX_DAY_MESSAGE'		=> 'Enable Welcome time of day message',
	'ACP_ENABLE_WELCOMEONINDEX_JOINED'			=> 'Enable joined info',
));
