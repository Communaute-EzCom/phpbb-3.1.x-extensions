<?php
/**
*
* Croatian translation by Ančica Sečan (http://ancica.sunceko.net)
*
*/

if (!defined('IN_PHPBB'))
{
exit;
}

if (empty($lang) || !is_array($lang))
{
$lang = array();
}

$lang = array_merge($lang, array(
'TOPIC_AUTHOR'=>'Autor/ica teme',
));
