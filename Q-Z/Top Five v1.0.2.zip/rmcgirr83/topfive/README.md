phpbb-3.1-ext-topfive
=========================

phpBB 3.1 extension that displays the latest topics, new users and most active users.

This extension is the 3.1.x version of the [3.0.x Top Five Mod](https://www.phpbb.com/customise/db/mod/top_five/

[![Build Status](https://travis-ci.org/RMcGirr83/phpBB-3.1-topfive.svg?branch=master)](https://travis-ci.org/RMcGirr83/phpBB-3.1-topfive)
## Installation

### 1. clone
Clone (or download and move) the repository into the folder phpBB3/ext/rmcgirr83/topfive:

```
cd phpBB3
git clone https://github.com/RMcGirr83/php-3.1-ext-topfive.git ext/rmcgirr83/topfive/
```

### 2. activate
Go to admin panel -> tab customise -> Manage extensions -> enable Top Five

