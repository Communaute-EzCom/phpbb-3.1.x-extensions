<?php

defined('MBQ_IN_IT') or exit;

/**
 * cookie handle
 */
Class MbqCookie {
    
    public function __construct() {
    }
  
}
