<html>
    <head></head>
    <body>
        <div><a href="../tapatalk.php?do=config" target="_blank">config</a></div>
        <div><a href="../tapatalk.php?do=forums" target="_blank">forums</a></div>
        <div><a href="../tapatalk.php?do=forum&fid=3&content=topic&type=normal" target="_blank">forum:only normal topic</a></div>
        <div><a href="../tapatalk.php?do=topic&tid=1" target="_blank">topic</a></div>
    </body>
</html>