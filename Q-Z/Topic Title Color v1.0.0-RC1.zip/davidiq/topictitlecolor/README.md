# Topic Title Color

## Installation

Copy the extension to phpBB/ext/davidiq/topictitlecolor

Go to "ACP" > "Customise" > "Extensions" and enable the "Topic Title Color" extension.

## License

[GPLv2](license.txt)
