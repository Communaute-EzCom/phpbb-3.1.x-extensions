$('#topic_title_color_palette_placeholder').each(function() {
    phpbb.registerPalette($(this));
});
