<?php
/**
*
* @package phpBB Extension - Right Random Image
* @copyright (c) 2015 - HiFiKabin
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace hifikabin\rightrandomimage\acp;

/**
* @package acp
*/

class main_module
{
	var $u_action;

	function main($id, $mode)
	{
		global $db, $user, $template, $request, $phpbb_log, $phpbb_container, $cache, $config;

		$this->cache = $cache;
		$this->tpl_name 		= 'acp_rightrandomimage';
		$this->page_title 		= $user->lang['ACP_RIGHTRANDOMIMAGE_TITLE'];
		$this->request 			= $request;
		$this->log				= $phpbb_log;
		$this->config			= $config;
		$rightrandomimage_table	= $phpbb_container->getParameter('tables.rightrandomimage_table');

		add_form_key('rightrandomimage/acp_rightrandomimage');

		$sql = 'SELECT *
		FROM '. $rightrandomimage_table;
		$result = $db->sql_query($sql);

		while ($row = $db->sql_fetchrow($result))
		{
			if (!empty($row['rri_image']))
			{
				$template->assign_block_vars('rri_images', array(
					'RRI_IMAGE'		=> $row['rri_image'],
					'RRI_LINK'		=> $row['rri_link'],
				));
			}
		};


		if (empty($row['rri_image']))
		{
			$template->assign_block_vars('rri_images', array(
				'RRI_IMAGE' => '',
			));
		};
		$db->sql_freeresult($result);

		$submit = $request->is_set_post('submit');
		if ($submit)
		{
			if (!check_form_key('rightrandomimage/acp_rightrandomimage'))
			{
				trigger_error('FORM_INVALID');
			}

			$config->set('rightrandomimage_enable', $request->variable('rightrandomimage_enable', 0));
			$config->set('rightrandomimage_search', $request->variable('rightrandomimage_search', 0));
			$config->set('rightrandomimage_open', $request->variable('rightrandomimage_open', 0));
			$config->set('rightrandomimage_resize', $request->variable('rightrandomimage_resize', 0));

			$sql = 'DELETE FROM ' . $rightrandomimage_table ;
			$db->sql_query($sql);

			$rightrandomimage_enable = $this->request->variable('rightrandomimage_enable',' ',true);
			$this->config->set('rightrandomimage_enable', $rightrandomimage_enable);


			$rri_image 		= $this->request->variable('rri_image', array('' => ''),true);
			$rri_link 		= $this->request->variable('rri_link', array('' => ''),true);

			$i = 0;
			while ($i < count($rri_image))
			{
				$sql_ary1 = array(
				'rri_image' 		=> $rri_image[$i],
				'rri_link'			=> $rri_link[$i],
				);
				$db->sql_query('INSERT INTO ' . $rightrandomimage_table . ' ' . $db->sql_build_array('INSERT', $sql_ary1));
				$i++;
			}

			$cache->destroy('sql', $rightrandomimage_table);

			$user_id = $user->data['user_id'];
			$user_ip = $user->ip;

			$phpbb_log->add('admin', $user_id, $user_ip, 'LOG_RIGHTRANDOMIMAGE_SAVE');
			trigger_error($user->lang['RIGHTRANDOMIMAGE_SAVED'] . adm_back_link($this->u_action));
		}

		$template->assign_vars(array(
			'RIGHTRANDOMIMAGE_ENABLE'		=> $this->config['rightrandomimage_enable'],
			'RIGHTRANDOMIMAGE_SEARCH'		=> $this->config['rightrandomimage_search'],
			'RIGHTRANDOMIMAGE_OPEN'			=> $this->config['rightrandomimage_open'],
			'RIGHTRANDOMIMAGE_RESIZE'		=> $this->config['rightrandomimage_resize'],
		));
	}
}
