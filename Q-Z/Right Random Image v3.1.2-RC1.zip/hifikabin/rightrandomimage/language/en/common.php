<?php
/**
*
* @package phpBB Extension - Right Random Image
* @copyright (c) 2015 - HiFiKabin
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/


if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}
// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ » “ ” …
//
$lang = array_merge($lang, array(
	'ACP_RIGHTRANDOMIMAGE_TITLE'			=> 'Right Random Image',
	'RIGHTRANDOMIMAGE_SAVED'				=> 'Right Random Image Settings Saved.',
	'RIGHTRANDOMIMAGE_CONFIG_SET'			=> 'Configuration',

	'LOG_RIGHTRANDOMIMAGE_SAVE'				=> 'Right Random Image Extension settings changed.',

	'RIGHTRANDOMIMAGE_ENABLE'				=> 'Enable Right Random Image',
	'RIGHTRANDOMIMAGE_ENABLE_EXPLAIN'		=> 'Do you want to enable the Right Random Image EXT?',

	'RIGHTRANDOMIMAGE_SEARCH'				=> 'Search',
	'RIGHTRANDOMIMAGE_SEARCH_EXPLAIN'		=> 'Do you want to show the Search in the NavBar when Right Random Image is enabled?',

	'RIGHTRANDOMIMAGE_RESIZE'				=> 'Image Size',
	'RIGHTRANDOMIMAGE_RESIZE_EXPLAIN'		=> 'You can change the maximum size of the image here but be aware that larger images may upset the layout within the header. Default is 200',

	'RIGHTRANDOMIMAGE_OPEN'					=> 'Link Opening',
	'RIGHTRANDOMIMAGE_OPEN_EXPLAIN'			=> 'Do you want the clicked link to open in a new tab/window?',
	
	'RIGHTRANDOMIMAGE_INSTRUCTIONS'			=> 'Right Random Image Instructions',

	'RIGHTRANDOMIMAGE_RANDOM'				=> 'What is Random?',
	'RIGHTRANDOMIMAGE_RANDOM_INFO'			=> 'Random in this instance means a random selection at each page load. There is no reference to any previously loaded images so there will be times when the same image is loaded several times in succession.',
	'RIGHTRANDOMIMAGE_IMAGE_INFO'			=> 'Images can be stored on the board, or externally.</br> Then add the FULL URL of the image in the Image URL field .</br>If you leave the image field empty that image and link will be deleted.',
	'RIGHTRANDOMIMAGE_LINK_INFO'			=> 'Enter the FULL URL of the page you wish to link the image to.</br>If you leave this field empty clicking the image will direct to the board index.',

	'RIGHTRANDOMIMAGE_NOTE'					=> 'Notes',
	'RIGHTRANDOMIMAGE_NOTE_INFO'			=> 'The Right Random Image is hidden on smaller screens.<br>You can add as many or as few images as you require.</br>For best visual results all images should be the same size',

	'RIGHTRANDOMIMAGE_IMAGE'				=> 'Image URL',
	'RIGHTRANDOMIMAGE_LINK'					=> 'Link URL',

	'RIGHTRANDOMIMAGE_MORE_IMAGES'			=> 'Add Another Image',
	'RIGHTRSANDOMIMAGE_REQUIRE_3.1.4'		=> 'This Extension needs at least phpBB 3.1.4 and will not work with phpBB 3.2.0',
	'RIGHTRSANDOMIMAGE_REQUIRE_3.2.0'		=> 'This Extension is for phpBB 3.2.0 and later. It will not work with phpBB 3.1.0',
));

