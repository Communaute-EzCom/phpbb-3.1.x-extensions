<?php
/**
*
* @package phpBB Extension - Right Random Image
* @copyright (c) 2015 - HiFiKabin
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace hifikabin\rightrandomimage\migrations;

class rightrandomimage_data extends \phpbb\db\migration\migration
{

	public function update_schema()
	{
		return array(
			'add_tables'	=> array(
			// ADD NEW TABLE STRUCTURE
				$this->table_prefix . 'rightrandomimage'	=> array(
					'COLUMNS' => array(
					'rri_id'			=> array('UINT', null, 'auto_increment'),
					'rri_image'			=> array('VCHAR', ''),
					'rri_link'			=> array('VCHAR', ''),
					),
					'PRIMARY_KEY'	=> 'rri_id',
				),
			),
		);
	}

	public function update_data()
	{
		// ADD CONFIG 
		return array(
			array('config.add', array('rightrandomimage_enable', '0')),
			array('config.add', array('rightrandomimage_search', '0')),
			array('config.add', array('rightrandomimage_open', '0')),
			array('config.add', array('rightrandomimage_resize', '200')),
			
		// Add ACP modules
			array('module.add', array('acp', 'ACP_CAT_DOT_MODS', 'ACP_RIGHTRANDOMIMAGE_TITLE')),
			array('module.add', array('acp', 'ACP_RIGHTRANDOMIMAGE_TITLE', array(
				'module_basename'	=> '\hifikabin\rightrandomimage\acp\main_module',
				'module_langname'	=> 'ACP_RIGHTRANDOMIMAGE',
				'module_mode'		=> 'overview',
				'module_auth'		=> 'ext_hifikabin/rightrandomimage && acl_a_board',
			))),
		);
	}

	/**
	* Drop the Timezone Clock table schema from the database
	*
	* @return array Array of table schema
	* @access public
	*/
	public function revert_schema()
	{
		return array(
			'drop_tables'	=> array(
				$this->table_prefix . 'rightrandomimage',
			),
		);
	}
}
