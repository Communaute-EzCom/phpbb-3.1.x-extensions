# phpbb-ext-recaptcha2

[![Build Status](https://travis-ci.org/gothick/phpbb-ext-recaptcha2.svg?branch=master)](https://travis-ci.org/gothick/phpbb-ext-recaptcha2)
[![Scrutinizer Code Quality](https://scrutinizer-ci.com/g/gothick/phpbb-ext-recaptcha2/badges/quality-score.png?b=master)](https://scrutinizer-ci.com/g/gothick/phpbb-ext-recaptcha2/?branch=master)

Current status: Initial release. Seems to be in use by quite
a few people, given the number of contributions I've seen. I've
been using it on my live (but not terribly busy) board for
months.


