<?php
/**
*  phpBB Extension - marttiphpbb templateevents
* @copyright (c) 2014 marttiphpbb <info@martti.be>
* @license GNU General Public License, version 2 (GPL-2.0)
*/

namespace marttiphpbb\templateevents;

use phpbb\extension\base;

class ext extends base
{

}
