topicdescriptions
=========================

An extension for phpBB 3.1.x that allows users to add a description to their topics.

## Installation

### 1. clone
Clone (or download and move) the repository into the folder phpBB3/ext/kinerity/topicdescriptions:

```
cd phpBB3
git clone https://github.com/kinerity/topicdescriptions.git ext/kinerity/topicdescriptions/
```

### 2. activate
Go to Administration Control Panel -> CUSTOMISE tab -> Manage extensions and enable Topic Descriptions
