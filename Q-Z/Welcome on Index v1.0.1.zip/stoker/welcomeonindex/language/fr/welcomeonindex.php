<?php
/**
*
* @package phpBB Extension - Welcome on Index
* @copyright (c) 2014 Stoker
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
* French translation by Galixte (http://www.galixte.com)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine

$lang = array_merge($lang, array(
    'UP_LATE'             		=> 'Vous êtes en retard %1$s, vous ne devriez pas être en train de dormir ?',
    'UP_EARLY'             		=> 'Bien le bonjour %1$s, vous vous êtes levé tôt aujourd’hui',
    'GOOD_MORNING'           	=> 'Bonjour %1$s, quelle belle matinée, n’est-ce pas ?',
	'GOOD_DAY'        			=> 'Salutations %1$s, nous espérons que vous apprécierez ces lieux',
    'GOOD_AFTERNOON'       		=> 'Bienvenue %1$s, finalement vous êtes là',
    'GOOD_EVENING'           	=> 'Bonsoir %1$s, nous sommes ravis de vous voir ici',
   	'GOOD_NIGHT'           		=> 'Bonne nuit %1$s, il est peut-être temps d’aller au lit',
    'MEMBER_FOR'           		=> 'Membre depuis :',
    'WELCOME_GUEST'           	=> 'invité',
    'WELCOME_HOUR'           	=> 'heure',
    'WELCOME_HOURS'           	=> 'heures',
   	'WELCOME_DAY'           	=> 'jour',
    'WELCOME_DAYS'           	=> 'jours',
    'WELCOME_MONTH'           	=> 'mois',
    'WELCOME_MONTHS'       		=> 'mois',
   	'WELCOME_YEAR'           	=> 'année',
    'WELCOME_YEARS'				=> 'années',
	'WELCOME_TO_MOD'			=> 'Bienvenue sur',
));
