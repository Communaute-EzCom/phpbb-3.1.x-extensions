<?php
/**
*
* @package phpBB Extension - Welcome on Index
* @copyright (c) 2014 Stoker
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace stoker\welcomeonindex\event;

/**
* @ignore
*/
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
* Event listener
*/
class listener implements EventSubscriberInterface
{
	/* @var \stoker\welcomeonindex\core\functions_welcomeonindex */
	protected $tf_functions;

	public function __construct(\stoker\welcomeonindex\core\functions_welcomeonindex $functions)
	{
		$this->welcomeonindex_functions = $functions;
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.user_setup' => 'load_language_on_setup',
			'core.index_modify_page_title'	=> 'main',
		);
	}

	public function main($event)
	{

		$this->welcomeonindex_functions->welcomeonindex();
	}

	public function load_language_on_setup($event)
	{
		$lang_set_ext = $event['lang_set_ext'];
		$lang_set_ext[] = array(
			'ext_name' => 'stoker/welcomeonindex',
			'lang_set' => 'welcomeonindex',
		);
		$event['lang_set_ext'] = $lang_set_ext;
	}
}
