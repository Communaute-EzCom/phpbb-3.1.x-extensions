<?php

/**
*
* @package Welcome on Index
* @copyright (c) 2014 Stoker
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*
*/

namespace stoker\welcomeonindex\core;

class functions_welcomeonindex
{
	/** @var \phpbb\auth\auth */
	protected $auth;

	/** @var \phpbb\config\config */
	protected $config;

	/** @var \phpbb\db\driver\driver */
	protected $db;

	/** @var \phpbb\event\dispatcher_interface */
	protected $dispatcher;

	/** @var \phpbb\template\template */
	protected $template;

	/** @var \phpbb\user */
	protected $user;

	/** @var string phpBB root path */
	protected $phpbb_root_path;

	/** @var string PHP extension */
	protected $php_ext;

	public function __construct(\phpbb\auth\auth $auth, \phpbb\config\config $config, \phpbb\cache\service $cache, \phpbb\db\driver\driver_interface $db, \phpbb\event\dispatcher_interface $dispatcher, \phpbb\template\template $template, \phpbb\user $user, $phpbb_root_path, $php_ext)
	{
		$this->auth = $auth;
		$this->config = $config;
		$this->db = $db;
		$this->dispatcher = $dispatcher;
		$this->template = $template;
		$this->user = $user;
		$this->root_path = $phpbb_root_path;
		$this->php_ext = $php_ext;
	}

	public function welcomeonindex()
	{
	$date = $this->user->format_date(time(), 'H');

	if ($this->user->data['is_registered'])
	{
		$u_user_name = get_username_string('full', $this->user->data['user_id'], $this->user->data['username'], $this->user->data['user_colour']);
	}
	else
	{
		$u_user_name = $this->user->lang['WELCOME_GUEST'];
	}    

	switch (true)
	{
			case ($date < 1):
				// if the hour is 01 - 23
				$s_welcome = sprintf($this->user->lang['GOOD_NIGHT'], $u_user_name);;
			break;
			
			case ($date < 4):
				// if the hour is 01 - 04
				$s_welcome = sprintf($this->user->lang['UP_LATE'], $u_user_name);
			break;
			
			case ($date < 7):
				// if the hour is 04 - 07 
				$s_welcome = sprintf($this->user->lang['UP_EARLY'], $u_user_name);
			break;
			
			case ($date < 10):
				// if the hour is 07 - 10 am
				$s_welcome = sprintf($this->user->lang['GOOD_MORNING'], $u_user_name);
			break;
			
			case ($date < 14):
				// if the hour is 10 - 14
				$s_welcome = sprintf($this->user->lang['GOOD_DAY'], $u_user_name);
			break;
			
			case ($date < 18):
				// if the hour is 14 - 18
				$s_welcome = sprintf($this->user->lang['GOOD_AFTERNOON'], $u_user_name);
			break;
			
			case ($date < 24):
				// if the hour is 18 - 24
				$s_welcome = sprintf($this->user->lang['GOOD_EVENING'], $u_user_name);;
			break;
	}

	// how long a member for
	$member_for = '';
	if ($this->user->data['is_registered'] && !$this->user->data['is_bot'])
	{
		$member_length = time() - $this->user->data['user_regdate'];
		$years = $months = $days = 0;
		$member_for = '';
		if ($member_length)
		{    
			if ($member_length >= 31536000)
			{
				$years = floor($member_length / 31536000);
				$member_length = $member_length - ($years * 31536000);
				$member_for .= $years > 1 ? ($years . '&nbsp;' . $this->user->lang['WELCOME_YEARS'] . ', ') : ($years . '&nbsp;' . $this->user->lang['WELCOME_YEAR'] . ', ');
			}
			$months = floor($member_length / 2628000);
			if ($months)
			{
				$months = $months > 1 ? ($months . '&nbsp;' . $this->user->lang['WELCOME_MONTHS'] . ', ') : ($months . '&nbsp;' . $this->user->lang['WELCOME_MONTHS'] . ', ');
				$member_length = $member_length - ($months * 2628000);
				$member_for .= $months;
			}
			$days = floor($member_length / 86400);
			if ($days)
			{
				$days = $days > 1 ? ($days . '&nbsp;' . $this->user->lang['WELCOME_DAYS']) : ($days . '&nbsp;' . $this->user->lang['WELCOME_DAY']);
				$member_for .= $days;
			}        
		}
	}
	// END Welcome Mod
	
	// Assign portal specific vars
	$this->template->assign_vars(array(
		// BEGIN Welcome Mod    
		'S_WELCOME'             => $s_welcome,
		'S_JOINED_DATE'         => $this->user->lang['JOINED'] . ':&nbsp;' . $this->user->format_date($this->user->data['user_regdate']),
		'MEMBER_FOR'            => (!empty($member_for)) ? $this->user->lang['MEMBER_FOR'] . '&nbsp;' . $member_for : '',
		// END Welcome Mod
	));
	}
}
