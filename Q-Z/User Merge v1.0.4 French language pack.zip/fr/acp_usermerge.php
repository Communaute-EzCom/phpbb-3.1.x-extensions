<?php
/**
 *
 * User Merge. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2018 RMcGirr83 (Rich McGirr) rmcgirr83@rmcgirr83.org & Jari Kanerva (tumba25) <http://www.phpbbmodders.net>
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

// Merge the following language entries into the lang array
$lang = array_merge($lang, array(
	'VERSION' 			=> 'Version',
	'NO_USER_FOR_MERGE'			=> 'Un membre spécifié pour la fusion n’est peut-être pas situé dans la base de données.',
	'NO_USER_SPECIFIED'			=> 'Un membre pour la fusion n’a pas été spécifié.',
	'CANNOT_MERGE_SAME'			=> 'Il n’est pas possible de fusionner et supprimer le même membre.',
	'CANNOT_MERGE_SELF'			=> 'Il n’est pas possible de supprimer son propre compte.',
	'CANNOT_MERGE_FOUNDER'		=> 'Les fondateurs ne peuvent être supprimés par d’autres fondateurs.',
	'CANNOT_MERGE_SAME'			=> 'Le compte utilisateur <strong>%s</strong> ne peut être fusionné avec lui-même.',

	'USERS_MERGED'				=> 'Les membres spécifiés ont été fusionnés avec succès.',
	'MERGE_USERS'				=> 'Fusionner des membres',
	'MERGE_USERS_CONFIRM'		=> 'Confirmer la fusion de ces membres ?<br /><strong>%s sera supprimé, une fois la fusion réalisée il n’est pas possible d’annuler cette action.</strong>',
	'ACP_USER_MERGE_TITLE'		=> 'Fusionner des membres',
	'ACP_USER_MERGE_EXPLAIN'	=> 'Depuis cette page il est possible de fusionner deux comptes utilisateur en un seul. Merci de noter que l’ancien compte sera supprimé et que seul son contenu sera transféré au nouveau membre.',

	'OLD_USER'					=> 'Ancien nom d’utilisateur',
	'OLD_USER_EXPLAIN'			=> 'Permet de saisir le nom d’utilisateur devant être fusionné. Attention, ce membre sera supprimé lors de la fusion.',
	'NEW_USER'					=> 'Nouveau nom d’utilisateur',
	'NEW_USER_EXPLAIN'			=> 'Permet de saisir le nom d’utilisateur dans lequel l’ancien membre doit être fusionné. Ce membre doit avoir été créé.',
	'MERGE_REGDATE'				=> 'Date d’enregistrement de la fusion',
	'MERGE_REGDATE_EXPLAIN'		=> 'Permet de remplacer l’ancienne date d’enregistrement par celle de la fusion.',
	'REGDATE'					=> 'Date d’enregistrement',
));
