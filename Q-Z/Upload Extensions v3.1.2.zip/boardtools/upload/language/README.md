## Language packages
Available language packages and the information about translations can be found here:
https://github.com/BoardTools/upload/wiki/Translations