## Changelog

### 1.0.4 - 2017-03-10

- Added admin_controller.
- Updated listener.
- Update code.
- Changed language files.

### 1.0.3 - 2016-03-20

- Update code.

### 1.0.2 - 2016-03-20

- Update code.

### 1.0.1 - 2014-11-25

- Update code.

### 1.0.0 - 2014-11-25

- First release
