## Language packages
* Arabic - Bassel Taha Alhitary (www.alhitary.net)
* English - original by William Jacoby (bonelifer), maintained by LavIgor
* French - Galixte (http://www.galixte.com)
* German - Philip Gisella
* Hungarian - aszi77
* Polish - FalconTech
* Russian - original by Tatiana5, maintained by LavIgor
* Spanish - Raul Arroyo Monzo
* Swedish - Tage Strandell
* Turkish - Edip Dincer

## Contributing
If you want to help with translations, send a request to join [the localization project on Transifex](https://www.transifex.com/boardtools/quickreply/).
