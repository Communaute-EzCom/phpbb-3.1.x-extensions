<?php
/**
*
* @package Subway Options Panel
* @copyright (c) KomiDesign, 2016
* @license http://www.komidesign.com Private License
*
*/

namespace komidesign\subway_op\controller;

class main
{
  protected $auth;
  protected $config;
  protected $template;
  protected $user;
  protected $helper;
  protected $settings;
  protected $root_path;
  protected $php_ext;
  
  public function __construct(\phpbb\auth\auth $auth, \phpbb\config\config $config, \phpbb\template\template $template, \phpbb\user $user, \phpbb\controller\helper $helper, \komidesign\subway_op\controller\settings $settings, $root_path, $php_ext)
  {
    $this->auth = $auth;
    $this->config = $config;
    $this->template = $template;
    $this->user = $user;
    $this->helper = $helper;
    $this->settings = $settings;
    $this->root_path = $root_path;
    $this->php_ext = $php_ext;    
  }

  public function base()
  {    
    if (!$this->auth->acl_get('a_'))
    {
      return $this->settings->finish('SOP_INVALID_LOGIN', 400, 4, 'sop_home');
    }
    
    $this->sop_settings();    
    return $this->helper->render('subway_op.html', 'Options Panel');
  }

  protected function sop_settings()
  {
     add_form_key('sop_settings');
  }
}