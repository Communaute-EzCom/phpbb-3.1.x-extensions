<?php
/**
*
* @package Subway Options Panel
* @copyright (c) KomiDesign, 2016
* @license http://www.komidesign.com Private License
*
*/

namespace komidesign\subway_op\controller;

class settings
{  
  protected $auth;
  protected $config;
  protected $request;
  protected $user;
  protected $helper;
  
  public function __construct(\phpbb\auth\auth $auth, \phpbb\config\config $config, \phpbb\request\request $request, \phpbb\user $user, \phpbb\controller\helper $helper)
  {
    $this->auth = $auth;
    $this->config = $config;
    $this->request = $request;
    $this->user = $user;
    $this->helper = $helper;
  }
  
  public function manage()
  {    
    if (!$this->auth->acl_get('a_'))
    {
      return $this->finish('SOP_INVALID_LOGIN', 403);
    }

    
    if ( !check_form_key('sop_settings') )
    {
      return $this->finish('SOP_INVALID_FORM', 400);
    }
    
    if( $this->request->is_set_post('submit_logo_op') )
    {
      $this->config->set('sop_logotext',  $this->request->variable('sop_logotext', '',true));
      $this->config->set('sop_logotext_size',  $this->request->variable('sop_logotext_size', '',true));
      $this->config->set('sop_logotext_color_sw',  $this->request->variable('sop_logotext_color_sw', '0'));
      $this->config->set('sop_logotext_color',  $this->request->variable('sop_logotext_color',  '',true));
      $this->config->set('sop_logofont_sw',  $this->request->variable('sop_logofont_sw', '0'));
      $this->config->set('sop_logofont_url',  $this->request->variable('sop_logofont_url', '',true));
      $this->config->set('sop_logofont_fam',  $this->request->variable('sop_logofont_fam', '',true));
      $this->config->set('sop_logofont_weight',  $this->request->variable('sop_logofont_weight', '',true));
      $this->config->set('sop_logoicon',  $this->request->variable('sop_logoicon', '',true));
      $this->config->set('sop_logoicon_size',  $this->request->variable('sop_logoicon_size', '',true));
      $this->config->set('sop_logoicon_color',  $this->request->variable('sop_logoicon_color', '',true));
      $this->config->set('sop_logoimg_url',  $this->request->variable('sop_logoimg_url', '',true));
    }
    
    if( $this->request->is_set_post('submit_general_op') )
    {
      $this->config->set('sop_genfavic',  $this->request->variable('sop_genfavic', '',true));
      $this->config->set('sop_genmeta_sw',  $this->request->variable('sop_genmeta_sw', '0'));
      $this->config->set('sop_genmetakw',  $this->request->variable('sop_genmetakw', '',true));
      $this->config->set('sop_genmetadc',  $this->request->variable('sop_genmetadc', '',true));      
      $this->config->set('sop_genpp_sw',  $this->request->variable('sop_genpp_sw', '0'));
      $this->config->set('sop_gensoc_ic1',  $this->request->variable('sop_gensoc_ic1', '',true));
      $this->config->set('sop_gensoc_ic2',  $this->request->variable('sop_gensoc_ic2', '',true));
      $this->config->set('sop_gensoc_ic3',  $this->request->variable('sop_gensoc_ic3', '',true));
      $this->config->set('sop_gensoc_ic4',  $this->request->variable('sop_gensoc_ic4', '',true));
      $this->config->set('sop_gensoc_ic5',  $this->request->variable('sop_gensoc_ic5', '',true));
      $this->config->set('sop_gensoc_ic6',  $this->request->variable('sop_gensoc_ic6', '',true));
      $this->config->set('sop_gensoc_t1',  $this->request->variable('sop_gensoc_t1', '',true));
      $this->config->set('sop_gensoc_t2',  $this->request->variable('sop_gensoc_t2', '',true));
      $this->config->set('sop_gensoc_t3',  $this->request->variable('sop_gensoc_t3', '',true));
      $this->config->set('sop_gensoc_t4',  $this->request->variable('sop_gensoc_t4', '',true));
      $this->config->set('sop_gensoc_t5',  $this->request->variable('sop_gensoc_t5', '',true));
      $this->config->set('sop_gensoc_t6',  $this->request->variable('sop_gensoc_t6', '',true));
      $this->config->set('sop_gensoc_u1',  $this->request->variable('sop_gensoc_u1', '',true));
      $this->config->set('sop_gensoc_u2',  $this->request->variable('sop_gensoc_u2', '',true));
      $this->config->set('sop_gensoc_u3',  $this->request->variable('sop_gensoc_u3', '',true));
      $this->config->set('sop_gensoc_u4',  $this->request->variable('sop_gensoc_u4', '',true));
      $this->config->set('sop_gensoc_u5',  $this->request->variable('sop_gensoc_u5', '',true));
      $this->config->set('sop_gensoc_u6',  $this->request->variable('sop_gensoc_u6', '',true));
      $this->config->set('sop_genfordesc_sw',  $this->request->variable('sop_genfordesc_sw', '0'));
      $this->config->set('sop_adsbelhd_sw',  $this->request->variable('sop_adsbelhd_sw', '0'));
      $this->config->set('sop_adsabft_sw',  $this->request->variable('sop_adsabft_sw', '0'));
      $this->config->set('sop_adsbel_fstpost_sw',  $this->request->variable('sop_adsbel_fstpost_sw', '0'));
      $this->config->set('sop_adsbel_lstpost_sw',  $this->request->variable('sop_adsbel_lstpost_sw', '0'));
    }
    
    if( $this->request->is_set_post('submit_layout_op') )
    { 
      $this->config->set('sop_lamaxw',  $this->request->variable('sop_lamaxw', '',true));      
      $this->config->set('sop_lah_sw',  $this->request->variable('sop_lah_sw', '0'));
      $this->config->set('sop_laf_sw',  $this->request->variable('sop_laf_sw', '0'));
      $this->config->set('sop_lasv_sw',  $this->request->variable('sop_lasv_sw', '0'));
      $this->config->set('sop_lastbsb_sw',  $this->request->variable('sop_lastbsb_sw', '0'));
      $this->config->set('sop_lascnb_sw',  $this->request->variable('sop_lascnb_sw', '0'));
      $this->config->set('sop_lascn_title',  $this->request->variable('sop_lascn_title', '',true));
      $this->config->set('sop_lascn_date',  $this->request->variable('sop_lascn_date', '',true));
      $this->config->set('sop_lascn_d',  $this->request->variable('sop_lascn_d', '',true)); 
      $this->config->set('sop_lascn_h',  $this->request->variable('sop_lascn_h', '',true)); 
      $this->config->set('sop_lascn_m',  $this->request->variable('sop_lascn_m', '',true));
      $this->config->set('sop_lascn_s',  $this->request->variable('sop_lascn_s', '',true));  
      $this->config->set('sop_last_sw',  $this->request->variable('sop_last_sw', '0'));
      $this->config->set('sop_labox_sw',  $this->request->variable('sop_labox_sw', '0'));
      $this->config->set('sop_loginsb_sw',  $this->request->variable('sop_loginsb_sw', '0'));
      $this->config->set('sop_genrtl_sw',  $this->request->variable('sop_genrtl_sw', '0'));
      $this->config->set('sop_bodyfont_url',  $this->request->variable('sop_bodyfont_url', '',true));
      $this->config->set('sop_bodyfont_fam',  $this->request->variable('sop_bodyfont_fam', '',true));  
    }
    
    if( $this->request->is_set_post('submit_skin_op') )
    {
      $this->config->set('sop_skdark_sw',  $this->request->variable('sop_skdark_sw', '0'));
      $this->config->set('sop_skbg_sw',  $this->request->variable('sop_skbg_sw', '0'));
      $this->config->set('sop_skbgpatt_sw',  $this->request->variable('sop_skbgpatt_sw', '0'));
      $this->config->set('sop_skbody_col',  $this->request->variable('sop_skbody_col', '',true));
      $this->config->set('sop_skbg_col1',  $this->request->variable('sop_skbg_col1', '',true));
      $this->config->set('sop_skbg_col2',  $this->request->variable('sop_skbg_col2', '',true));
      $this->config->set('sop_skbgimg_url',  $this->request->variable('sop_skbgimg_url', '',true));
      $this->config->set('sop_skbgpatt_cus',  $this->request->variable('sop_skbgpatt_cus', '',true));
      $this->config->set('sop_skboxed_bgcol',  $this->request->variable('sop_skboxed_bgcol', '',true));
      $this->config->set('sop_sklfooter_sw',  $this->request->variable('sop_sklfooter_sw', '0'));
      $this->config->set('sop_skbgimgatt_sw',  $this->request->variable('sop_skbgimgatt_sw', '0'));
      $this->config->set('sop_skbgimg_pos',  $this->request->variable('sop_skbgimg_pos', '',true));
      $this->config->set('sop_skcol_link',  $this->request->variable('sop_skcol_link', '',true));
      $this->config->set('sop_skcol_linkhov',  $this->request->variable('sop_skcol_linkhov', '',true));
      $this->config->set('sop_skcol_linkforvis',  $this->request->variable('sop_skcol_linkforvis', '',true));
    }
    
    if( $this->request->is_set_post('submit_fi_op') )
    {
      $this->config->set('sop_fipm',  $this->request->variable('sop_fipm', '',true));
      $this->config->set('sop_fif',  $this->request->variable('sop_fif', '',true));
      $this->config->set('sop_fifl',  $this->request->variable('sop_fifl', '',true));
      $this->config->set('sop_filk',  $this->request->variable('sop_filk', '',true));
      $this->config->set('sop_fian',  $this->request->variable('sop_fian', '',true));
      $this->config->set('sop_figl',  $this->request->variable('sop_figl', '',true));
      $this->config->set('sop_fist',  $this->request->variable('sop_fist', '',true));
      $this->config->set('sop_fitp',  $this->request->variable('sop_fitp', '',true));
      $this->config->set('sop_fitpm',  $this->request->variable('sop_fitpm', '',true));
      $this->config->set('sop_fitph',  $this->request->variable('sop_fitph', '',true));
      $this->config->set('sop_fibr_sw',  $this->request->variable('sop_fibr_sw', '0'));
      $this->config->set('sop_fimg_sw',  $this->request->variable('sop_fimg_sw', '0'));
      $this->config->set('sop_fimg_type_sw',  $this->request->variable('sop_fimg_type_sw', '0'));
      $this->config->set('sop_fimg_poshoz',  $this->request->variable('sop_fimg_poshoz', '',true));
      $this->config->set('sop_fimg_posver',  $this->request->variable('sop_fimg_posver', '',true));
      $this->config->set('sop_tlittic_poshoz',  $this->request->variable('sop_tlittic_poshoz', '',true));
      $this->config->set('sop_tlittic_posver',  $this->request->variable('sop_tlittic_posver', '',true));
    }
    
    if( $this->request->is_set_post('submit_sl_op') )
    {      
      $this->config->set('sop_sl_sw',  $this->request->variable('sop_sl_sw', '0'));
      $this->config->set('sop_sl_mfx',  $this->request->variable('sop_sl_mfx', '0'));
      $this->config->set('sop_sl_slc',  max(1, $this->request->variable('sop_sl_slc', 0)));
      $this->config->set('sop_sl_bxc',  max(1, $this->request->variable('sop_sl_bxc', 0)));
      $this->config->set('sop_sl_bxr',  max(1, $this->request->variable('sop_sl_bxr', 0)));
      $this->config->set('sop_sl_aspd',  max(1, $this->request->variable('sop_sl_aspd', 0)));
      $this->config->set('sop_sl_ptm',  max(1, $this->request->variable('sop_sl_ptm', 0)));
      $this->config->set('sop_sl_dnv_sw',  $this->request->variable('sop_sl_dnv_sw', '0'));
      $this->config->set('sop_sl_cnv_sw',  $this->request->variable('sop_sl_cnv_sw', '0'));
      $this->config->set('sop_sl_poh_sw',  $this->request->variable('sop_sl_poh_sw', '0'));      
      $this->config->set('sop_sl1_img',  $this->request->variable('sop_sl1_img', '',true));
      $this->config->set('sop_sl1_url',  $this->request->variable('sop_sl1_url', '',true));
      $this->config->set('sop_sl1_cap',  $this->request->variable('sop_sl1_cap', '',true));
      $this->config->set('sop_sl2_img',  $this->request->variable('sop_sl2_img', '',true));
      $this->config->set('sop_sl2_url',  $this->request->variable('sop_sl2_url', '',true));
      $this->config->set('sop_sl2_cap',  $this->request->variable('sop_sl2_cap', '',true));
      $this->config->set('sop_sl3_img',  $this->request->variable('sop_sl3_img', '',true));
      $this->config->set('sop_sl3_url',  $this->request->variable('sop_sl3_url', '',true));
      $this->config->set('sop_sl3_cap',  $this->request->variable('sop_sl3_cap', '',true));
      $this->config->set('sop_sl4_img',  $this->request->variable('sop_sl4_img', '',true));
      $this->config->set('sop_sl4_url',  $this->request->variable('sop_sl4_url', '',true));
      $this->config->set('sop_sl4_cap',  $this->request->variable('sop_sl4_cap', '',true));
      $this->config->set('sop_sl5_img',  $this->request->variable('sop_sl5_img', '',true));
      $this->config->set('sop_sl5_url',  $this->request->variable('sop_sl5_url', '',true));
      $this->config->set('sop_sl5_cap',  $this->request->variable('sop_sl5_cap', '',true));
      $this->config->set('sop_sl6_img',  $this->request->variable('sop_sl6_img', '',true));
      $this->config->set('sop_sl6_url',  $this->request->variable('sop_sl6_url', '',true));
      $this->config->set('sop_sl6_cap',  $this->request->variable('sop_sl6_cap', '',true));
      $this->config->set('sop_sl7_img',  $this->request->variable('sop_sl7_img', '',true));
      $this->config->set('sop_sl7_url',  $this->request->variable('sop_sl7_url', '',true));
      $this->config->set('sop_sl7_cap',  $this->request->variable('sop_sl7_cap', '',true));
      $this->config->set('sop_sl8_img',  $this->request->variable('sop_sl8_img', '',true));
      $this->config->set('sop_sl8_url',  $this->request->variable('sop_sl8_url', '',true));
      $this->config->set('sop_sl8_cap',  $this->request->variable('sop_sl8_cap', '',true));

    }

    return $this->finish('SOP_SETTINGS_SAVED', 200, 3);
  }
  
  public function finish($message, $status_code, $redirect_time = 10, $route = 'sop_controller')
  {
    $this->meta_refresh($redirect_time, $route);
    return $this->helper->error($this->user->lang($message), $status_code);
  }
  
  public function meta_refresh($redirect_time, $route)
  {
    meta_refresh($redirect_time, $this->helper->route($route));
  }
}
