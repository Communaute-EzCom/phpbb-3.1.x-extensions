$('#header-image').click(function(e) {
    e.preventDefault();
});