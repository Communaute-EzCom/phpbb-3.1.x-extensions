welcomerobot
============

This extention create new topic when someone register in board and signs in. this can be a welcome message topic or anything that make new user active and responsive.
