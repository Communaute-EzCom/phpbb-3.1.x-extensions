<?php
/**
*
* @package Subway Options Panel
* @copyright (c) KomiDesign, 2014
* @license http://www.komidesign.com Private License
*
*/

namespace komidesign\subway_op\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

class main_listener implements EventSubscriberInterface
{
  /* @var \phpbb\config\config */
  protected $config;

  /* @var \phpbb\template\template */
  protected $template;

  /* @var \phpbb\user */
  protected $user;

  /* @var \phpbb\controller\helper */
  protected $helper;


  static public function getSubscribedEvents()
  {
    return array(
       'core.user_setup'   => 'add_sop_language_vars',
       'core.page_header'  => 'add_sop_template_vars',
    );
  }

  /**
   * Constructor
   *
   * @param \phpbb\config\config      $this->config    Config object
   * @param \phpbb\controller\helper  $helper    Helper object
   * @param \phpbb\template\template  $template  Template object
   * @param \phpbb\user               $user      User object
   */
  public function __construct(\phpbb\config\config $config, \phpbb\template\template $template, \phpbb\user $user, \phpbb\controller\helper $helper)
  {
    $this->config = $config;
    $this->template = $template;
    $this->user = $user;
    $this->helper = $helper;
  }

  public function add_sop_language_vars($event)
  {
    $lang_set_ext = $event['lang_set_ext'];
    $lang_set_ext[] = array(
      'ext_name' => 'komidesign/subway_op',
      'lang_set' => 'subway_op',
    );
    $event['lang_set_ext'] = $lang_set_ext;
  }

  public function add_sop_template_vars($event)
  {
    $this->template->assign_vars(array(
      // OP 
      'SOP_VERSION'             => (bool) $this->config['sop_version'],
      'U_SOP_URL'               => $this->helper->route('sop_controller'),
      // Logo Options    
      'SOP_LOGOTEXT'            => (string) $this->config['sop_logotext'],
      'SOP_LOGOTEXT_SIZE'       => (string) $this->config['sop_logotext_size'],
      'SOP_LOGOTEXT_COLOR_SW'   => (bool) $this->config['sop_logotext_color_sw'],
      'SOP_LOGOTEXT_COLOR'      => (string) $this->config['sop_logotext_color'],       
      'SOP_LOGOFONT_SW'         => (bool) $this->config['sop_logofont_sw'],
      'SOP_LOGOFONT_URL'        => (string) $this->config['sop_logofont_url'],
      'SOP_LOGOFONT_FAM'        => (string) $this->config['sop_logofont_fam'],
      'SOP_LOGOFONT_WEIGHT'     => (string) $this->config['sop_logofont_weight'],
      'SOP_LOGOICON'            => (string) $this->config['sop_logoicon'],
      'SOP_LOGOICON_SIZE'       => (string) $this->config['sop_logoicon_size'],
      'SOP_LOGOICON_COLOR'      => (string) $this->config['sop_logoicon_color'],
      'SOP_LOGOIMG_URL'         => (string) $this->config['sop_logoimg_url'],
      // General Options 
      'SOP_GENFAVIC'            => (string) $this->config['sop_genfavic'],
      'SOP_GENMETA_SW'          => (bool) $this->config['sop_genmeta_sw'],
      'SOP_GENMETAKW'           => (string) $this->config['sop_genmetakw'],
      'SOP_GENMETADC'           => (string) $this->config['sop_genmetadc'],           
      'SOP_GENRTL_SW'           => (bool) $this->config['sop_genrtl_sw'],
      'SOP_GENPP_SW'            => (bool) $this->config['sop_genpp_sw'],
      'SOP_GENSOC_IC1'          => (string) $this->config['sop_gensoc_ic1'],
      'SOP_GENSOC_IC2'          => (string) $this->config['sop_gensoc_ic2'],
      'SOP_GENSOC_IC3'          => (string) $this->config['sop_gensoc_ic3'],
      'SOP_GENSOC_IC4'          => (string) $this->config['sop_gensoc_ic4'],
      'SOP_GENSOC_IC5'          => (string) $this->config['sop_gensoc_ic5'],
      'SOP_GENSOC_IC6'          => (string) $this->config['sop_gensoc_ic6'],
      'SOP_GENSOC_T1'           => (string) $this->config['sop_gensoc_t1'],
      'SOP_GENSOC_T2'           => (string) $this->config['sop_gensoc_t2'],
      'SOP_GENSOC_T3'           => (string) $this->config['sop_gensoc_t3'],
      'SOP_GENSOC_T4'           => (string) $this->config['sop_gensoc_t4'],
      'SOP_GENSOC_T5'           => (string) $this->config['sop_gensoc_t5'],
      'SOP_GENSOC_T6'           => (string) $this->config['sop_gensoc_t6'],
      'SOP_GENSOC_U1'           => (string) $this->config['sop_gensoc_u1'],
      'SOP_GENSOC_U2'           => (string) $this->config['sop_gensoc_u2'],
      'SOP_GENSOC_U3'           => (string) $this->config['sop_gensoc_u3'],
      'SOP_GENSOC_U4'           => (string) $this->config['sop_gensoc_u4'],
      'SOP_GENSOC_U5'           => (string) $this->config['sop_gensoc_u5'],
      'SOP_GENSOC_U6'           => (string) $this->config['sop_gensoc_u6'],
      'SOP_GENFORDESC_SW'       => (bool) $this->config['sop_genfordesc_sw'],       
      // Layout Options 
      'SOP_LAMAXW'              => (string) $this->config['sop_lamaxw'],     
      'SOP_LAH_SW'              => (string) $this->config['sop_lah_sw'],
      'SOP_LAF_SW'              => (bool) $this->config['sop_laf_sw'],
      'SOP_LASV_SW'             => (string) $this->config['sop_lasv_sw'],  
      'SOP_LASTBSB_SW'          => (bool) $this->config['sop_lastbsb_sw'],        
      'SOP_LASCNB_SW'           => (bool) $this->config['sop_lascnb_sw'],
      'SOP_LASCN_TITLE'         => (string) $this->config['sop_lascn_title'],
      'SOP_LASCN_DATE'          => (string) $this->config['sop_lascn_date'],
      'SOP_LASCN_D'             => (string) $this->config['sop_lascn_d'],
      'SOP_LASCN_H'             => (string) $this->config['sop_lascn_h'],
      'SOP_LASCN_M'             => (string) $this->config['sop_lascn_m'], 
      'SOP_LASCN_S'             => (string) $this->config['sop_lascn_s'],         
      'SOP_LAST_SW'             => (bool) $this->config['sop_last_sw'],
      'SOP_LABOX_SW'            => (bool) $this->config['sop_labox_sw'],
      'SOP_LOGINSB_SW'          => (bool) $this->config['sop_loginsb_sw'],
      'SOP_BODYFONT_URL'        => (string) $this->config['sop_bodyfont_url'],
      'SOP_BODYFONT_FAM'        => (string) $this->config['sop_bodyfont_fam'],      
      // Skin Options 
      'SOP_SKDARK_SW'           => (bool) $this->config['sop_skdark_sw'],
      'SOP_SKBG_SW'             => (bool) $this->config['sop_skbg_sw'],
      'SOP_SKBGPATT_SW'         => (string) $this->config['sop_skbgpatt_sw'],
      'SOP_SKBODY_COL'          => (string) $this->config['sop_skbody_col'],
      'SOP_SKBG_COL1'           => (string) $this->config['sop_skbg_col1'],
      'SOP_SKBG_COL2'           => (string) $this->config['sop_skbg_col2'],
      'SOP_SKBGIMG_URL'         => (string) $this->config['sop_skbgimg_url'],
      'SOP_SKBGPATT_CUS'        => (string) $this->config['sop_skbgpatt_cus'],
      'SOP_SKBOXED_BGCOL'       => (string) $this->config['sop_skboxed_bgcol'],
      'SOP_SKLFOOTER_SW'        => (bool) $this->config['sop_sklfooter_sw'],
      'SOP_SKBGIMGATT_SW'       => (bool) $this->config['sop_skbgimgatt_sw'],
      'SOP_SKBGIMG_POS'         => (string) $this->config['sop_skbgimg_pos'],
      'SOP_ADSBELHD_SW'         => (bool) $this->config['sop_adsbelhd_sw'],
      'SOP_ADSABFT_SW'          => (bool) $this->config['sop_adsabft_sw'],
      'SOP_ADSBEL_FSTPOST_SW'   => (bool) $this->config['sop_adsbel_fstpost_sw'],
      'SOP_ADSBEL_LSTPOST_SW'   => (bool) $this->config['sop_adsbel_lstpost_sw'],

      'SOP_SKCOL_LINK'          => (string) $this->config['sop_skcol_link'],
      'SOP_SKCOL_LINKHOV'       => (string) $this->config['sop_skcol_linkhov'],
      'SOP_SKCOL_LINKFORVIS'    => (string) $this->config['sop_skcol_linkforvis'],
      // Forum Icons 
      'SOP_FIPM'                => (string) $this->config['sop_fipm'],
      'SOP_FIF'                 => (string) $this->config['sop_fif'],
      'SOP_FIFL'                => (string) $this->config['sop_fifl'],
      'SOP_FILK'                => (string) $this->config['sop_filk'],
      'SOP_FIAN'                => (string) $this->config['sop_fian'],
      'SOP_FIGL'                => (string) $this->config['sop_figl'],
      'SOP_FIST'                => (string) $this->config['sop_fist'],
      'SOP_FITP'                => (string) $this->config['sop_fitp'],
      'SOP_FITPM'               => (string) $this->config['sop_fitpm'],
      'SOP_FITPH'               => (string) $this->config['sop_fitph'],
      'SOP_FIBR_SW'             => (bool) $this->config['sop_fibr_sw'],
      'SOP_FIMG_SW'             => (bool) $this->config['sop_fimg_sw'],
      'SOP_FIMG_TYPE_SW'        => (string) $this->config['sop_fimg_type_sw'],
      'SOP_FIMG_POSHOZ'         => (string) $this->config['sop_fimg_poshoz'],
      'SOP_FIMG_POSVER'         => (string) $this->config['sop_fimg_posver'],
      'SOP_TLITTIC_POSHOZ'      => (string) $this->config['sop_tlittic_poshoz'],
      'SOP_TLITTIC_POSVER'      => (string) $this->config['sop_tlittic_posver'],
      // Slider 
      'SOP_SL_SW'               => (string) $this->config['sop_sl_sw'],
      'SOP_SL_MFX'              => (string) $this->config['sop_sl_mfx'],
      'SOP_SL_SLC'              => (int) $this->config['sop_sl_slc'],
      'SOP_SL_BXC'              => (int) $this->config['sop_sl_bxc'],
      'SOP_SL_BXR'              => (int) $this->config['sop_sl_bxr'],
      'SOP_SL_ASPD'             => (int) $this->config['sop_sl_aspd'],
      'SOP_SL_PTM'              => (int) $this->config['sop_sl_ptm'],
      'SOP_SL_DNV_SW'           => (bool) $this->config['sop_sl_dnv_sw'],
      'SOP_SL_CNV_SW'           => (bool) $this->config['sop_sl_cnv_sw'],
      'SOP_SL_POH_SW'           => (bool) $this->config['sop_sl_poh_sw'],
      'SOP_SL1_IMG'             => (string) $this->config['sop_sl1_img'],
      'SOP_SL1_URL'             => (string) $this->config['sop_sl1_url'],
      'SOP_SL1_CAP'             => (string) $this->config['sop_sl1_cap'],
      'SOP_SL2_IMG'             => (string) $this->config['sop_sl2_img'],
      'SOP_SL2_URL'             => (string) $this->config['sop_sl2_url'],
      'SOP_SL2_CAP'             => (string) $this->config['sop_sl2_cap'],
      'SOP_SL3_IMG'             => (string) $this->config['sop_sl3_img'],
      'SOP_SL3_URL'             => (string) $this->config['sop_sl3_url'],
      'SOP_SL3_CAP'             => (string) $this->config['sop_sl3_cap'],
      'SOP_SL4_IMG'             => (string) $this->config['sop_sl4_img'],
      'SOP_SL4_URL'             => (string) $this->config['sop_sl4_url'],
      'SOP_SL4_CAP'             => (string) $this->config['sop_sl4_cap'],
      'SOP_SL5_IMG'             => (string) $this->config['sop_sl5_img'],
      'SOP_SL5_URL'             => (string) $this->config['sop_sl5_url'],
      'SOP_SL5_CAP'             => (string) $this->config['sop_sl5_cap'],
      'SOP_SL6_IMG'             => (string) $this->config['sop_sl6_img'],
      'SOP_SL6_URL'             => (string) $this->config['sop_sl6_url'],
      'SOP_SL6_CAP'             => (string) $this->config['sop_sl6_cap'],
      'SOP_SL7_IMG'             => (string) $this->config['sop_sl7_img'],
      'SOP_SL7_URL'             => (string) $this->config['sop_sl7_url'],
      'SOP_SL7_CAP'             => (string) $this->config['sop_sl7_cap'],
      'SOP_SL8_IMG'             => (string) $this->config['sop_sl8_img'],
      'SOP_SL8_URL'             => (string) $this->config['sop_sl8_url'],
      'SOP_SL8_CAP'             => (string) $this->config['sop_sl8_cap'],      
    ));
  }
}