<?php
/**
*
* @package Subway Options Panel
* @copyright (c) KomiDesign, 2014
* @license http://www.komidesign.com Private License
*
*/

namespace komidesign\subway_op\controller;

class main
{
  /* @var \phpbb\auth\auth */
    protected $auth;

  /* @var \phpbb\config\config */
  protected $config;

  /* @var \phpbb\template\template */
  protected $template;

  /* @var \phpbb\user */
  protected $user;

  /* @var \phpbb\controller\helper */
  protected $helper;

  /* @var \komidesign\subway_op\controller\settings */
  protected $settings;

  /* @var string phpBB root path */
  protected $root_path;

  /* @var string phpEx */
  protected $php_ext;

  /**
  * Constructor
  * NOTE: The parameters of this method must match in order and type with
  * the dependencies defined in the services.yml file for this service.
  *
  * @param \phpbb\auth\auth                          $auth       Auth object
  * @param \phpbb\config                             $config     Config object
  * @param \phpbb\template                           $template   Template object
  * @param \phpbb\user                               $user       User object
  * @param \phpbb\controller\helper                  $helper     Controller helper object
  * @param \komidesign\subway_op\controller\settings  $settings   Settings object
  * @param string                                    $root_path  phpBB root path
  * @param string                                    $php_ext    phpEx  
  */
  public function __construct(\phpbb\auth\auth $auth, \phpbb\config\config $config, \phpbb\template\template $template, \phpbb\user $user, \phpbb\controller\helper $helper, \komidesign\subway_op\controller\settings $settings, $root_path, $php_ext)
  {
    $this->auth = $auth;
    $this->config = $config;
    $this->template = $template;
    $this->user = $user;
    $this->helper = $helper;
    $this->settings = $settings;
    $this->root_path = $root_path;
    $this->php_ext = $php_ext;    
  }

  /**
  * Base controller to be accessed with the URL /subway-options-panel
  *
  * @return Symfony\Component\HttpFoundation\Response A Symfony Response object
  */
  public function base()
  {
    // Redirect non admins back to the index page
    if (!$this->auth->acl_get('a_'))
    {
      return $this->settings->finish('SOP_INVALID_LOGIN', 400, 4, 'sop_home');
    }

    // Form key validation
    $this->sop_settings();


    /**
    * The render method takes up to three other arguments
    * @param   string      Name of the template file to display
    *                      Template files are searched for two places:
    *                      - phpBB/styles/<style_name>/template/
    *                      - phpBB/ext/<all_active_extensions>/styles/<style_name>/template/
    * @param   string      Page title
    * @param   int         Status code of the page (200 - OK [ default ], 403 - Unauthorized, 404 - Page not found, etc.)
    */
    return $this->helper->render('subway_op.html', 'Options Panel');
  }

  protected function sop_settings()
  {
     add_form_key('sop_settings');
  }
}