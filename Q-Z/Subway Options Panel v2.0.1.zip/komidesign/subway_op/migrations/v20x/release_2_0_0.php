<?php
/**
*
* @package Subway Options Panel
* @copyright (c) KomiDesign, 2014
* @license http://www.komidesign.com Private License
*
*/

namespace komidesign\subway_op\migrations\v20x;

class release_2_0_0 extends \phpbb\db\migration\migration
{
  public function effectively_installed()
  {
    return version_compare($this->config['sop_version'], '2.0.0', '>=');
  }

  static public function depends_on()
  {
    return array('\komidesign\subway_op\migrations\v10x\release_1_0_4');
  }

  public function update_data()
  {
    return array(          
      // Skin Options 
      array('config.add', array('sop_skcol_link', '')),
      array('config.add', array('sop_skcol_linkhov', '')),
      array('config.add', array('sop_skcol_linkforvis', '')),
      array('config.add', array('sop_bodyfont_url', '')),
      array('config.add', array('sop_bodyfont_fam', '')),
      array('config.remove', array('sop_logoimg_sw', '')),
      // SOP Version 
      array('config.update', array('sop_version', '2.0.0')),
    );
  }
}