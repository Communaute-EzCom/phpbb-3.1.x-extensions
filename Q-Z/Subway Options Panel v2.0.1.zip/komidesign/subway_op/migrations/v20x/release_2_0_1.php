<?php
/**
*
* @package Subway Options Panel
* @copyright (c) KomiDesign, 2014
* @license http://www.komidesign.com Private License
*
*/

namespace komidesign\subway_op\migrations\v20x;

class release_2_0_1 extends \phpbb\db\migration\migration
{
  public function effectively_installed()
  {
    return version_compare($this->config['sop_version'], '2.0.1', '>=');
  }

  static public function depends_on()
  {
    return array('\komidesign\subway_op\migrations\v20x\release_2_0_0');
  }

  public function update_data()
  {
    return array(          
      // Logo Options
      array('config.update', array('sop_logotext', 'Subway')),
      array('config.update', array('sop_logoicon', 'icon-thunder')),
      // SOP Version 
      array('config.update', array('sop_version', '2.0.1')),
    );
  }
}