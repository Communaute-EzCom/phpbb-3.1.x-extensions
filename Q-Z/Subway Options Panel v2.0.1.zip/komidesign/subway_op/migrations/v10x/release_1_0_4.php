<?php
/**
*
* @package Subway Options Panel
* @copyright (c) KomiDesign, 2014
* @license http://www.komidesign.com Private License
*
*/

namespace komidesign\subway_op\migrations\v10x;

class release_1_0_4 extends \phpbb\db\migration\migration
{
  public function effectively_installed()
  {
    return version_compare($this->config['sop_version'], '1.0.4', '>=');
  }

  static public function depends_on()
  {
    return array('\komidesign\subway_op\migrations\v10x\release_1_0_3');
  }

  public function update_data()
  {
    return array(
      // Layout Options 
      array('config.add', array('sop_loginsb_sw', '')),   
      // General Options 
      array('config.add', array('sop_genfordesc_sw', '')),      
      // Skin Options 
      array('config.add', array('sop_skbgimgatt_sw', '')),
      array('config.add', array('sop_skbgimg_pos', '')),
      // Forum Icons 
      array('config.add', array('sop_fimg_sw', '')),
      array('config.add', array('sop_fimg_type_sw', '')),
      array('config.add', array('sop_fimg_poshoz', '')),
      array('config.add', array('sop_fimg_posver', '')),
      array('config.add', array('sop_tlittic_poshoz', '')),
      array('config.add', array('sop_tlittic_posver', '')),
      // SOP Slider 
      array('config.add', array('sop_sl_sw', '')),
      array('config.add', array('sop_sl_mfx', 'random')),
      array('config.add', array('sop_sl_slc', '15')),
      array('config.add', array('sop_sl_bxc', '8')),
      array('config.add', array('sop_sl_bxr', '4')),
      array('config.add', array('sop_sl_aspd', '500')),
      array('config.add', array('sop_sl_ptm', '3000')),
      array('config.add', array('sop_sl_dnv_sw', '1')),
      array('config.add', array('sop_sl_cnv_sw', '1')),
      array('config.add', array('sop_sl_poh_sw', '1')),
      array('config.add', array('sop_sl1_img', '1.png')),
      array('config.add', array('sop_sl1_url', '')),
      array('config.add', array('sop_sl1_cap', 'Caption text example')),
      array('config.add', array('sop_sl2_img', '2.png')),
      array('config.add', array('sop_sl2_url', '')),
      array('config.add', array('sop_sl2_cap', '')),
      array('config.add', array('sop_sl3_img', '')),
      array('config.add', array('sop_sl3_url', '')),
      array('config.add', array('sop_sl3_cap', '')),
      array('config.add', array('sop_sl4_img', '')),
      array('config.add', array('sop_sl4_url', '')),
      array('config.add', array('sop_sl4_cap', '')),
      array('config.add', array('sop_sl5_img', '')),
      array('config.add', array('sop_sl5_url', '')),
      array('config.add', array('sop_sl5_cap', '')),
      array('config.add', array('sop_sl6_img', '')),
      array('config.add', array('sop_sl6_url', '')),
      array('config.add', array('sop_sl6_cap', '')),
      array('config.add', array('sop_sl7_img', '')),
      array('config.add', array('sop_sl7_url', '')),
      array('config.add', array('sop_sl7_cap', '')),
      array('config.add', array('sop_sl8_img', '')),
      array('config.add', array('sop_sl8_url', '')),
      array('config.add', array('sop_sl8_cap', '')),
      // SOP Version 
      array('config.update', array('sop_version', '1.0.4')),
    );
  }
}