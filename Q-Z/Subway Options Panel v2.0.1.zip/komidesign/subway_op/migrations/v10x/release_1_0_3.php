<?php
/**
*
* @package Subway Options Panel
* @copyright (c) KomiDesign, 2014
* @license http://www.komidesign.com Private License
*
*/

namespace komidesign\subway_op\migrations\v10x;

class release_1_0_3 extends \phpbb\db\migration\migration
{
  public function effectively_installed()
  {
    return version_compare($this->config['sop_version'], '1.0.3', '>=');
  }

  static public function depends_on()
  {
    return array('\komidesign\subway_op\migrations\v10x\release_1_0_2');
  }

  public function update_data()
  {
    return array(
      array('config.add', array('sop_sklfooter_sw', '')),
      // SOP Version 
      array('config.update', array('sop_version', '1.0.3')),
    );
  }
}