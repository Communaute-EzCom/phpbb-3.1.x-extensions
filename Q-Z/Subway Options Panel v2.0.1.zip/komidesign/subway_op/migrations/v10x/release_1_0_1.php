<?php
/**
*
* @package Subway Options Panel
* @copyright (c) KomiDesign, 2014
* @license http://www.komidesign.com Private License
*
*/

namespace komidesign\subway_op\migrations\v10x;

class release_1_0_1 extends \phpbb\db\migration\migration
{
  public function effectively_installed()
  {
    return version_compare($this->config['sop_version'], '1.0.1', '>=');
  }

  static public function depends_on()
  {
    return array('\komidesign\subway_op\migrations\v10x\release_1_0_0');
  }

  public function update_data()
  {
    return array(
      // General Options 
      array('config.add', array('sop_gensoc_ic1', '')),
      array('config.add', array('sop_gensoc_ic2', '')),
      array('config.add', array('sop_gensoc_ic3', '')),
      array('config.add', array('sop_gensoc_ic4', '')),
      array('config.add', array('sop_gensoc_ic5', '')),
      array('config.add', array('sop_gensoc_ic6', '')),
      array('config.add', array('sop_gensoc_t1', '')),
      array('config.add', array('sop_gensoc_t2', '')),
      array('config.add', array('sop_gensoc_t3', '')),
      array('config.add', array('sop_gensoc_t4', '')),
      array('config.add', array('sop_gensoc_t5', '')),
      array('config.add', array('sop_gensoc_t6', '')),
      array('config.add', array('sop_gensoc_u1', '')),
      array('config.add', array('sop_gensoc_u2', '')),
      array('config.add', array('sop_gensoc_u3', '')),
      array('config.add', array('sop_gensoc_u4', '')),
      array('config.add', array('sop_gensoc_u5', '')),
      array('config.add', array('sop_gensoc_u6', '')),
      // Layout Options 
      array('config.add', array('sop_labox_sw', '')),
      // Skin Options 
      array('config.add', array('sop_skdark_sw', '')),
      array('config.add', array('sop_skbgpatt_sw', '')),
      array('config.add', array('sop_skbgimg_url', '')),
      array('config.add', array('sop_skbgpatt_cus', '')),
      array('config.add', array('sop_skboxed_bgcol', '')),
      array('config.add', array('sop_adsbelhd_sw', '')),
      array('config.add', array('sop_adsabft_sw', '')),
      array('config.add', array('sop_adsbel_fstpost_sw', '')),
      array('config.add', array('sop_adsbel_lstpost_sw', '')),
      // SOP Version 
      array('config.update', array('sop_version', '1.0.1')),
    );
  }
}