<?php
/**
*
* @package Subway Options Panel
* @copyright (c) KomiDesign, 2014
* @license http://www.komidesign.com Private License
*
*/

namespace komidesign\subway_op\migrations\v10x;

class release_1_0_0 extends \phpbb\db\migration\migration
{
  public function effectively_installed()
  {
    return isset($this->config['sop_version']) && version_compare($this->config['sop_version'], '1.0.0', '>=');
  }

  static public function depends_on()
  {
    return array('\phpbb\db\migration\data\v310\dev');
  }

  public function update_data()
  {
    return array(
      // OP Version
      array('config.add', array('sop_version', '1.0.0')),
      // Logo Options
      array('config.add', array('sop_logotext', '')),
      array('config.add', array('sop_logotext_size', '')),
      array('config.add', array('sop_logotext_color_sw', '')),
      array('config.add', array('sop_logotext_color', '')),
      array('config.add', array('sop_logofont_sw', '')),
      array('config.add', array('sop_logofont_url', '')),
      array('config.add', array('sop_logofont_fam', '')),
      array('config.add', array('sop_logofont_weight', '')),
      array('config.add', array('sop_logoicon', '')),
      array('config.add', array('sop_logoicon_size', '')),
      array('config.add', array('sop_logoicon_color', '')),
      array('config.add', array('sop_logoimg_sw', '')),
      array('config.add', array('sop_logoimg_url', '')),
      // General Options 
      array('config.add', array('sop_genfavic', '')),
      array('config.add', array('sop_genmeta_sw', '')),
      array('config.add', array('sop_genmetakw', '')),
      array('config.add', array('sop_genmetadc', '')),
      array('config.add', array('sop_genrtl_sw', '')),
      array('config.add', array('sop_genpp_sw', '')),
      // Layout Options      
      array('config.add', array('sop_lamaxw', '')),
      array('config.add', array('sop_lah_sw', '')),
      array('config.add', array('sop_laf_sw', '')),
      array('config.add', array('sop_lasv_sw', '1')),
      array('config.add', array('sop_lastbsb_sw', '')),
      array('config.add', array('sop_lascnb_sw', '')),
      array('config.add', array('sop_lascn_title', 'Your Countdown Title')),
      array('config.add', array('sop_lascn_date', '2015/12/22')),
      array('config.add', array('sop_lascn_d', 'days')),
      array('config.add', array('sop_lascn_h', 'hours')),
      array('config.add', array('sop_lascn_m', 'min')),
      array('config.add', array('sop_lascn_s', 'sec')),
      array('config.add', array('sop_last_sw', '')),
      // Skin Options 
      array('config.add', array('sop_skbg_sw', '')),
      array('config.add', array('sop_skbody_col', '')),
      array('config.add', array('sop_skbg_col1', '')),
      array('config.add', array('sop_skbg_col2', '')),
    );
  }
}
