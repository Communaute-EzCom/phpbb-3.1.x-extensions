<?php
/**
*
* @package Subway Options Panel
* @copyright (c) KomiDesign, 2014
* @license http://www.komidesign.com Private License
*
*/

namespace komidesign\subway_op\migrations\v10x;

class release_1_0_2 extends \phpbb\db\migration\migration
{
  public function effectively_installed()
  {
    return version_compare($this->config['sop_version'], '1.0.2', '>=');
  }

  static public function depends_on()
  {
    return array('\komidesign\subway_op\migrations\v10x\release_1_0_1');
  }

  public function update_data()
  {
    return array(
      // Forum Icons 
      array('config.add', array('sop_fipm', '')),
      array('config.add', array('sop_fif', '')),
      array('config.add', array('sop_fifl', '')),
      array('config.add', array('sop_filk', '')),
      array('config.add', array('sop_fian', '')),
      array('config.add', array('sop_figl', '')),
      array('config.add', array('sop_fist', '')),
      array('config.add', array('sop_fitp', '')),
      array('config.add', array('sop_fitpm', '')),
      array('config.add', array('sop_fitph', '')),
      array('config.add', array('sop_fibr_sw', '')),
      // SOP Version 
      array('config.update', array('sop_version', '1.0.2')),
    );
  }
}