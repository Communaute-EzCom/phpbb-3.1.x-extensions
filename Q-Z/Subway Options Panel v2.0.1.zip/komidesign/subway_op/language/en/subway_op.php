<?php

/**
*
* subway_op [British English]
*
* @package Subway Options Panel
* @version $Id$
* @copyright (c) KomiDesign, 2014
* @license http://www.komidesign.com Private License
*
*/

if (!defined('IN_PHPBB'))
{
  exit;
}
if (empty($lang) || !is_array($lang))
{
  $lang = array();
}

$lang = array_merge($lang, array(  
  'SOP_TITLE'  => 'Theme Options Panel',
  'SOP_SETTINGS_SAVED'  => 'The settings have been saved successfully.',
  'SOP_INVALID_LOGIN'  => 'Sorry..<br>You must be logged in as Administrator to access the Options Panel.',
  'SOP_INVALID_FORM'  => 'Invalid form data.',  
));
