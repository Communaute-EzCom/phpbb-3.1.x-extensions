# Time to Read

## Installation

Copy the extension to phpBB/ext/senky/timetoread

Go to "ACP" > "Customise" > "Extensions" and enable the "Time to Read" extension.

## License

[GPLv2](license.txt)
