//==========================================
// Welcome Guest Popup
//==========================================
var cookieid = "phpbb3_";
var welcomeBoxWidth = 320,
	welcomeBoxHeight = 160;

/**
 * Get cookie
 */
function my_getcookie(name) {
	cname = cookieid + name + "=";
	cpos = document.cookie.indexOf(cname);

	if (cpos != -1) {
		cstart = cpos + cname.length;
		cend = document.cookie.indexOf(';', cstart);

		if (cend == -1) {
			cend = document.cookie.length;
		}

		return unescape(document.cookie.substring(cstart, cend));
	}

	return null;
}

/**
 * Set cookie
 */
function my_setcookie(name, value, days) {
	if (days) {
		var date = new Date();
		date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
		var expires = "; expires=" + date.toUTCString();
	}
	else var expires = "";

	document.cookie = cookieid + name + "=" + value + expires + "; path=/";
}

/**
 * Display Welcome Box
 */
$(function() {
	if (my_getcookie('welcome') != '1' && $('#welcome-box').length > 0) {
		welcomeBoxTop = Math.round(($(window).height() - welcomeBoxHeight - 16) / 3);

		$('#welcome-box').css({
			top: welcomeBoxTop + 'px',
			minWidth: welcomeBoxWidth + 'px',
			minHeight: welcomeBoxHeight + 'px'
		});

		$('#welcome-box').fadeIn('fast');
		$('#welcome-bgd').css('display', 'block');

		$('#welcome_close').click(function() {
			my_setcookie('welcome', '1', '7');
			$('#welcome-box').fadeOut('normal');
			$('#welcome-bgd').css('display', 'none');
			return false;
		});
	}
});