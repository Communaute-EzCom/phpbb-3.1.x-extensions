# Sticky navigation bar

Makes the top navigation bar sticky in prosilver.
Adds the search box to the sticky navigation bar.
Adds a site mini logo to the navigation bar.

Initial work by javiexin.
Full extension development by HiFiKabin.

## Installation

Copy the extension to phpBB/ext/hifikabin/stickybar

Go to "ACP" > "Customise" > "Extensions" and enable the "Sticky navigation bar" extension.

## License

[GPLv2](license.txt)
