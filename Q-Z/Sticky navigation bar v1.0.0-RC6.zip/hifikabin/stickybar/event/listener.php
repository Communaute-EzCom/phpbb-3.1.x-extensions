<?php
/**
*
* @package phpBB Extension - Sticky Bar
* @copyright (c) 2017 HiFiKabin
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

namespace hifikabin\stickybar\event;

use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
* Event listener
*/

class listener implements EventSubscriberInterface
{
	protected $ext_manager;

	protected $path_helper;

	protected $user;

	protected $template;

	public function __construct(\phpbb\extension\manager $ext_manager, \phpbb\path_helper $path_helper, \phpbb\user $user, \phpbb\template\template $template, \phpbb\config\config $config)
	{
		$this->user			= $user;
		$this->template		= $template;
		$this->config		= $config;
		$this->ext_manager	= $ext_manager;
		$this->path_helper	= $path_helper;

		$this->ext_path		= $this->ext_manager->get_extension_path('hifikabin/stickybar', true);
		$this->ext_path_web	= $this->path_helper->update_web_root_path($this->ext_path);
	}

	static public function getSubscribedEvents()
	{
		return array(
			'core.user_setup'	=> 'load_language_on_setup',
			'core.page_header'	=> 'add_page_header_link',
		);
	}

	public function load_language_on_setup($event)
	{
		$lang_set_ext = $event['lang_set_ext'];
		$lang_set_ext[] = array(
			'ext_name' => 'hifikabin/stickybar',
			'lang_set' => 'common',
		);
		$event['lang_set_ext'] = $lang_set_ext;
	}

	public function add_page_header_link($event)
	{
		$this->template->assign_vars(array(
		'S_STICKY_PATH'			=> $this->ext_path_web,
		'IS_PHPBB_31'			=> (phpbb_version_compare(PHPBB_VERSION, '3.2.0@dev', '<')),
		'STICKYBAR_COLOUR'		=> $this->config['stickybar_colour'],
		'STICKYBAR_TEXT_COLOUR'	=> $this->config['stickybar_text_colour'],
		'STICKYBAR_SEARCH'		=> $this->config['stickybar_search'],
		'STICKYBAR_SELECT'		=> $this->config['stickybar_select'],
		'STICKYBAR_LOGO'		=> $this->config['stickybar_logo'],
		'STICKYBAR_LEFT'		=> $this->config['stickybar_left'],
		'STICKYBAR_TOP'			=> $this->config['stickybar_top'] ,
		'USER_STICKYBAR'		=> $this->user->data['stickybar'],
		));
	}
}