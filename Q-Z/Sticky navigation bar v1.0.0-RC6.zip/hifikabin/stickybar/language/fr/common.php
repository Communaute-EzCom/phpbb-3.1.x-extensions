<?php
/**
 *
 * Sticky navigation bar. An extension for the phpBB Forum Software package.
 * French translation by Galixte (http://www.galixte.com)
 *
 * @copyright (c) 2018 HiFiKabin
 * @license GNU General Public License, version 2 (GPL-2.0-only)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'ACP_STICKYBAR_CONFIG'				=> 'Barre de navigation épinglée',
	'ACP_STICKYBAR_CONFIG_EXPLAIN'		=> 'Cette page permet de configurer l’extension « Barre de navigation épinglée ».',

	'STICKYBAR_COLOUR'					=> 'Couleur d’arrière-plan de la barre de navigation épinglée',
	'STICKYBAR_COLOUR_JS'				=> 'Pour sélectionner la couleur d’arrière-plan cliquer sur le champ de saisie du code couleur.',
	'STICKYBAR_COLOUR_EXPLAIN'			=> 'Permet de saisir le code HEXADECIMAL de la couleur d’arrière-plan de la barre de navigation épinglée.',

	'STICKYBAR_TEXT_COLOUR'				=> 'Couleur du texte de la barre de navigation épinglée',
	'STICKYBAR_TEXT_COLOUR_JS'			=> 'Pour sélectionner la couleur du texte cliquer sur le champ de saisie du code couleur.',
	'STICKYBAR_TEXT_COLOUR_EXPLAIN'		=> 'Select the Sticky Text Bar colour',

	'STICKYBAR_SEARCH'					=> 'Afficher la recherche dans la barre de navigation épinglée',
	'STICKYBAR_SEARCH_EXPLAIN'			=> 'Permet d’afficher le champ de recherche du forum dans la barre de navigation épinglée.',

	'STICKYBAR_SELECT'					=> 'Afficher un logo dans la barre de navigation épinglée',
	'STICKYBAR_SELECT_EXPLAIN'			=> 'Permet d’afficher un logo personnalisé dans la barre de navigation épinglée.',
	'STICKYBAR_LOGO'					=> 'Fichier du logo de la barre de navigation épinglée',
	'STICKYBAR_LOGO_EXPLAIN'			=> 'Permet de saisir le nom du fichier image du logo, tel que : « logo.png ». L’extension va rechercher automatiquement le fichier image du logo depuis le répertoire suivant : « ./images/ ».',

	'STICKYBAR_LEFT'					=> 'Largeur du logo',
	'STICKYBAR_LEFT_EXPLAIN'			=> 'Permet de saisir la valeur en pixel de la largeur du fichier image du logo affiché dans la barre de navigation épinglée.',

	'STICKYBAR_TOP'						=> 'Hauteur du logo',
	'STICKYBAR_TOP_EXPLAIN'				=> 'Permet de saisir la valeur en pixel de la hauteur du fichier image du logo affiché dans la barre de navigation épinglée.',

	'ACP_STICKYBAR_CONFIG_SET'			=> 'Configuration',
	'STICKYBAR_SAVED'					=> 'Les paramètres de la barre de navigation épinglée ont été sauvegardés',
));

