<?php
/**
*
* Sticky navigation bar extension for the phpBB Forum Software package.
* French translation by Galixte (http://www.galixte.com)
*
* @copyright (c) 2017 HiFiKabin <https://phpbb.hifikabin.me.uk>
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
	'ACP_STICKYBAR'					=> 'Barre de navigation épinglée',
	'STICKYBAR_CONFIG'				=> 'Paramètres de la barre de navigation épinglée',

	'STICKYBAR_SAVED'				=> 'Les paramètres de la barre de navigation épinglée ont été sauvegardés',

	'STICKYBAR_COLOUR'				=> 'Couleur d’arrière-plan de la barre de navigation épinglée',
	'STICKYBAR_SEARCH'				=> 'Afficher la recherche dans la barre de navigation épinglée',
	'STICKYBAR_SELECT'				=> 'Afficher un logo dans la barre de navigation épinglée',
	'STICKYBAR_LOGO'				=> 'Fichier du logo de la barre de navigation épinglée',
	'STICKYBAR_CORNER'				=> 'Arrondir les angles du logo de la barre de navigation épinglée',

	'STICKYBAR_COLOUR_EXPLAIN'		=> 'Permet de saisir le code HEXADECIMAL de la couleur d’arrière-plan de la barre de navigation épinglée.',
	'STICKYBAR_COLOUR_JS'			=> 'Pour sélectionner une couleur d’arrière-plan cliquer sur le champ de saisie du code couleur',
	'STICKYBAR_SEARCH_EXPLAIN'		=> 'Permet d’afficher le champ de recherche du forum dans la barre de navigation épinglée.',
	'STICKYBAR_SELECT_EXPLAIN'		=> 'Permet d’afficher un logo personnalisé dans la barre de navigation épinglée.',
	'STICKYBAR_LOGO_EXPLAIN'		=> 'Permet de saisir le nom du fichier image du logo, tel que : « logo.png ». Il est nécessaire de placer le fichier image dans l’un des répertoires suivants afin que l’extension puisse le trouver : « ./styles/votre_style/theme/ » ou « ./styles/votre_style/theme/images » ou encore « ./images folder ».',
	'STICKYBAR_LOGO_PREVIEW'		=> 'Aperçu du logo de la barre de navigation épinglée',
	'STICKYBAR_LOGO_NOT_FOUND'		=> 'Aucun logo trouvé dans l’un des trois répertoires mentionnées',
	'STICKYBAR_CORNER_EXPLAIN'		=> 'Permet de saisir la valeur de l’arrondi (Border radius) pour le logo de la barre de navigation épinglée.',
	'STICKYBAR_PX'					=> 'px',

	'ACP_STICKYBAR_CONFIG'			=> 'Barre de navigation épinglée',
	'ACP_STICKYBAR_CONFIG_EXPLAIN'	=> 'Cette page permet de configurer l’extension « Barre de navigation épinglée ».',

	'ACP_STICKYBAR_CONFIG_SET'		=> 'Configuration',
	'STICKYBAR_CONFIG_SAVED'		=> 'Les paramètres de la barre de navigation épinglée ont été sauvegardés',
));

