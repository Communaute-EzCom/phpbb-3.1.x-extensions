<?php

namespace rfd\trader;

class ext extends \phpbb\extension\base {

}