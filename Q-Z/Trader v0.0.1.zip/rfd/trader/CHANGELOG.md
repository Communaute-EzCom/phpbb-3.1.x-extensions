* 0.0.1 (2015-xx-xx)

    * 2015-01-19
        * fixed feedback replies so only the related parties can see the reply to feedback button
        * added view and post feedback user permissions
        * redesigned how private comments are displayed on the Trader Feedback page
        * fixed bugs where reporting trader feedback wasn't working properly 
        * last editor of a feedback is now shown in the edit history
        * fixed behaviour/crashes in the MCP where report details tabs were being shown incorrectly
        * closing and deleting feedback reports now correctly mimics phpBB behaviour
        * closing/deleting feedback reports in the MCP now shows up in the moderator log
        * when creating a topic in a forum with only one BST option, the option is now shown

	* 2014-08-11
		* updated feedback image
	
	* 2014-08-07
		* changed the logic so that the rating given to other users is the summations of all feedback
		* added configuration option on ACP to set what kind of trades are permitted on per forum basis