<?php
/**
*
* Right Side Header Image extension for the phpBB Forum Software package.
* French translation by Galixte (http://www.galixte.com)
*
* @copyright (c) 2015 HiFiKabin
* @license GNU General Public License, version 2 (GPL-2.0)
*
*/

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ’ « » “ ” …
//

$lang = array_merge($lang, array(
   'ACP_RIGHTHEADERIMAGE_CONFIG'           => 'Image de droite de l’en-tête',
   'ACP_RIGHTHEADERIMAGE_CONFIG_EXPLAIN'      => 'Sur cette page il est possible de configurer l’extension « Image de droite de l’en-tête ». L’en-tête du forum sera redimensionnée automatiquement suivant les dimensions de l’image.',
   'RIGHTHEADERIMAGE_VERSION'              => 'Version',

   'ACP_RIGHTHEADERIMAGE_CONFIG_SET'       => 'Configuration',
   'RIGHTHEADERIMAGE_CONFIG_SAVED'         => 'Les paramètres de l’image de droite de l’en-tête ont été sauvegardés.',
      
   'RIGHTHEADERIMAGE_ENABLE'               => 'Activer l’image de droite de l’en-tête',
   'RIGHTHEADERIMAGE_ENABLE_EXPLAIN'       => 'Permet d’afficher l’image de droite de l’en-tête du forum.',

   'RIGHTHEADERIMAGE_SEARCH'               => 'Recherche',
   'RIGHTHEADERIMAGE_SEARCH_EXPLAIN'       => 'Permet d’afficher la recherche dans la barre de navigation du forum lorsque l’image de droite de l’en-tête est activée.',

   'RIGHTHEADERIMAGE_IMAGE_URL'              => 'Adresse URL de l’image de droite de l’en-tête',
   'RIGHTHEADERIMAGE_IMAGE_URL_EXPLAIN'         => 'Permet de saisir l’adresse URL complète de l’image de droite de l’en-tête incluant : « http:// »',
   'RIGHTHEADERIMAGE_IMAGE_URL_PLACEHOLDER'     => 'http://domaine.fr/image.jpg',

   'RIGHTHEADERIMAGE_IMAGE_LINK'             => 'Adresse URL du lien de l’image de droite de l’en-tête',
   'RIGHTHEADERIMAGE_IMAGE_LINK_EXPLAIN'        => 'Permet de saisir l’adresse URL complète du lien lorsque l’on clique sur l’image de droite de l’en-tête incluant : « http:// »',
   'RIGHTHEADERIMAGE_IMAGE_LINK_PLACEHOLDER'     => 'http://www.domaine.com',

   'RIGHTHEADERIMAGE_TARGET'              => 'Mode d’ouverture du lien',
   'RIGHTHEADERIMAGE_TARGET_EXPLAIN'         => 'Permet d’ouvrir le lien de l’image de droite de l’en-tête dans un nouvel onglet/fenêtre.',

));
